package com.optum.dc.cdw.processtracker.service;

import com.optum.dc.cdw.processtracker.entity.FilePrcsTrackCorrId;
import com.optum.dc.cdw.processtracker.repository.FilePrcsTrackCorrIdImp;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

class FilePrcsTrackCorrIdServiceTest {

    @Mock
    private FilePrcsTrackCorrIdImp filePrcsTrackCorrIdImp;

    @InjectMocks
    private FilePrcsTrackCorrIdService service;

    @BeforeEach
    void setUp(){
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void addFilePrcsTrackCorrId_setsTimestampsAndSaves(){
        FilePrcsTrackCorrId input = new FilePrcsTrackCorrId();
        FilePrcsTrackCorrId saved = new FilePrcsTrackCorrId();
        saved.setFilePrcsTrackCorrIdSk(1L);
        when(filePrcsTrackCorrIdImp.save(any(FilePrcsTrackCorrId.class))).thenReturn(saved);

        FilePrcsTrackCorrId result = service.addFilePrcsTrackCorrId(input);
        assertNotNull(result);
        assertEquals(1L, result.getFilePrcsTrackCorrIdSk());
        assertNotNull(input.getInsrtDttm());
        assertNotNull(input.getUpdtDttm());
    }
}


