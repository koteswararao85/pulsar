package com.optum.dc.cdw.processtracker;

import com.optum.dc.cdw.processtracker.controller.AppController;
import com.optum.dc.cdw.processtracker.exception.ExceptionHandlers;
import com.optum.dc.cdw.processtracker.service.AppService;
import com.optum.dc.cdw.processtracker.util.FilePrcsTrackMapper;
import com.optum.dc.cdw.processtracker.util.FilePrcsTrackMapperImpl;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.test.context.ActiveProfiles;

@Configuration
@ActiveProfiles("junit")
public class TestConfig {
    @Bean
    public AppController appController(){
        return new AppController();
    }

    @Bean
    public AppService appService(){
        return new AppService();
    }

    @Bean
    public ExceptionHandlers exceptionHandlers(){
        return new ExceptionHandlers();
    }

    @Bean
    public FilePrcsTrackMapper filePrcsTrackMapper(){
        return new FilePrcsTrackMapperImpl();
    }

}
