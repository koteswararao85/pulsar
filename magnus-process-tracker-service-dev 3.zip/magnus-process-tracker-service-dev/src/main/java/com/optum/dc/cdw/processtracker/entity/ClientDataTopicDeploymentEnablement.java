package com.optum.dc.cdw.processtracker.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.optum.dc.cdw.processtracker.util.Constants;
import com.optum.dc.cdw.processtracker.util.DataTopic;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "client_datatopic_deployment_enablement", schema = Constants.SCHEMA)
@AllArgsConstructor
@NoArgsConstructor
public class ClientDataTopicDeploymentEnablement {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @JsonIgnore
    @Column(name = "id")
    private Long id;

    @Column(name = "sub_cli_sk", nullable = false)
    private Long subCliSk;

    @Enumerated(EnumType.STRING)
    @Column(name = "data_topic", nullable = false)
    private DataTopic dataTopic;

    @Column(name = "is_active", nullable = false)
    private Boolean isActive;

    @JsonIgnore
    @Column(name= "UPDT_DTTM", nullable = true)
    private LocalDateTime updtDttm;

    @Column(name = "UPDATE_DESCRIPTION", nullable = true)
    private String updateDescription;

    @NotEmpty(message = "Update user cannot be null or empty")
    @Column(name = "UPDATE_USER", nullable = true)
    private String updateUser;

}
