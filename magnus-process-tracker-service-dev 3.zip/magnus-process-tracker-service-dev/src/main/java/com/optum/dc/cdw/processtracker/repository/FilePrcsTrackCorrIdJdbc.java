package com.optum.dc.cdw.processtracker.repository;

import com.optum.dc.cdw.processtracker.dto.EventTriggerBody;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Component;

import java.util.List;

import static com.optum.dc.cdw.processtracker.util.Constants.SCHEMA;

@Component
public class FilePrcsTrackCorrIdJdbc {

    private final NamedParameterJdbcTemplate jdbcTemplate;

    @Autowired
    public FilePrcsTrackCorrIdJdbc(NamedParameterJdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public List<String> findCorrIdsByFileTypeAndStatusRanked(String fileType, Integer status, String orderBy,Integer limit) {
        String query = """
                WITH RankedTable as (
                SELECT c.FILE_PRCS_NAME, ROW_NUMBER() OVER (PARTITION BY c.CLIENT_ID ORDER BY c.%s) as rn
                FROM %s.FILE_PRCS_TRACK_CORR_ID c
                INNER JOIN %s.FILE_PRCS_TRACK t ON c.FILE_PRCS_KEY = t.FILE_PRCS_KEY
                WHERE c.FILE_TYPE= :fileType AND t.FILE_PRCS_STS_KEY= :status AND c.CLIENT_ID IS NOT NULL
            ) SELECT TOP %s FILE_PRCS_NAME FROM RankedTable WHERE rn = 1
                """.formatted(orderBy,SCHEMA,SCHEMA,limit);
        MapSqlParameterSource parameters = new MapSqlParameterSource();
        parameters.addValue("fileType", fileType);
        parameters.addValue("status", status);
        return jdbcTemplate.queryForList(query,parameters ,String.class);
    }

    public List<EventTriggerBody> findEventTriggerBodiesByFileTypeAndFilePrcsStsKeyAndMaxRetryCount(String fileType, Integer filePrcsStsKey, Long maxRetryCount) {
        String query = """
                SELECT t.FILE_PRCS_NAME, t.EVENT_TRIGGER_BODY
                FROM %s.FILE_PRCS_TRACK_CORR_ID t
                INNER JOIN %s.FILE_PRCS_TRACK c ON t.FILE_PRCS_KEY = c.FILE_PRCS_KEY
                WHERE t.FILE_TYPE = :fileType AND c.FILE_PRCS_STS_KEY = :filePrcsStsKey AND c.RETRY_COUNT < :maxRetryCount
                """.formatted(SCHEMA,SCHEMA);
        MapSqlParameterSource parameters = new MapSqlParameterSource();
        parameters.addValue("fileType", fileType);
        parameters.addValue("filePrcsStsKey", filePrcsStsKey);
        parameters.addValue("maxRetryCount", maxRetryCount);
        return jdbcTemplate.query(query,parameters,(rs, rowNum) -> new EventTriggerBody(rs.getString("FILE_PRCS_NAME"), rs.getString("EVENT_TRIGGER_BODY")));
    }
}
