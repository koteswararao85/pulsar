package com.optum.dc.cdw.processtracker.util;

import com.optum.dc.cdw.processtracker.dto.FilePrcs;
import com.optum.dc.cdw.processtracker.dto.FilePrcsTrackUpdate;
import com.optum.dc.cdw.processtracker.entity.FilePrcsTrack;
import com.optum.dc.cdw.processtracker.entity.FilePrcsTrackAudit;
import com.optum.dc.cdw.processtracker.entity.FilePrcsTrackCorrId;
import com.optum.dc.cdw.processtracker.entity.FilePrcsTrackError;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.NullValuePropertyMappingStrategy;

@Mapper(componentModel = "spring",nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
public interface FilePrcsTrackMapper {

    @Mapping(target = "filePrcsKey", ignore = true)
    @Mapping(target = "filePrcsName", ignore = true)
    @Mapping(target = "insrtDttm", ignore = true)
    @Mapping(target = "insrtUserId", ignore = true)
    @Mapping(target = "updtDttm", ignore = true)
    @Mapping(target = "filePrcsType", ignore = true)
    @Mapping(target = "filePrcsTypeEnum", ignore = true)
    @Mapping(target = "filePrcsStsKey", ignore = true)
    @Mapping(target = "prcsTrigger", ignore = true)
    void filePrcsTrackUpdateToFilePrcsTrack(FilePrcsTrackUpdate filePrcsTrackUpdate, @MappingTarget FilePrcsTrack filePrcsTrack);

    @Mapping(target = "attempts", ignore = true)
    @Mapping(target = "totalCount", ignore = true)
    @Mapping(target = "prntFilePrcsKey", ignore = true)
    @Mapping(target = "sourceSystem", source = "filePrcs.origSourceInfo")
    FilePrcsTrack filePrcsToFilePrcsTrack(FilePrcs filePrcs);

    FilePrcsTrackUpdate filePrcsTrackToFilePrcsTrackUpdate(FilePrcsTrack filePrcsTrack);

    @Mapping(target = "filePrcsTrackCorrIdSk", ignore = true)
    FilePrcsTrackCorrId filePrcsToFilePrcsTrackCorrID(FilePrcs filePrcs);

    @Mapping(target = "fileSize", ignore = true)
    @Mapping(target = "attempts", ignore = true)
    @Mapping(target = "totalCount", ignore = true)
    @Mapping(target = "prntFilePrcsKey", ignore = true)
    @Mapping(target = "sourceSystem", ignore = true)
    @Mapping(target = "batchRunId",ignore = true)
    FilePrcsTrackUpdate filePrcsTrackErrorToFilePrcsTrackUpdate(FilePrcsTrackError filePrcsTrackError);

    @Mapping(target = "runId", source = "filePrcsTrack.batchRunId")
    FilePrcsTrackAudit filePrcsTrackToFilePrcsTrackAudit(FilePrcsTrack filePrcsTrack);

    FilePrcsTrackError filePrcsTrackToFilePrcsTrackError(FilePrcsTrack filePrcsTrack);

}
