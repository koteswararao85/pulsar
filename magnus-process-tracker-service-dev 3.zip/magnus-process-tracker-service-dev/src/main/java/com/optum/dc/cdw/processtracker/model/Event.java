package com.optum.dc.cdw.processtracker.model;

public class Event {

    EventHeader eventHeader;
    EventBody eventBody;

    public Event() {

    }

    public Event(EventHeader eventHeader, EventBody eventBody) {
        super();
        this.eventHeader = eventHeader;
        this.eventBody = eventBody;
    }

    /**
     * @return the eventHeader
     */
    public EventHeader getEventHeader() {
        return eventHeader;
    }
    /**
     * @param eventHeader the eventHeader to set
     */
    public void setEventHeader(EventHeader eventHeader) {
        this.eventHeader = eventHeader;
    }
    /**
     * @return the eventBody
     */
    public EventBody getEventBody() {
        return eventBody;
    }
    /**
     * @param eventBody the eventBody to set
     */
    public void setEventBody(EventBody eventBody) {
        this.eventBody = eventBody;
    }


    @Override
    public String toString() {
        return "Event [eventHeader=" + eventHeader + ", eventBody=" + eventBody + "]";
    }


}