package com.optum.dc.cdw.processtracker.service;

import com.optum.dc.cdw.processtracker.dto.FilePrcsTrackUpdate;
import com.optum.dc.cdw.processtracker.entity.FilePrcsTrack;
import com.optum.dc.cdw.processtracker.exception.DataFieldsMismatch;
import com.optum.dc.cdw.processtracker.exception.DataNotFoundException;
import com.optum.dc.cdw.processtracker.repository.FilePrcsTrackImp;
import com.optum.dc.cdw.processtracker.util.FilePrcsStatus;
import com.optum.dc.cdw.processtracker.util.FilePrcsTrackMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Objects;
import java.util.Optional;

@Service
@Slf4j
public class FilePrcsTrackUpdateService {

    private static final ZoneId CHICAGO_ZONE_ID = ZoneId.of("America/Chicago");

    @Autowired
    private FilePrcsTrackImp filePrcsTrackImp;

    @Autowired
    private FilePrcsTrackMapper filePrcsTrackMapper;

    @Autowired
    private EventHelper eventHelper;

    @Transactional
    public FilePrcsTrackUpdate updateFilePrcsTrack(FilePrcsTrackUpdate filePrcsTrackUpdate){
        Optional<FilePrcsTrack> existFileTrack = Optional.empty();
        if(filePrcsTrackUpdate.getFilePrcsKey()!=null)
            existFileTrack = filePrcsTrackImp.findById(filePrcsTrackUpdate.getFilePrcsKey());
        if (filePrcsTrackUpdate.getFilePrcsName()!=null && existFileTrack.isEmpty()) {
            existFileTrack = filePrcsTrackImp.findByFilePrcsNameLike(filePrcsTrackUpdate.getFilePrcsName());
        }
        if (existFileTrack.isEmpty()) {
            throw new DataNotFoundException("FilePrcsTrack not found for given Key or Name");
        }
        FilePrcsTrack existFileTrackGot = existFileTrack.get();
        if(filePrcsTrackUpdate.getFilePrcsName()!=null && !Objects.equals(filePrcsTrackUpdate.getFilePrcsName(), existFileTrackGot.getFilePrcsName()))
            throw new DataFieldsMismatch("Data mismatched for given FilePrcsKey & FilePrcsName");
        if(filePrcsTrackUpdate.getFilePrcsKey()!=null && !Objects.equals(filePrcsTrackUpdate.getFilePrcsKey(), existFileTrackGot.getFilePrcsKey()))
            throw new DataFieldsMismatch("Data mismatched for given FilePrcsKey & FilePrcsName");
        filePrcsTrackMapper.filePrcsTrackUpdateToFilePrcsTrack(filePrcsTrackUpdate,existFileTrackGot);
        existFileTrackGot.setUpdtDttm(ZonedDateTime.now(CHICAGO_ZONE_ID).toLocalDateTime());
        existFileTrackGot.setFilePrcsStsKey(filePrcsTrackUpdate.getFilePrcsStatus().getValue());
        FilePrcsTrack updatedFileTrack = filePrcsTrackImp.save(existFileTrackGot);
        log.info("fileprcstrack is updated {}",existFileTrackGot.getFilePrcsKey());
        filePrcsTrackUpdate.setFilePrcsKey(existFileTrackGot.getFilePrcsKey());

        if(filePrcsTrackUpdate.getFilePrcsStatus() != null && filePrcsTrackUpdate.getFilePrcsStatus().getValue().equals(FilePrcsStatus.COPIED_TO_DATAHUB.getValue())){
            eventHelper.sendEventIfCopiedToDatahub(filePrcsTrackUpdate.getFilePrcsName(), filePrcsTrackUpdate.getFilePrcsStatus());
        }
        return filePrcsTrackMapper.filePrcsTrackToFilePrcsTrackUpdate(updatedFileTrack);
    }
}


