package com.optum.dc.cdw.processtracker.service;

import com.optum.dc.cdw.processtracker.entity.FilePrcsTrack;
import com.optum.dc.cdw.processtracker.entity.FilePrcsTrackCorrId;
import com.optum.dc.cdw.processtracker.repository.FilePrcsTrackCorrIdImp;
import com.optum.dc.cdw.processtracker.repository.FilePrcsTrackImp;
import com.optum.dc.cdw.processtracker.util.FilePrcsTrackMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
@Slf4j
public class FilePrcsBatchService {

    private static final ZoneId CHICAGO_ZONE_ID = ZoneId.of("America/Chicago");

    @Autowired
    private FilePrcsTrackImp filePrcsTrackImp;

    @Autowired
    private FilePrcsTrackCorrIdImp filePrcsTrackCorrIdImp;

    @Autowired
    private FilePrcsTrackMapper filePrcsTrackMapper;

    @Transactional
    public Collection<FilePrcsTrack> batchInsertFilePrcsTrack(Collection<FilePrcsTrack> batchFilePrcsTrack){
        List<String> filePrcsNames = new ArrayList<>();
        batchFilePrcsTrack = batchFilePrcsTrack.stream().map(filePrcsTrack -> {
            filePrcsTrack.setInsrtDttm(ZonedDateTime.now(CHICAGO_ZONE_ID).toLocalDateTime());
            filePrcsTrack.setUpdtDttm(ZonedDateTime.now(CHICAGO_ZONE_ID).toLocalDateTime());
            filePrcsTrack.setFilePrcsStsKey(filePrcsTrack.getFilePrcsStatus().getValue());
            filePrcsTrack.setFilePrcsType(filePrcsTrack.getFilePrcsTypeEnum().name());
            filePrcsNames.add(filePrcsTrack.getFilePrcsName());
            return filePrcsTrack;
        }).collect(Collectors.toList());
        Map<String,FilePrcsTrack> map = batchFilePrcsTrack.stream().collect(Collectors.toMap(FilePrcsTrack::getFilePrcsName, Function.identity()));
        try {
            log.info("Trying to create entries for FilePrcs [{}]",String.join(",",filePrcsNames));
            Collection<FilePrcsTrack> result = filePrcsTrackImp.saveAll(batchFilePrcsTrack);
            return result.stream().map(filePrcsTrack -> {
                log.info("FilePrcsTrack created {}",filePrcsTrack.getFilePrcsKey());
                filePrcsTrack.setFilePrcsTypeEnum(map.get(filePrcsTrack.getFilePrcsName()).getFilePrcsTypeEnum());
                filePrcsTrack.setFilePrcsStatus(map.get(filePrcsTrack.getFilePrcsName()).getFilePrcsStatus());
                return filePrcsTrack;
            }).collect(Collectors.toList());
        }catch (DataIntegrityViolationException ex){
            log.error("Need Unique value for name");
            throw new DataIntegrityViolationException("Integrity Violated while inserting, Need Unique value for filePrcsName");
        }
    }

    @Transactional
    public Collection<FilePrcsTrackCorrId> batchInsertFilePrcsCorr(Collection<FilePrcsTrackCorrId> batchFilePrcsCorr){
        batchFilePrcsCorr = batchFilePrcsCorr.stream().map(filePrcsTrackCorrId -> {
            filePrcsTrackCorrId.setInsrtDttm(ZonedDateTime.now(CHICAGO_ZONE_ID).toLocalDateTime());
            filePrcsTrackCorrId.setUpdtDttm(ZonedDateTime.now(CHICAGO_ZONE_ID).toLocalDateTime());
            return filePrcsTrackCorrId;
        }).collect(Collectors.toList());
        return filePrcsTrackCorrIdImp.saveAll(batchFilePrcsCorr);
    }
}


