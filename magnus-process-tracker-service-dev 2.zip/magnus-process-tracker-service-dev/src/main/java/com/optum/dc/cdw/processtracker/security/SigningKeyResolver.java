package com.optum.dc.cdw.processtracker.security;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.dc.cdw.processtracker.configuration.AADAuthorizationConfig;
import com.optum.dc.cdw.processtracker.dto.JsonWebKey;
import com.optum.dc.cdw.processtracker.dto.OpenIdConnectConfiguration;
import com.optum.dc.cdw.processtracker.dto.AADKeySet;
import com.optum.dc.cdw.processtracker.exception.JwtValidationException;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwsHeader;
import io.jsonwebtoken.SigningKeyResolverAdapter;
import lombok.extern.slf4j.Slf4j;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

import java.io.Serial;
import java.io.Serializable;
import java.math.BigInteger;
import java.security.Key;
import java.security.KeyFactory;
import java.security.PublicKey;
import java.security.spec.RSAPublicKeySpec;
import java.util.Base64;

@Slf4j
@Configuration
@Profile("!default")
public class SigningKeyResolver extends SigningKeyResolverAdapter implements Serializable {
    @Serial
    private static final long serialVersionUID = 2405172041950251807L;
    private transient AADKeySet keySet;


    private static final String OPENID_CONFIG_PATH="/.well-known/openid-configuration";

    SigningKeyResolver(AADAuthorizationConfig aadAuthorizationConfig) throws Exception {
        keySet = getSigningKeys(aadAuthorizationConfig.getAuthority());
    }

    @Override
    public Key resolveSigningKey(JwsHeader jwsHeader, Claims claims) {

        String tokenKeyId = jwsHeader.getKeyId();
        for(JsonWebKey key: keySet.getKeys()){
            if(key.getKid().equalsIgnoreCase(tokenKeyId)){
                return generatePublicKey(key);
            }
        }

        throw new JwtValidationException("Signature validation failed: Could not find a key with matching kid");
    }

    private AADKeySet getSigningKeys(String authority)throws Exception {
        OpenIdConnectConfiguration openIdConfig = getOpenIdConfiguration(authority);
        return getKeysFromJwkUri(openIdConfig.getJwksUri());
    }

    private OpenIdConnectConfiguration getOpenIdConfiguration(String authority) throws Exception {
        String openIdConnectDiscoveryEndpoint = authority + OPENID_CONFIG_PATH;

        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder()
                .url(openIdConnectDiscoveryEndpoint)
                .build();

        Response response = client.newCall(request).execute();
        String responseJson =  response.body().string();
        ObjectMapper objectMapper = new ObjectMapper();
        return objectMapper.readValue(responseJson, OpenIdConnectConfiguration.class);
    }

    private AADKeySet getKeysFromJwkUri(String jwksUri) throws Exception {

        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder()
                .url(jwksUri)
                .build();

        Response response = client.newCall(request).execute();
        String responseJson =  response.body().string();
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        return objectMapper.readValue(responseJson, AADKeySet.class);
    }

    private PublicKey generatePublicKey(JsonWebKey key) {
        try {
            BigInteger modulus = new BigInteger(1, Base64.getUrlDecoder().decode(key.getN()));
            BigInteger exponent = new BigInteger(1, Base64.getUrlDecoder().decode(key.getE()));

            RSAPublicKeySpec publicSpec = new RSAPublicKeySpec(modulus, exponent);
            KeyFactory factory = KeyFactory.getInstance("RSA");
            return factory.generatePublic(publicSpec);
        } catch(Exception e){
            throw new JwtValidationException("Key generation failed", e);
        }
    }
}