package com.optum.dc.cdw.processtracker.repository;

import com.optum.dc.cdw.processtracker.entity.FilePrcsTrackAudit;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface FilePrcsTrackAuditImp extends JpaRepository<FilePrcsTrackAudit,Long> {
}
