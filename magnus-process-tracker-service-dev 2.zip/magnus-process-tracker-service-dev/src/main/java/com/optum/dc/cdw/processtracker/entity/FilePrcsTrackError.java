package com.optum.dc.cdw.processtracker.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.optum.dc.cdw.processtracker.util.Constants;
import com.optum.dc.cdw.processtracker.util.FilePrcsStatus;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.io.File;
import java.time.LocalDateTime;

@Entity
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@Table(name = "FILE_PRCS_TRACK_ERROR",schema = Constants.SCHEMA)
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper=false)
public class FilePrcsTrackError extends AuditTrack {
    @Id
    @JsonIgnore
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "FILE_PRCS_TRACK_ERROR_SK")
    private Long filePrcsTrackErrorSk;

    @Column(name="FILE_PRCS_KEY")
    private Long filePrcsKey;

    @Column(name="FILE_PRCS_NAME")
    @NotNull
    @Size(max = 500)
    private String filePrcsName;

    @Column(name = "ERROR_MSG")
    @NotNull
    @Size(max = 4000)
    private String errorMsg;

    @Column(name = "PROCESS_NAME")
    @Size(max = 200)
    private String processNm;

    @Column(name = "PROCESS_ID")
    @Size(max = 200)
    private String processId;

    @Column(name ="SOURCE_SYSTEM")
    @Size(max=100)
    private String sourceSystem;

    @Transient
    private FilePrcsStatus filePrcsStatus;

    public FilePrcsTrackError(@NotNull LocalDateTime insrtDttm, @NotNull String insrtUserId, LocalDateTime updtDttm, String updtUserId, Long filePrcsTrackErrorSk, Long filePrcsKey, String filePrcsName, String errorMsg, String processNm, String processId, String sourceSystem, FilePrcsStatus filePrcsStatus) {
        super(insrtDttm, insrtUserId, updtDttm, updtUserId);
        this.filePrcsTrackErrorSk = filePrcsTrackErrorSk;
        this.filePrcsKey = filePrcsKey;
        this.filePrcsName = filePrcsName;
        this.errorMsg = errorMsg;
        this.processNm = processNm;
        this.processId = processId;
        this.sourceSystem = sourceSystem;
        this.filePrcsStatus = filePrcsStatus;
    }

    public FilePrcsTrackError(@NotNull String insrtUserId, String filePrcsName, String errorMsg, String processNm, String processId, @NotNull LocalDateTime insrtDttm, FilePrcsStatus filePrcsStatus) {
        super(insrtDttm,insrtUserId);
        this.filePrcsName = filePrcsName;
        this.errorMsg = errorMsg;
        this.processNm = processNm;
        this.processId = processId;
        this.filePrcsStatus = filePrcsStatus;
    }
}
