package com.optum.dc.cdw.processtracker.controller;

import com.optum.dc.cdw.processtracker.dto.*;
import com.optum.dc.cdw.processtracker.entity.ClientDataTopicDeploymentEnablement;
import com.optum.dc.cdw.processtracker.entity.FilePrcsTrack;
import com.optum.dc.cdw.processtracker.entity.FilePrcsTrackError;
import com.optum.dc.cdw.processtracker.service.AppService;
import com.optum.dc.cdw.processtracker.util.FilePrcsStatus;
import com.optum.dc.cdw.processtracker.util.FilePrcsTrackCorrIdColumnsEnum;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import java.util.Collection;


@RestController
@RequestMapping(value = "/api/v1/processtrkr")
@Validated
@Slf4j
@Tag(name = "Process Tracker APIs")
public class AppController {

    @Autowired
    private AppService service;
    @Value("${spring.datasource.url}")
    private String database;

    @PostMapping("/addFilePrcsTrack")
    @ResponseBody
    @Operation(summary = "Adding new File Process Track",
                description = """
                            Table: FILE_PRCS_TRACK
                            
                            Functionality: Adding new File Prcs Track entry with unique file_prcs_name
                            
                            Input Schema: FilePrcsTrack
                            
                            Output Schema: FilePrcsTrack
                               
                        """)
    public FilePrcsTrack addFilePrcsTrack(@Validated @RequestBody FilePrcsTrack filePrcsTrack){
            return service.addFilePrcsTrack(filePrcsTrack);
    }

    @PostMapping("/updateFilePrcsTrack")
    @ResponseBody
    @Operation( summary = "Updating File Process Track",
                description = """
                                Table: FILE_PRCS_TRACK
                                                             
                                Functionality: Updating the existing File_Prcs_Track entry with FilePrcsKey or FilePrcsName
                                 
                                Input Schema: FilePrcsTrackUpdate
                                
                                Output Schema: FilePrcsTrackUpdate
                              """)
    public FilePrcsTrackUpdate updateFilePrcsTrack(@Validated @RequestBody FilePrcsTrackUpdate filePrcsTrackUpdate)  {
        return service.updateFilePrcsTrack(filePrcsTrackUpdate);
    }

    @PostMapping("addFilePrcsTrackError")
    @ResponseBody
    @Operation(summary = "Adding File Process Track Error",
                description = """
                            Table: FILE_PRCS_TRACK_ERROR (also updates FIlE_PRCS_TRACK)
                            
                            Functionality: Adds a entry in FILE_PRCS_TRACK_ERROR and also updates it's corresponding filePrcsTrack in FILE_PRCS_TRACK if it is present.
                            
                            Input Scheme: FilePrcsTrackError
                            
                            Output Scheme: FilePrcsTrackError
                        """)
    public FilePrcsTrackError addFilePrcsTrackError(@Validated @RequestBody FilePrcsTrackError filePrcsTrackError){
        return service.addFilePrcsTrackError(filePrcsTrackError);
    }

    @PostMapping("trackAndCreateFilePrcsKey")
    @ResponseBody
    @Operation(summary = "Creating File Process Track with File Process Correlation",
                description = """
                            Table: FILE_PRCS_TRACK & FILE_PRCS_TRACK_CORR_ID
                            
                            Functionality: Adds entry in FILE_PRCS_TRACK_CORR_ID && and FILE_PRCS_TRACK
                            
                            Input Scheme: FilePrcs
                            
                            Output Scheme: FilePrcsTrack
                        """)
    public FilePrcsTrack trackAndCreateFilePrcsKey(@Validated @RequestBody FilePrcs filePrcs){
        log.info("the databse url is : {}",database);
        return service.trackAndCreateFilePrcsKey(filePrcs);
    }

    @PostMapping("/batchUpdateFilePrcsTrack")
    @ResponseBody
    @Operation(summary = "Used for updating multiple files with same update details")
    public int batchUpdateFilePrcsTrack(@Validated @RequestBody FilePrcsStatusBatchUpdate filePrcsTrackUpdateList){
        return service.batchUpdateFilePrcsTrack(filePrcsTrackUpdateList);
    }

    @PostMapping("/batchCreateAndTrack")
    @ResponseBody
    @Operation(summary = "Batch Insertion of FilePrcsTrack and FilePrcsTrackCorrId")
    public Collection<FilePrcsTrack> batchCreateAndTrack(@Validated @RequestBody Collection<FilePrcs> filePrcsCollection) {
        return service.batchTrackAndCreateFilePrcs(filePrcsCollection);
    }

    @GetMapping("/batchFetchFilePrcsTrackCorrIdByStsKey")
    @ResponseBody
    @Operation(summary = "Used for fetching multiple FilePrcsTrackCorrId by filetype and file status")
    public List<String> getFileNamesByFileTyepAndFilePrcsStsKey(@Validated String fileType, @Validated String filePrcsStatus,
                                                                @RequestParam(required = false, defaultValue = "FILE_PRCS_KEY") FilePrcsTrackCorrIdColumnsEnum orderByColumn,
                                                                @RequestParam(required = false, defaultValue = "false")boolean getOnlyOneClientFileInBatch,
                                                                @RequestParam(required = false, defaultValue = "500")Integer limit){
        return service.getFileNamesByFileTyepAndFilePrcsStsKey(fileType,filePrcsStatus,orderByColumn, getOnlyOneClientFileInBatch,limit);
    }

    @PostMapping("/batchAddFilePrcsError")
    @ResponseBody
    @Operation(summary = "Batch insertion of FilePrcsError")
    public List<String> batchAddFilePrcsError(@Validated @RequestBody FilePrcsErrorBatch filePrcsErrorBatch){
            return service.batchErrorInsert(filePrcsErrorBatch);
    }

    @GetMapping("/batchFetchEventTriggerBodies")
    @ResponseBody
    @Operation(summary = "Batch Fetching of Event Trigger Bodies by File Type and Max retry count")
    public List<EventTriggerBody> findEventTriggerBodiesByFileTypeAndFilePrcsStsKeyAndMaxRetryCount(@Validated String fileType,@RequestParam(required = false, defaultValue = "3") Long maxRetryCount){
        return service.findEventTriggerBodiesByFileTypeAndFilePrcsStsKeyAndMaxRetryCount(fileType,0,maxRetryCount);
    }

    @PostMapping("/increaseRetryCountForFileNames")
    @ResponseBody
    @Operation(summary = "Incrementing Retry Count for a list of file names")
    public int increaseRetryCountByFilePrcsNameIn(@Validated @RequestBody List<String> fileNames){
        return service.increaseRetryCountByFilePrcsNameIn(fileNames);
    }

    @PostMapping("/clientDataTopicEnable")
    @ResponseBody
    @Operation(summary = "Enabling the ingestion of Client Data Topics in core Kafka consumer")
    public ResponseEntity<List<ClientDataTopicDeploymentEnablement>> insertClientDataTopics(@Validated @RequestBody ClientDataTopicRequest request) {
        List<ClientDataTopicDeploymentEnablement> result = service.insertClientDataTopics(request,true);
        return ResponseEntity.ok(result);
    }

    @PostMapping("/clientDataTopicDisable")
    @ResponseBody
    @Operation(summary = "Disabling the ingestion of Client Data Topics in core Kafka consumer")
    public ResponseEntity<List<ClientDataTopicDeploymentEnablement>> anotherInsertClientDataTopics(@Validated @RequestBody ClientDataTopicRequest request) {
        List<ClientDataTopicDeploymentEnablement> result = service.insertClientDataTopics(request,false);
        return ResponseEntity.ok(result);
    }

    @GetMapping("/health-check")
    @ResponseBody
    public ResponseEntity<String> healthCheck(){
        return new ResponseEntity<>("app is up", HttpStatusCode.valueOf(200));
    }


}
