package com.optum.dc.cdw.processtracker.util;

import lombok.Getter;

@Getter
public enum FilePrcsTrackCorrIdColumnsEnum {

    FILE_PRCS_KEY	("filePrcsKey"),
    BAD_ROWS	("badRows"),
    CHASE_PROCESS_ID ("chaseProcessId"),
    RUN_ID	("runID");


    private final String value;

    FilePrcsTrackCorrIdColumnsEnum(String i) {
        this.value = i;
    }
}

