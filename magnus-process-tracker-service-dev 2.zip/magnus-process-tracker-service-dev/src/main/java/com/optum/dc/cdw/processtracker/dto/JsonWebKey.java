package com.optum.dc.cdw.processtracker.dto;

import com.fasterxml.jackson.annotation.JsonAlias;
import lombok.Data;

import java.util.List;

@Data
public class JsonWebKey {

    @JsonAlias("kty")
    private String kty;

    @JsonAlias("use")
    private String use;

    @JsonAlias("kid")
    private String kid;

    @JsonAlias("n")
    private String n;

    @JsonAlias("e")
    private String e;

    @JsonAlias("x5t")
    private String x5t;

    @JsonAlias("issuer")
    private String issuer;

    @JsonAlias("x5c")
    private List<String> x5c;
}
