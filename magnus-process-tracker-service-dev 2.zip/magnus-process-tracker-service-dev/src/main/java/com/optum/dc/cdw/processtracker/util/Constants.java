package com.optum.dc.cdw.processtracker.util;

public class Constants {
    public final static String SCHEMA = "tracking";

    public final static String HSTS_HEADER = "Strict-Transport-Security";

    public static final String HSTS_HEADER_VALUE = "max-age=2592000";
}
