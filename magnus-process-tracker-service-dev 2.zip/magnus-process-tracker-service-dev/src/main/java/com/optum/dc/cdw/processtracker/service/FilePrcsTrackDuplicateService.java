package com.optum.dc.cdw.processtracker.service;

import com.optum.dc.cdw.processtracker.entity.FilePrcsTrack;
import com.optum.dc.cdw.processtracker.entity.FilePrcsTrackAudit;
import com.optum.dc.cdw.processtracker.entity.FilePrcsTrackError;
import com.optum.dc.cdw.processtracker.exception.DataNotFoundException;
import com.optum.dc.cdw.processtracker.repository.FilePrcsTrackAuditImp;
import com.optum.dc.cdw.processtracker.repository.FilePrcsTrackErrorImp;
import com.optum.dc.cdw.processtracker.repository.FilePrcsTrackImp;
import com.optum.dc.cdw.processtracker.util.FilePrcsStatus;
import com.optum.dc.cdw.processtracker.util.FilePrcsTrackMapper;
import com.optum.dc.cdw.processtracker.util.FilePrcsType;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Service
@Slf4j
public class FilePrcsTrackDuplicateService {

    private static final String TRACKER_API_NAME = "Tracker.API";

    @Autowired
    private FilePrcsTrackImp filePrcsTrackImp;
    @Autowired
    private FilePrcsTrackAuditImp filePrcsTrackAuditImp;
    @Autowired
    private FilePrcsTrackErrorImp filePrcsTrackErrorImp;
    @Autowired
    private FilePrcsTrackMapper filePrcsTrackMapper;

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public FilePrcsTrack handleDuplicateFilePrcsTrack(FilePrcsTrack incomingFilePrcsTrack) {
        try {
            log.error("Need Unique value for name");
            FilePrcsTrack existingTrack = filePrcsTrackImp.findByFilePrcsNameLike(incomingFilePrcsTrack.getFilePrcsName())
                    .orElseThrow(() -> new DataNotFoundException("Could not find existing track for duplicate handling: " + incomingFilePrcsTrack.getFilePrcsName()));

            existingTrack.setFilePrcsStatus(FilePrcsStatus.DUPLICATE_FILE_NAME);
            existingTrack.setFilePrcsTypeEnum(FilePrcsType.valueOf(existingTrack.getFilePrcsType()));

            log.info("FilePrcsTrack already exists with filePrcsKey: {}", existingTrack.getFilePrcsKey());

            FilePrcsTrackAudit filePrcsTrackAudit = filePrcsTrackMapper.filePrcsTrackToFilePrcsTrackAudit(existingTrack);
            filePrcsTrackAudit.setFilePrcsStatus(FilePrcsStatus.DUPLICATE_FILE_NAME);
            filePrcsTrackAuditImp.saveAndFlush(filePrcsTrackAudit);
            log.info("FilePrcsTrackAudit is created for existing FilePrcsTrack with filePrcsKey: {} and FilePrcsName: {}", existingTrack.getFilePrcsKey(), existingTrack.getFilePrcsName());

            FilePrcsTrackError filePrcsTrackError = filePrcsTrackMapper.filePrcsTrackToFilePrcsTrackError(existingTrack);
            filePrcsTrackError.setErrorMsg("Integrity Violated while inserting, Need Unique value for filePrcsName");
            filePrcsTrackError.setProcessNm(TRACKER_API_NAME);
            filePrcsTrackErrorImp.saveAndFlush(filePrcsTrackError);
            log.info("FilePrcsTrackError is created for existing FilePrcsTrack with filePrcsKey: {} and FilePrcsName: {}", existingTrack.getFilePrcsKey(), existingTrack.getFilePrcsName());

            return existingTrack;
        } catch (Exception e) {
            log.error("Error during duplicate file handling for file: {}", incomingFilePrcsTrack.getFilePrcsName().replace('\n', '_').replace('\r', '_'), e);
            throw new RuntimeException("Failed to handle duplicate file process track for " + incomingFilePrcsTrack.getFilePrcsName(), e);
        }
    }
}


