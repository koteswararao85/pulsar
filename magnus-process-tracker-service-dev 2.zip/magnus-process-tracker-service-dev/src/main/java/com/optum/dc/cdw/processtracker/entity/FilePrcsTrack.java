package com.optum.dc.cdw.processtracker.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.optum.dc.cdw.processtracker.util.Constants;
import com.optum.dc.cdw.processtracker.util.FilePrcsStatus;
import com.optum.dc.cdw.processtracker.util.FilePrcsType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.springframework.lang.NonNull;

import java.time.LocalDateTime;

@Data
@Entity
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@Table(name = "FILE_PRCS_TRACK",schema = Constants.SCHEMA)
@NoArgsConstructor
@EqualsAndHashCode(callSuper=false)
public class  FilePrcsTrack extends AuditTrack {
    @Id
    @JsonIgnore
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator= "file_prcs_track_seq")
    @SequenceGenerator(name = "file_prcs_track_seq", sequenceName="tracking.FILE_PRCS_TRACK_SEQ", allocationSize = 1)
    @Column(name = "FILE_PRCS_KEY")
    private Long filePrcsKey;

    @Column(name="FILE_PRCS_NAME", unique = true, length = 500)
    @NotNull
    private String filePrcsName;

    @JsonIgnore
    @Column(name = "FILE_PRCS_TYPE", length = 100)
    @Size(max = 100)
    private String filePrcsType;

    @Transient
    @NonNull
    private FilePrcsType filePrcsTypeEnum;

    @JsonIgnore
    @Column(name = "FILE_PRCS_STS_KEY")
    private Integer filePrcsStsKey;

    @Transient
    @NonNull
    private FilePrcsStatus filePrcsStatus;


    @Column(name = "FILE_SIZE")
    private Long fileSize;

    @Column(name = "ATTEMPTS")
    private Integer attempts;

    @Column(name = "TOTAL_COUNT")
    private Integer totalCount;

    @Column(name = "PRNT_FILE_PRCS_KEY")
    private Long prntFilePrcsKey;

    @Column(name = "SOURCE_SYSTEM")
    @Size(max = 100)
    private String sourceSystem;

    @Column(name = "BATCH_RUN_ID")
    private String batchRunId;

    @Column(name = "RETRY_COUNT")
    private Long retryCount;

    @Column(name = "PRCS_TRIGGER")
    private String prcsTrigger;

    public FilePrcsTrack(@NotNull LocalDateTime insrtDttm, @NotNull String insrtUserId, LocalDateTime updtDttm, String updtUserId, Long filePrcsKey, String filePrcsName, String filePrcsType, Integer filePrcsStsKey, Long fileSize, Integer attempts, Integer totalCount, Long prntFilePrcsKey, String sourceSystem,String batchRunId, Long retryCount, String prcsTrigger) {
        super(insrtDttm, insrtUserId, updtDttm, updtUserId);
        this.filePrcsKey = filePrcsKey;
        this.filePrcsName = filePrcsName;
        this.filePrcsType = filePrcsType;
        this.filePrcsStsKey = filePrcsStsKey;
        this.fileSize = fileSize;
        this.attempts = attempts;
        this.totalCount = totalCount;
        this.prntFilePrcsKey = prntFilePrcsKey;
        this.sourceSystem = sourceSystem;
        this.batchRunId = batchRunId;
        this.retryCount = retryCount;
        this.prcsTrigger = prcsTrigger;
    }
}