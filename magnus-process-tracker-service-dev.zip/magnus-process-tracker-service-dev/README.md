# magnus-process-tracker-service
repository for magnus lakehouse process tracker

# Build docker image, push to azure repository and run from local
* docker login -u cregmagnuscusdev cregmagnuscusdev.azurecr.io with acr credential
* docker build -t magnus-process-tracker-service:latest .
* docker tag magnus-process-tracker-service:latest cregmagnuscusdev.azurecr.io/cregmagnuscusdev/magnus-processtrkr:latest
* docker push cregmagnuscusdev.azurecr.io/cregmagnuscusdev/magnus-processtrkr:latest
* docker run -it -p 8080:8080 magnus-process-tracker-service:latest

# Azure login
* $  az login
* $  az account set -s bff0c133-c56b-4467-aa3a-9592e052d757
