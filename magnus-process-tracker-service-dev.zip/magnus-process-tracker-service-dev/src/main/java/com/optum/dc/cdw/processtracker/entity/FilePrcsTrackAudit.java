package com.optum.dc.cdw.processtracker.entity;


import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.optum.dc.cdw.processtracker.util.Constants;
import com.optum.dc.cdw.processtracker.util.FilePrcsStatus;
import com.optum.dc.cdw.processtracker.util.FilePrcsType;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.springframework.lang.NonNull;

@Data
@Entity
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@Table(name = "FILE_PRCS_TRACK_AUDIT",schema = Constants.SCHEMA)
@NoArgsConstructor
@EqualsAndHashCode(callSuper=false)
public class FilePrcsTrackAudit extends AuditTrack{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "FILE_PRCS_TRACK_AUDIT_SK")
    private Long filePrcsTrackAuditSk;

    @Column(name = "FILE_PRCS_KEY")
    @NotNull
    private Long filePrcsKey;

    @Column(name="FILE_PRCS_NAME")
    @NotNull
    private String filePrcsName;

    @JsonIgnore
    @Column(name = "FILE_PRCS_TYPE")
    @Size(max = 100)
    private String filePrcsType;

    @Transient
    @NonNull
    private FilePrcsType filePrcsTypeEnum;

    @JsonIgnore
    @Column(name = "FILE_PRCS_STS_KEY")
    private Integer filePrcsStsKey;

    @Transient
    @NonNull
    private FilePrcsStatus filePrcsStatus;


    @Column(name = "FILE_SIZE")
    private Long fileSize;

    @Column(name = "ATTEMPTS")
    private Integer attempts;

    @Column(name = "TOTAL_COUNT")
    private Integer totalCount;

    @Column(name = "PRNT_FILE_PRCS_KEY")
    private Long prntFilePrcsKey;

    @Column(name = "SOURCE_SYSTEM")
    @Size(max = 100)
    private String sourceSystem;

    @Column(name = "RUN_ID")
    private String runId;

    @Column(name = "RETRY_COUNT")
    private Long retryCount;

    @Column(name = "PRCS_TRIGGER")
    private String prcsTrigger;
}
