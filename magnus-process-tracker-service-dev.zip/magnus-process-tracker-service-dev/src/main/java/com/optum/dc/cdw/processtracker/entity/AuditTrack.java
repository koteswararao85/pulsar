package com.optum.dc.cdw.processtracker.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.Column;
import jakarta.persistence.MappedSuperclass;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@MappedSuperclass
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public abstract class AuditTrack {

    @JsonIgnore
    @Column(name = "INSRT_DTTM")
    private LocalDateTime insrtDttm;

    @NotNull
    @Column(name = "INSRT_USER_ID", length = 20)
    @Size(max = 20)
    private String insrtUserId;

    @JsonIgnore
    @Column(name = "UPDT_DTTM")
    private LocalDateTime updtDttm;

    @Column(name = "UPDT_USER_ID", length = 20)
    private String updtUserId;

    public AuditTrack(LocalDateTime insrtDttm, String insrtUserId) {
        this.insrtDttm=insrtDttm;
        this.insrtUserId=insrtUserId;
    }
}
