package com.optum.dc.cdw.processtracker.repository;

import com.optum.dc.cdw.processtracker.entity.ClientDataTopicDeploymentEnablement;
import com.optum.dc.cdw.processtracker.util.DataTopic;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface ClientDataTopicDeploymentEnablementRepository extends JpaRepository<ClientDataTopicDeploymentEnablement,Void> {
    Optional<ClientDataTopicDeploymentEnablement> findBySubCliSkAndDataTopic(Long subCliSk, DataTopic dataTopic);
}
