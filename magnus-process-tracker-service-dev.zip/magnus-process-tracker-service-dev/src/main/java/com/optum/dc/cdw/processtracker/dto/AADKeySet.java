package com.optum.dc.cdw.processtracker.dto;

import com.fasterxml.jackson.annotation.JsonAlias;

import java.io.Serializable;
import java.util.ArrayList;

public class AADKeySet implements Serializable {

    @JsonAlias("keys")
    private transient ArrayList<JsonWebKey> keys = new ArrayList<>();

    public  ArrayList<JsonWebKey> getKeys() {
        return keys;
    }

    public void setKeys(ArrayList<JsonWebKey> keys) {
        this.keys = keys;
    }
}
