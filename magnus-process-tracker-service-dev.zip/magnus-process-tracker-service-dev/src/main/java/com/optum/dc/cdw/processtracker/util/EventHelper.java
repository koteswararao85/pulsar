package com.optum.dc.cdw.processtracker.util;

import com.optum.dc.cdw.processtracker.entity.FilePrcsTrackError;
import com.optum.dc.cdw.processtracker.model.Event;
import com.optum.dc.cdw.processtracker.model.EventBody;
import com.optum.dc.cdw.processtracker.model.EventHeader;
import com.optum.dc.cdw.processtracker.service.KafkaService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.UUID;

@Component
@Slf4j
public class EventHelper {

    @Autowired
    private KafkaService kafkaService;

    private static final ZoneId CHICAGO_ZONE_ID = ZoneId.of("America/Chicago");
    private static final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    public void sendEventIfCopiedToDatahub(String filename, FilePrcsStatus filePrcsStatus) {
            String dataType = FileBundlingHelper.determineEventType(filename, true);
            if (dataType != null) {
                String type = dataType;
                Event event = new Event();

                EventHeader eventHeader = new EventHeader();
                eventHeader.setEventId(UUID.randomUUID().toString());
                eventHeader.setParentEventId("");
                eventHeader.setCorrelationId("");
                eventHeader.setTimestamp(ZonedDateTime.now(CHICAGO_ZONE_ID).format(formatter));
                eventHeader.setCategory("DataIntake");
                eventHeader.setType(type);
                eventHeader.setPublisher("Magnus");

                EventBody eventBody = new EventBody();
                eventBody.setCliSk(-1);
                eventBody.setSubCliSk(-1);
                eventBody.setClntGuid("");
                eventBody.setSubClntGuid("");
                String additionalInfo = "[fileName=" + filename + "]";
                eventBody.setAdditionalInfo(additionalInfo);

                event.setEventHeader(eventHeader);
                event.setEventBody(eventBody);
                log.info("event contents {}", event);

                kafkaService.sendEvent(event);
            }

    }

public void sendFailureEvent(FilePrcsTrackError filePrcsTrackError) {
    // Determine the failure event type based on the file name
    String filename = filePrcsTrackError.getFilePrcsName();
    String failureEventType = FileBundlingHelper.determineEventType(filename, false);
    if (failureEventType != null) {
        Event event = new Event();

        // Create and populate the event header
        EventHeader eventHeader = new EventHeader();
        eventHeader.setEventId(UUID.randomUUID().toString());
        eventHeader.setParentEventId("");
        eventHeader.setCorrelationId("");
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        eventHeader.setTimestamp(ZonedDateTime.now(CHICAGO_ZONE_ID).format(formatter));
        eventHeader.setCategory("DataIntake");
        eventHeader.setType(failureEventType);
        eventHeader.setPublisher("Magnus");

        // Create and populate the event body
        EventBody eventBody = new EventBody();
        eventBody.setCliSk(-1);
        eventBody.setSubCliSk(-1);
        eventBody.setClntGuid("");
        eventBody.setSubClntGuid("");
        String additionalInfo = "[fileName=" + filename + "]";
        eventBody.setAdditionalInfo(additionalInfo);

        // Set the event header and body to the event object
        event.setEventHeader(eventHeader);
        event.setEventBody(eventBody);
        log.info("Failure event contents {}", event);

        // Send the failure event to Kafka
        kafkaService.sendEvent(event);
    }
}
}