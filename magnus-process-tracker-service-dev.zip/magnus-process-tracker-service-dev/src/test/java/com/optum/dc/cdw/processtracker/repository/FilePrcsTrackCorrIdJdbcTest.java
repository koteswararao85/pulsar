package com.optum.dc.cdw.processtracker.repository;

import com.optum.dc.cdw.processtracker.dto.EventTriggerBody;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

class FilePrcsTrackCorrIdJdbcTest {

    @Mock
    private NamedParameterJdbcTemplate jdbcTemplate;

    @InjectMocks
    private FilePrcsTrackCorrIdJdbc filePrcsTrackCorrIdJdbc;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testFindCorrIdsByFileTypeAndStatusRanked() {
        List<String> expected = Arrays.asList("file1", "file2");
        when(jdbcTemplate.queryForList(anyString(), any(MapSqlParameterSource.class), eq(String.class)))
                .thenReturn(expected);

        List<String> result = filePrcsTrackCorrIdJdbc.findCorrIdsByFileTypeAndStatusRanked("typeA", 1, "ORDER_COL", 5);
        assertEquals(expected, result);
    }

    @Test
    void testFindEventTriggerBodiesByFileTypeAndFilePrcsStsKeyAndMaxRetryCount() {
        EventTriggerBody body1 = new EventTriggerBody("file1", "event1");
        EventTriggerBody body2 = new EventTriggerBody("file2", "event2");
        List<EventTriggerBody> expected = Arrays.asList(body1, body2);

        when(jdbcTemplate.query(anyString(), any(MapSqlParameterSource.class), any(RowMapper.class)))
                .thenReturn(expected);

        List<EventTriggerBody> result = filePrcsTrackCorrIdJdbc.findEventTriggerBodiesByFileTypeAndFilePrcsStsKeyAndMaxRetryCount("typeA", 1, 3L);
        assertEquals(expected, result);
    }

}