package com.optum.dc.cdw.processtracker.service;

import com.optum.dc.cdw.processtracker.dto.FilePrcs;
import com.optum.dc.cdw.processtracker.dto.FilePrcsErrorBatch;
import com.optum.dc.cdw.processtracker.dto.FilePrcsStatusBatchUpdate;
import com.optum.dc.cdw.processtracker.dto.FilePrcsTrackUpdate;
import com.optum.dc.cdw.processtracker.entity.FilePrcsTrack;
import com.optum.dc.cdw.processtracker.entity.FilePrcsTrackCorrId;
import com.optum.dc.cdw.processtracker.entity.FilePrcsTrackError;
import com.optum.dc.cdw.processtracker.entity.FilePrcsTrackAudit;
import com.optum.dc.cdw.processtracker.exception.DataFieldsMismatch;
import com.optum.dc.cdw.processtracker.exception.DataNotFoundException;
import com.optum.dc.cdw.processtracker.repository.*;
import com.optum.dc.cdw.processtracker.util.*;
import org.junit.Rule;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.rules.ExpectedException;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mapstruct.factory.Mappers;

import static org.mockito.Mockito.*;
import static org.mockito.ArgumentMatchers.any;
import static org.junit.jupiter.api.Assertions.*;
import java.util.NoSuchElementException;

import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Sort;


import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

import static com.optum.dc.cdw.processtracker.util.FilePrcsStatus.ERROR;
import static com.optum.dc.cdw.processtracker.util.FilePrcsStatus.IN_PROGRESS;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class AppServiceTest {
    @Mock
    private FilePrcsTrackImp filePrcsTrackImp;

    @Mock
    private FilePrcsTrackErrorImp filePrcsTrackErrorImp;

    @Mock
    private FilePrcsTrackCorrIdImp filePrcsTrackCorrIdImp;

    @Mock
    private FilePrcsTrackCorrIdJdbc filePrcsTrackCorrIdJdbc;

    @Mock
    private FilePrcsTrackAuditImp filePrcsTrackAuditImp;

    @Mock
    private ClientDataTopicDeploymentEnablementRepository clientDataTopicDeploymentEnablementRepository;

    @Mock
    private EventHelper eventHelper;

    @Spy
    private FilePrcsTrackMapper filePrcsTrackMapper = Mappers.getMapper(FilePrcsTrackMapper.class);

    @InjectMocks
    private AppService appService;

    @Rule
    public final ExpectedException exception = ExpectedException.none();

    FilePrcsTrack record1=new FilePrcsTrack(LocalDateTime.now(),"string",LocalDateTime.now(),"string",12L,"string","OUT",0,0L,1,0,1L,"string","runId",10L,"prcsTrigger");
    FilePrcsTrack record2 = new FilePrcsTrack(LocalDateTime.now(), "string", LocalDateTime.now(), "User_tst", 1L, "File_name", null, null, 12L, 13, 14, 15L,"Source","runId",10L,"prcsTrigger");
    FilePrcsTrackError filePrcsTrackError=new FilePrcsTrackError(LocalDateTime.now(),"string",LocalDateTime.now(),"string",1L,2L,"prcsname","errormsg","prcsname","prcsid","srcsystem", FilePrcsStatus.ERROR);
    FilePrcsTrackCorrId filePrcsTrackCorrId=new FilePrcsTrackCorrId(LocalDateTime.now(),"string",LocalDateTime.now(),"string",1L,2L,"prcsName","urlId","runId","corrId","strAcc","filePath","fileName",3L,4L,5L,6L,"status","startTime","prcsId","clientName","clientId","fileType","lob",7L,"drtsId","drtsName","cntrctId","paidDate","origSrc","eventMsg","eventTriggerBody");

    @Test
    void addFilePrcsTrack() {
        // Case 1: Successful record creation
        FilePrcsTrack newRecord = new FilePrcsTrack();
        newRecord.setFilePrcsStatus(FilePrcsStatus.valueOf("MESSAGE_RECEIVED"));
        newRecord.setFilePrcsTypeEnum(FilePrcsType.IN);
        newRecord.setFilePrcsName("newFile");

        when(filePrcsTrackImp.saveAndFlush(any(FilePrcsTrack.class))).thenReturn(newRecord);

        FilePrcsTrack result = appService.addFilePrcsTrack(newRecord);

        // Verify result
        assertEquals(newRecord, result);
        verify(filePrcsTrackImp).saveAndFlush(newRecord);

        // Case 2: Successful duplicate record handling
        FilePrcsTrack duplicateRecord = new FilePrcsTrack();
        duplicateRecord.setFilePrcsStatus(FilePrcsStatus.valueOf("MESSAGE_RECEIVED"));
        duplicateRecord.setFilePrcsTypeEnum(FilePrcsType.IN);
        duplicateRecord.setFilePrcsName("existingFile");

        FilePrcsTrack existingRecord = new FilePrcsTrack();
        existingRecord.setFilePrcsKey(123L);
        existingRecord.setFilePrcsName("existingFile");
        existingRecord.setFilePrcsType("IN"); // Set the filePrcsType string

        when(filePrcsTrackImp.saveAndFlush(eq(duplicateRecord)))
                .thenThrow(new DataIntegrityViolationException("Duplicate entry"));
        when(filePrcsTrackImp.findByFilePrcsNameLike("existingFile"))
                .thenReturn(Optional.of(existingRecord));

        FilePrcsTrackAudit mockAudit = new FilePrcsTrackAudit();
        when(filePrcsTrackMapper.filePrcsTrackToFilePrcsTrackAudit(any(FilePrcsTrack.class)))
                .thenReturn(mockAudit);
        when(filePrcsTrackAuditImp.saveAndFlush(any(FilePrcsTrackAudit.class)))
                .thenReturn(mockAudit);

        FilePrcsTrackError mockError = new FilePrcsTrackError();
        when(filePrcsTrackMapper.filePrcsTrackToFilePrcsTrackError(any(FilePrcsTrack.class)))
                .thenReturn(mockError);
        when(filePrcsTrackErrorImp.saveAndFlush(any(FilePrcsTrackError.class)))
                .thenReturn(mockError);

        FilePrcsTrack resultDuplicate = appService.addFilePrcsTrack(duplicateRecord);

        // Verify duplicate handling results
        assertEquals(123L, resultDuplicate.getFilePrcsKey());
        assertEquals(existingRecord.getFilePrcsName(), resultDuplicate.getFilePrcsName());
        verify(filePrcsTrackAuditImp).saveAndFlush(mockAudit);
        verify(filePrcsTrackErrorImp).saveAndFlush(mockError);


        // Case 3: Edge case - duplicate detected but can't find existing record
        FilePrcsTrack missingRecord = new FilePrcsTrack();
        missingRecord.setFilePrcsName("missingFile");
        missingRecord.setFilePrcsStatus(FilePrcsStatus.valueOf("MESSAGE_RECEIVED"));
        missingRecord.setFilePrcsTypeEnum(FilePrcsType.IN);

        when(filePrcsTrackImp.saveAndFlush(eq(missingRecord)))
                .thenThrow(new DataIntegrityViolationException("Duplicate entry"));
        when(filePrcsTrackImp.findByFilePrcsNameLike("missingFile"))
                .thenReturn(Optional.empty());

        RuntimeException exception = assertThrows(
                RuntimeException.class,
                () -> appService.addFilePrcsTrack(missingRecord)
        );
        assertNotNull(exception, "Exception should be thrown when duplicate record cannot be found");
        assertEquals("Failed to handle duplicate file process track for missingFile", exception.getMessage());
        assertTrue(exception.getCause() instanceof DataNotFoundException);

        // Case 4: Edge case - error during duplicate handling (e.g., audit save fails)
        FilePrcsTrack errorHandlingRecord = new FilePrcsTrack();
        errorHandlingRecord.setFilePrcsName("errorHandlingFile");
        errorHandlingRecord.setFilePrcsStatus(FilePrcsStatus.MESSAGE_RECEIVED);
        errorHandlingRecord.setFilePrcsTypeEnum(FilePrcsType.IN);

        FilePrcsTrack existingForError = new FilePrcsTrack();
        existingForError.setFilePrcsKey(456L);
        existingForError.setFilePrcsName("errorHandlingFile");
        existingForError.setFilePrcsType("IN");

        when(filePrcsTrackImp.saveAndFlush(eq(errorHandlingRecord)))
                .thenThrow(new DataIntegrityViolationException("Duplicate entry"));
        when(filePrcsTrackImp.findByFilePrcsNameLike("errorHandlingFile"))
                .thenReturn(Optional.of(existingForError));
        when(filePrcsTrackAuditImp.saveAndFlush(any(FilePrcsTrackAudit.class)))
                .thenThrow(new RuntimeException("DB connection failed"));

        RuntimeException runtimeException = assertThrows(
                RuntimeException.class,
                () -> appService.addFilePrcsTrack(errorHandlingRecord)
        );
        assertEquals("Failed to handle duplicate file process track for errorHandlingFile", runtimeException.getMessage());
        assertTrue(runtimeException.getCause() instanceof RuntimeException);
        assertEquals("DB connection failed", runtimeException.getCause().getMessage());
    }




    @Test
    void updateFilePrcsTrack() {
        FilePrcsTrackUpdate recordUFT1 = new FilePrcsTrackUpdate();
        recordUFT1.setUpdtUserId("User_update1");
        recordUFT1.setFilePrcsKey(10L);
        recordUFT1.setFilePrcsStatus(IN_PROGRESS);
        recordUFT1.setFilePrcsName("string2");
        record1.setFilePrcsStatus(FilePrcsStatus.valueOf("MESSAGE_RECEIVED"));
        record1.setFilePrcsTypeEnum(FilePrcsType.IN);
        when(filePrcsTrackImp.save(record1)).thenReturn(record1);
        when(filePrcsTrackImp.findById(recordUFT1.getFilePrcsKey())).thenReturn(Optional.empty());
        DataNotFoundException ex1 = Assertions.assertThrows(DataNotFoundException.class,() ->{
            appService.updateFilePrcsTrack(recordUFT1);
        });
        assertEquals("FilePrcsTrack not found for given Key or Name", ex1.getMessage());
        when(filePrcsTrackImp.findById(recordUFT1.getFilePrcsKey())).thenReturn(Optional.of(record1));
        DataFieldsMismatch ex2=Assertions.assertThrows(DataFieldsMismatch.class,()->{
            appService.updateFilePrcsTrack(recordUFT1);
        });
        assertEquals("Data mismatched for given FilePrcsKey & FilePrcsName", ex2.getMessage());
        recordUFT1.setFilePrcsName(null);
        when(filePrcsTrackImp.findById(recordUFT1.getFilePrcsKey())).thenReturn(Optional.of(record1));
        DataFieldsMismatch ex3=Assertions.assertThrows(DataFieldsMismatch.class,()->{
            appService.updateFilePrcsTrack(recordUFT1);
        });
        assertEquals("Data mismatched for given FilePrcsKey & FilePrcsName", ex3.getMessage());

        record1.setFilePrcsKey(10L);
        assertEquals(appService.updateFilePrcsTrack(recordUFT1),filePrcsTrackMapper.filePrcsTrackToFilePrcsTrackUpdate(record1));
    }




    @Test
    void addFilePrcsTrackError() {
        when(filePrcsTrackErrorImp.save(filePrcsTrackError)).thenReturn(filePrcsTrackError);
        FilePrcsTrack tempRecord = new FilePrcsTrack();
        tempRecord.setFilePrcsName(filePrcsTrackError.getFilePrcsName());
        tempRecord.setFilePrcsKey(filePrcsTrackError.getFilePrcsKey());
        when(filePrcsTrackImp.findByFilePrcsNameLike(filePrcsTrackError.getFilePrcsName())).thenReturn(Optional.of(tempRecord));
        FilePrcsTrackUpdate trackUpdate = filePrcsTrackMapper.filePrcsTrackErrorToFilePrcsTrackUpdate(filePrcsTrackError);
        trackUpdate.setFilePrcsStatus(ERROR);
        assertEquals(appService.addFilePrcsTrackError(filePrcsTrackError), filePrcsTrackError);
    }

    @Test
    void addFilePrcsTrackCorrId() {
        when(filePrcsTrackCorrIdImp.save(filePrcsTrackCorrId)).thenReturn(filePrcsTrackCorrId);
        assertEquals(appService.addFilePrcsTrackCorrId(filePrcsTrackCorrId),filePrcsTrackCorrId);
    }

    @Test
    void trackAndCreateFilePrcsKey() {
        FilePrcs recordTCI1 = new FilePrcs();
        recordTCI1.setFilePrcsName("File name");
        recordTCI1.setCorrelationId("Correlation Id");
        recordTCI1.setInsrtUserId("Insert user id");
        recordTCI1.setFilePrcsTypeEnum(FilePrcsType.valueOf("OUT"));
        recordTCI1.setFilePrcsStatus(FilePrcsStatus.valueOf("COPIED_TO_BRONZE"));
        FilePrcsTrack recordTCI1R = new FilePrcsTrack();
        recordTCI1R.setFilePrcsName("File name");
        recordTCI1R.setInsrtUserId("Insert user id");
        recordTCI1R.setFilePrcsKey(1L);
        FilePrcsTrack filePrcsTrack=filePrcsTrackMapper.filePrcsToFilePrcsTrack(recordTCI1);
        when(filePrcsTrackImp.saveAndFlush(filePrcsTrack)).thenReturn(filePrcsTrack);
        assertEquals(appService.addFilePrcsTrack(filePrcsTrack),filePrcsTrack);
        FilePrcsTrackCorrId filePrcsTrackCorrId1=filePrcsTrackMapper.filePrcsToFilePrcsTrackCorrID(recordTCI1);
        filePrcsTrackCorrId1.setFilePrcsKey(filePrcsTrack.getFilePrcsKey());
        when(filePrcsTrackCorrIdImp.save(filePrcsTrackCorrId1)).thenReturn(filePrcsTrackCorrId1);
        assertEquals(appService.addFilePrcsTrackCorrId(filePrcsTrackCorrId1),filePrcsTrackCorrId1);
        assertEquals(appService.trackAndCreateFilePrcsKey(recordTCI1),filePrcsTrack);
    }

    @Test
    void batchUpdateFilePrcsTrack(){
        FilePrcsStatusBatchUpdate filePrcsStatusBatchUpdate=new FilePrcsStatusBatchUpdate();
        filePrcsStatusBatchUpdate.setFilePrcsNameList(List.of(new String[]{"straing_1", "string_2"}));
        filePrcsStatusBatchUpdate.setFilePrcsStatus(IN_PROGRESS);
        filePrcsStatusBatchUpdate.setUpdtUserId("usr_id");
        when(filePrcsTrackImp.updateUpdtUserIdAndUpdtDttmAndFilePrcsStsKeyAndBatchRunIdByFilePrcsNameIn(eq(filePrcsStatusBatchUpdate.getUpdtUserId()),any(),eq(filePrcsStatusBatchUpdate.getFilePrcsStatus().getValue()),any(),eq(filePrcsStatusBatchUpdate.getFilePrcsNameList()))).thenReturn(2);
        assertEquals(2,appService.batchUpdateFilePrcsTrack(filePrcsStatusBatchUpdate));
    }

    @Test
    void getFileNamesByFileTyepAndFilePrcsStsKey() {
        List<FilePrcsTrackCorrId> filePrcsTrackCorrIdList = new ArrayList<>();
        filePrcsTrackCorrIdList.add(filePrcsTrackCorrId);
        List<String> stringList = new ArrayList<>();
        stringList.add("file_1");
        stringList.add("file_2");
        when(filePrcsTrackCorrIdJdbc.findCorrIdsByFileTypeAndStatusRanked("opsi", 0,"RUN_ID",0)).thenReturn(stringList);
        assertEquals(stringList,appService.getFileNamesByFileTyepAndFilePrcsStsKey("opsi", "MESSAGE_RECEIVED", FilePrcsTrackCorrIdColumnsEnum.RUN_ID,true,0));
        Sort sort = Sort.by(Sort.Direction.ASC, "runID");
        when(filePrcsTrackCorrIdImp.findCorrIdsByFileTypeAndStatus("opsi", 0, sort)).thenReturn(stringList);
        assertEquals(stringList,appService.getFileNamesByFileTyepAndFilePrcsStsKey("opsi", "MESSAGE_RECEIVED", FilePrcsTrackCorrIdColumnsEnum.RUN_ID,false,2));
        assertThrows(IllegalArgumentException.class,()->appService.getFileNamesByFileTyepAndFilePrcsStsKey("opsi", "WRONG_STATUS", FilePrcsTrackCorrIdColumnsEnum.RUN_ID,false,0));
    }

    @Test
    void batchTrackAndCreate(){
        FilePrcs recordTCI1 = new FilePrcs();
        recordTCI1.setFilePrcsKey(1L);
        recordTCI1.setFilePrcsName("File name");
        recordTCI1.setCorrelationId("Correlation Id");
        recordTCI1.setInsrtUserId("Insert user id");
        recordTCI1.setInsrtDttm(LocalDateTime.now());
        recordTCI1.setUpdtDttm(LocalDateTime.now());
        recordTCI1.setFilePrcsTypeEnum(FilePrcsType.valueOf("OUT"));
        recordTCI1.setFilePrcsStatus(FilePrcsStatus.valueOf("COPIED_TO_BRONZE"));
        FilePrcs recordTCI2 = new FilePrcs();
        recordTCI2.setFilePrcsKey(2L);
        recordTCI2.setFilePrcsName("File name 2");
        recordTCI2.setCorrelationId("Correlation Id");
        recordTCI2.setInsrtUserId("Insert user id");
        recordTCI2.setInsrtDttm(LocalDateTime.now());
        recordTCI2.setUpdtDttm(LocalDateTime.now());
        recordTCI2.setFilePrcsTypeEnum(FilePrcsType.valueOf("IN"));
        recordTCI2.setFilePrcsStatus(FilePrcsStatus.valueOf("COPIED_TO_BRONZE"));
        Collection<FilePrcs> filePrcsCollection = List.of(recordTCI1,recordTCI2);
        Collection<FilePrcsTrack> resultFilePrcsTrack = filePrcsCollection.stream().map(filePrcsTrackMapper::filePrcsToFilePrcsTrack).collect(Collectors.toList());
        when(filePrcsTrackImp.saveAll(any())).thenReturn(resultFilePrcsTrack.stream().toList());
        assertEquals(appService.batchTrackAndCreateFilePrcs(filePrcsCollection),resultFilePrcsTrack);
        when(filePrcsTrackImp.saveAll(any())).thenThrow(new DataIntegrityViolationException("Testing"));
        assertThrows(DataIntegrityViolationException.class,()->appService.batchTrackAndCreateFilePrcs(filePrcsCollection));
    }

    @Test
    void batchErrorInsert() {
        List<String> fileNames = new ArrayList<>();
        fileNames.add("file1");
        fileNames.add("error");

        // Create FilePrcsErrorBatch with FilePrcsStatus.ERROR explicitly set
        FilePrcsErrorBatch filePrcsErrorBatch = new FilePrcsErrorBatch("insrtUserId", fileNames, "errorMsg", "PrcsNm", "prcsId", "batchrunId", FilePrcsStatus.ERROR);

        List<FilePrcsTrack> filePrcsTrackList = new ArrayList<>();
        filePrcsTrackList.add(record1);
        filePrcsTrackList.add(record2);

        when(filePrcsTrackImp.findByFilePrcsNameIn(eq(fileNames))).thenReturn(filePrcsTrackList);
        when(filePrcsTrackImp.updateUpdtUserIdAndUpdtDttmAndFilePrcsStsKeyAndBatchRunIdByFilePrcsNameIn(
                eq(filePrcsErrorBatch.getInsrtUserId()),
                any(LocalDateTime.class),
                eq(FilePrcsStatus.ERROR.getValue()),
                eq(filePrcsErrorBatch.getBatchRunId()),
                eq(fileNames))).thenReturn(2);

        when(filePrcsTrackErrorImp.saveAllAndFlush(any())).thenReturn(any());

        assertEquals(filePrcsErrorBatch.getFilePrcsNameList(), appService.batchErrorInsert(filePrcsErrorBatch));

        // Test with null FilePrcsStatus (should default to ERROR)
        FilePrcsErrorBatch filePrcsErrorBatchNullStatus = new FilePrcsErrorBatch("insrtUserId", fileNames, "errorMsg", "PrcsNm", "prcsId", "batchrunId", null);

        when(filePrcsTrackImp.updateUpdtUserIdAndUpdtDttmAndFilePrcsStsKeyAndBatchRunIdByFilePrcsNameIn(
                eq(filePrcsErrorBatchNullStatus.getInsrtUserId()),
                any(LocalDateTime.class),
                eq(FilePrcsStatus.ERROR.getValue()),
                eq(filePrcsErrorBatchNullStatus.getBatchRunId()),
                eq(fileNames))).thenReturn(2);

        assertEquals(filePrcsErrorBatchNullStatus.getFilePrcsNameList(), appService.batchErrorInsert(filePrcsErrorBatchNullStatus));
    }

    @Test
    void testDetermineEventType() {

        // Test cases for PROVIDER_
        assertEquals("Provider.MagnusLoad.Success", FileBundlingHelper.determineEventType("PROVIDER_ABC", true));
        assertEquals("Provider.MagnusLoad.Failed", FileBundlingHelper.determineEventType("PROVIDER_ABC", false));

        // Test cases for MEMBER_BV_
        assertEquals("MemberBV.MagnusLoad.Success", FileBundlingHelper.determineEventType("MEMBER_BV_123_ABC", true));
        assertEquals("MemberBV.MagnusLoad.Failed", FileBundlingHelper.determineEventType("MEMBER_BV_123_ABC", false));

        // Test cases for MEMBER_ without GLBID
        assertEquals("Member.MagnusLoad.Success", FileBundlingHelper.determineEventType("MEMBER_ABC", true));
        assertEquals("Member.MagnusLoad.Failed", FileBundlingHelper.determineEventType("MEMBER_ABC", false));

        // Test cases for MEMBER_ with GLBID
        assertEquals("GlobalId.MagnusLoad.Success", FileBundlingHelper.determineEventType("MEMBER_GLBID_ABC", true));
        assertEquals("GlobalId.MagnusLoad.Failed", FileBundlingHelper.determineEventType("MEMBER_GLBID_ABC", false));

        // Test cases for MINCLM_
        assertEquals("MedicalClaims.MagnusLoad.Success", FileBundlingHelper.determineEventType("MINCLM_ABC", true));
        assertEquals("MedicalClaims.MagnusLoad.Failed", FileBundlingHelper.determineEventType("MINCLM_ABC", false));

        // Test cases for PHARMACY_
        assertEquals("PharmacyClaims.MagnusLoad.Success", FileBundlingHelper.determineEventType("PHARMACY_ABC", true));
        assertEquals("PharmacyClaims.MagnusLoad.Failed", FileBundlingHelper.determineEventType("PHARMACY_ABC", false));

        // Test cases for LAB_
        assertEquals("LabResults.MagnusLoad.Success", FileBundlingHelper.determineEventType("LAB_ABC", true));
        assertEquals("LabResults.MagnusLoad.Failed", FileBundlingHelper.determineEventType("LAB_ABC", false));

        // Test cases for RISKGAPS_
        assertEquals("RiskGaps.MagnusLoad.Success", FileBundlingHelper.determineEventType("RISKGAPS_ABC", true));
        assertEquals("RiskGaps.MagnusLoad.Failed", FileBundlingHelper.determineEventType("RISKGAPS_ABC", false));

        // Test cases for QUALITYGAPS_
        assertEquals("QualityGaps.MagnusLoad.Success", FileBundlingHelper.determineEventType("QUALITYGAPS_ABC", true));
        assertEquals("QualityGaps.MagnusLoad.Failed", FileBundlingHelper.determineEventType("QUALITYGAPS_ABC", false));

        // Test cases for PLAN_
        assertEquals("Plan.MagnusLoad.Success", FileBundlingHelper.determineEventType("PLAN_ABC", true));
        assertEquals("Plan.MagnusLoad.Failed", FileBundlingHelper.determineEventType("PLAN_ABC", false));

        // Test case for unknown prefix
        assertEquals(null, FileBundlingHelper.determineEventType("UNKNOWN_ABC", true));
    }
}

