package com.optum.dc.cdw.processtracker.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import com.optum.dc.cdw.processtracker.TestConfig;
import com.optum.dc.cdw.processtracker.dto.EventTriggerBody;
import com.optum.dc.cdw.processtracker.dto.FilePrcs;
import com.optum.dc.cdw.processtracker.dto.FilePrcsErrorBatch;
import com.optum.dc.cdw.processtracker.dto.FilePrcsStatusBatchUpdate;
import com.optum.dc.cdw.processtracker.dto.FilePrcsTrackUpdate;
import com.optum.dc.cdw.processtracker.entity.FilePrcsTrack;
import com.optum.dc.cdw.processtracker.entity.FilePrcsTrackCorrId;
import com.optum.dc.cdw.processtracker.entity.FilePrcsTrackError;
import com.optum.dc.cdw.processtracker.exception.DataFieldsMismatch;
import com.optum.dc.cdw.processtracker.exception.DataNotFoundException;
import com.optum.dc.cdw.processtracker.service.AppService;
import com.optum.dc.cdw.processtracker.util.FilePrcsStatus;
import com.optum.dc.cdw.processtracker.util.FilePrcsTrackCorrIdColumnsEnum;
import com.optum.dc.cdw.processtracker.util.FilePrcsType;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import static org.hamcrest.CoreMatchers.containsString;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;


@WebMvcTest(AppController.class)
@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = TestConfig.class)
@ActiveProfiles("junit")
class AppControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private AppService service;

    static ObjectMapper objectMapper = new ObjectMapper();

    FilePrcsTrack record1 = new FilePrcsTrack(LocalDateTime.now(), "User_tst", LocalDateTime.now(), "User_tst", null, "File_name", null, null, 12L, 13, 14, 15L,"Source","runId",10L,"triggertype");

    @BeforeAll
    static void setUpMapper(){
        JavaTimeModule javaTimeModule = new JavaTimeModule();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSSSSS");
        javaTimeModule.addSerializer(LocalDateTime.class, new LocalDateTimeSerializer(formatter));
        objectMapper.registerModule(javaTimeModule);
        objectMapper.setDateFormat(new SimpleDateFormat("yyyy-MM-dd"));
    }

    @Test
    void addFileTrack() throws Exception {
        record1.setFilePrcsStatus(FilePrcsStatus.valueOf("MESSAGE_RECEIVED"));
        record1.setFilePrcsTypeEnum(FilePrcsType.IN);
        when(service.addFilePrcsTrack(record1)).thenReturn(record1);
        String jsonRecord1 = objectMapper.writeValueAsString(record1);
        mockMvc.perform(post("/api/v1/processtrkr/addFilePrcsTrack")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(jsonRecord1))
                .andExpect(status().is2xxSuccessful())
                .andExpect(content().json(jsonRecord1))
                .andReturn();

        // Validation Error
        String unformatted_json = objectMapper.writeValueAsString(new FilePrcsTrack());
        mockMvc.perform(post("/api/v1/processtrkr/addFilePrcsTrack")
                        .contentType("application/json")
                        .content(unformatted_json))
                .andExpect(status().isBadRequest())
                .andExpect(content().string(containsString("JSON parse error")))
                .andReturn();

        // Data Integrity
        FilePrcsTrack recordDI1 = new FilePrcsTrack();
        recordDI1.setFilePrcsName("Existing_FileName");
        recordDI1.setInsrtUserId("Test_user");
        recordDI1.setFilePrcsTypeEnum(FilePrcsType.IN);
        recordDI1.setFilePrcsStatus(FilePrcsStatus.MESSAGE_RECEIVED);
        String jsonRecordDI = objectMapper.writeValueAsString(recordDI1);
        when(service.addFilePrcsTrack(recordDI1)).thenThrow(new DataIntegrityViolationException("Data Violation"));
        mockMvc.perform(post("/api/v1/processtrkr/addFilePrcsTrack")
                        .contentType("application/json")
                        .content(jsonRecordDI))
                .andExpect(status().isBadRequest())
                .andExpect(content().string("Data Violation"))
                .andReturn();

        //Lenght check
        FilePrcsTrack recordDI2 = new FilePrcsTrack();
        recordDI2.setFilePrcsName("DI_Filename");
        recordDI2.setInsrtUserId("Test_user2");
        recordDI2.setFilePrcsTypeEnum(FilePrcsType.IN);
        recordDI2.setFilePrcsStatus(FilePrcsStatus.MESSAGE_RECEIVED);
        recordDI2.setSourceSystem("tMM!Z3c$aWJP3ZSCt@yy&u!4ANQaNrmFr!&Z!pY@d%t=dYsuD!YhndBJM7#RtkD+9!RZ6M&Wq!$aXb=gaZpyZxp%W8XgWyMMnbjFsdjndsjfn");
        String jsonLengthTest = objectMapper.writeValueAsString(recordDI2);
        mockMvc.perform(post("/api/v1/processtrkr/addFilePrcsTrack")
                        .contentType("application/json")
                        .content(jsonLengthTest))
                .andExpect(status().isBadRequest())
                .andExpect(content().json("{\"sourceSystem\":\"size must be between 0 and 100\"}"))
                .andReturn();
    }

    @Test
    void updateFileTrack() throws Exception {
        FilePrcsTrackUpdate recordUFT1 = new FilePrcsTrackUpdate();
        recordUFT1.setUpdtUserId("User_update1");
        recordUFT1.setFilePrcsKey(10L);
        recordUFT1.setFilePrcsName("Respective File name");
        recordUFT1.setFilePrcsStatus(FilePrcsStatus.MESSAGE_RECEIVED);
        String jsonRecordUTF1 = objectMapper.writeValueAsString(recordUFT1);
        when(service.updateFilePrcsTrack(recordUFT1)).thenReturn(recordUFT1);
        mockMvc.perform(post("/api/v1/processtrkr/updateFilePrcsTrack")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(jsonRecordUTF1))
                .andExpect(status().is2xxSuccessful())
                .andExpect(content().json(jsonRecordUTF1))
                .andReturn();

        //Update user is null (Validation)
        FilePrcsTrackUpdate recordUFT2 = new FilePrcsTrackUpdate();
        recordUFT2.setFilePrcsKey(10L);
        recordUFT2.setFilePrcsName("UserID not mentioned");
        String jsonRecordUTF2 = objectMapper.writeValueAsString(recordUFT2);
        mockMvc.perform(post("/api/v1/processtrkr/updateFilePrcsTrack")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(jsonRecordUTF2))
                .andExpect(status().isBadRequest())
                .andReturn();

        //Data Not found for both key & name
        FilePrcsTrackUpdate recordUTF3 = new FilePrcsTrackUpdate();
        recordUTF3.setFilePrcsKey(404L);
        recordUTF3.setUpdtUserId("User_tst3");
        recordUTF3.setFilePrcsName("Not Present");
        when(service.updateFilePrcsTrack(recordUTF3)).thenThrow(new DataNotFoundException("Not found"));
        String jsonRecordUTF3 = objectMapper.writeValueAsString(recordUTF3);
        mockMvc.perform(post("/api/v1/processtrkr/updateFilePrcsTrack")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(jsonRecordUTF3))
                .andExpect(status().isNotFound())
                .andExpect(content().string("Not found"))
                .andReturn();

        //Data Mismatch(i.e different key and name values)
        FilePrcsTrackUpdate recordUTF4 = new FilePrcsTrackUpdate();
        recordUTF4.setFilePrcsKey(422L);
        recordUTF4.setFilePrcsName("Data Mismatch");
        recordUTF4.setUpdtUserId("User tst4");
        when(service.updateFilePrcsTrack(recordUTF4)).thenThrow(new DataFieldsMismatch("Fields mismatch"));
        String jsonRecordUTF4 = objectMapper.writeValueAsString(recordUTF4);
        mockMvc.perform(post("/api/v1/processtrkr/updateFilePrcsTrack")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(jsonRecordUTF4))
                .andExpect(status().isUnprocessableEntity())
                .andExpect(content().string("Fields mismatch"))
                .andReturn();


    }

    @Test
    void addFilePrcsTrackError() throws Exception {
        FilePrcsTrackError recordTE1 = new FilePrcsTrackError(null, "User Id insert", null, "Update userId", null, 11L, "File name", "Error msg", "Process num", "Process Id", "Source System", FilePrcsStatus.ERROR);
        // Ensure errorStatus is set properly
        if (recordTE1.getFilePrcsStatus() == null) {
            recordTE1.setFilePrcsStatus(FilePrcsStatus.ERROR);
        }

        when(service.addFilePrcsTrackError(recordTE1)).thenReturn(recordTE1);
        String jsonRecordTE1 = objectMapper.writeValueAsString(recordTE1);
        mockMvc.perform(post("/api/v1/processtrkr/addFilePrcsTrackError")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(jsonRecordTE1))
                .andExpect(status().is2xxSuccessful())
                .andExpect(content().json(jsonRecordTE1))
                .andReturn();

        // Test with explicit error status parameter
        when(service.addFilePrcsTrackError(recordTE1)).thenReturn(recordTE1);
        mockMvc.perform(post("/api/v1/processtrkr/addFilePrcsTrackError")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(jsonRecordTE1)
                        .param("errorStatus", "ERROR"))
                .andExpect(status().is2xxSuccessful())
                .andExpect(content().json(jsonRecordTE1))
                .andReturn();

        String unformatted_json = objectMapper.writeValueAsString(new FilePrcsTrackError());
        mockMvc.perform(post("/api/v1/processtrkr/addFilePrcsTrackError")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(unformatted_json))
                .andExpect(status().isBadRequest())
                .andExpect(content().string(containsString("must not be null")))
                .andReturn();

        FilePrcsTrackError recordTE2 = new FilePrcsTrackError();
        recordTE2.setFilePrcsKey(12L);
        recordTE2.setFilePrcsName("TE_File2");
        recordTE2.setErrorMsg("Error_msg");
        recordTE2.setInsrtUserId("This User Id is more than 20 size");
        // Ensure errorStatus is set for recordTE2 as well
        recordTE2.setFilePrcsStatus(FilePrcsStatus.ERROR);

        String jsonLengthCheck = objectMapper.writeValueAsString(recordTE2);
        mockMvc.perform(post("/api/v1/processtrkr/addFilePrcsTrackError")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(jsonLengthCheck))
                .andExpect(status().isBadRequest())
                .andReturn();
    }


    @Test
    void trackAndCreateFilePrcsKey() throws Exception {
        FilePrcs recordTCI1 = new FilePrcs();
        recordTCI1.setFilePrcsName("File name");
        recordTCI1.setCorrelationId("Correlation Id");
        recordTCI1.setInsrtUserId("Insert user id");
        FilePrcsTrack recordTCI1R = new FilePrcsTrack();
        recordTCI1R.setFilePrcsName("File name");
        recordTCI1R.setInsrtUserId("Insert user id");
        when(service.trackAndCreateFilePrcsKey(recordTCI1)).thenReturn(recordTCI1R);
        String jsonRecordTCI1 = objectMapper.writeValueAsString(recordTCI1);
        String jsonRecordTCI1R = objectMapper.writeValueAsString(recordTCI1R);
        mockMvc.perform(post("/api/v1/processtrkr/trackAndCreateFilePrcsKey")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(jsonRecordTCI1))
                .andExpect(status().is2xxSuccessful())
                .andExpect(content().json(jsonRecordTCI1R))
                .andReturn();

        String unformatted_json = objectMapper.writeValueAsString(new FilePrcs());
        mockMvc.perform(post("/api/v1/processtrkr/trackAndCreateFilePrcsKey")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(unformatted_json))
                .andExpect(status().isBadRequest())
                .andExpect(content().string(containsString("must not be null")))
                .andReturn();

        FilePrcs recordTCI2 = new FilePrcs();
        recordTCI2.setUpdtUserId("Test_Usr");
        recordTCI2.setInsrtUserId("Test_Usr");
        recordTCI2.setRunID("Testing RunID with Length constraint of length exceeding 64 characters");
        String jsonLengthCheck = objectMapper.writeValueAsString(recordTCI2);
        mockMvc.perform(post("/api/v1/processtrkr/trackAndCreateFilePrcsKey")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(jsonLengthCheck))
                .andExpect(status().isBadRequest())
                .andReturn();
    }

    @Test
    void batchUpdateTest() throws Exception {
        FilePrcsStatusBatchUpdate batchUpdate = new FilePrcsStatusBatchUpdate();
        batchUpdate.setFilePrcsNameList(List.of("File1","File2","File3","File4"));
        batchUpdate.setUpdtUserId("User_id");
        batchUpdate.setFilePrcsStatus(FilePrcsStatus.IN_PROGRESS);
        String batchUpdate_json = objectMapper.writeValueAsString(batchUpdate);
        when(service.batchUpdateFilePrcsTrack(batchUpdate)).thenReturn(4);
        mockMvc.perform(post("/api/v1/processtrkr/batchUpdateFilePrcsTrack")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(batchUpdate_json))
                .andExpect(status().is2xxSuccessful())
                .andExpect(content().json("4"))
                .andReturn();
        batchUpdate.setUpdtUserId(null);
        String null_json = objectMapper.writeValueAsString(batchUpdate);
        mockMvc.perform(post("/api/v1/processtrkr/batchUpdateFilePrcsTrack")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(null_json))
                .andExpect(status().isBadRequest())
                .andExpect(content().string(containsString("must not be null")))
                .andReturn();
        String status_json = "{\"filePrcsNameList\":[\"File1\",\"File2\",\"File3\",\"File4\"],\"updtUserId\":\"User_id\",\"filePrcsStatus\":\"NOT_IN_PROGRESS\"}";
        mockMvc.perform(post("/api/v1/processtrkr/batchUpdateFilePrcsTrack")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(status_json))
                .andExpect(status().isBadRequest())
                .andExpect(content().string(containsString("not one of the values accepted for Enum class:")))
                .andReturn();
    }

    @Test
    void batchInsert() throws Exception {
        FilePrcs recordTCI1 = new FilePrcs();
        recordTCI1.setFilePrcsName("File name");
        recordTCI1.setCorrelationId("Correlation Id");
        recordTCI1.setInsrtUserId("Insert user id");
        Collection<FilePrcs> input = List.of(recordTCI1);
        String jsonRecordTCI1 = objectMapper.writeValueAsString(input);
        Collection<FilePrcsTrack> output = List.of(new FilePrcsTrack());
        when(service.batchTrackAndCreateFilePrcs(input)).thenReturn(output);
        mockMvc.perform(post("/api/v1/processtrkr/batchCreateAndTrack")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(jsonRecordTCI1))
                .andExpect(status().is2xxSuccessful())
                .andReturn();
    }

    @Test
    void batchFetch() throws Exception {
        List<String> filePrcsNamesList = new ArrayList<>();
        filePrcsNamesList.add("file_1");
        filePrcsNamesList.add("file_2");
        when(service.getFileNamesByFileTyepAndFilePrcsStsKey("Filetype","MESSAGE_RECEIVED", FilePrcsTrackCorrIdColumnsEnum.valueOf("RUN_ID"),false,0)).thenReturn(filePrcsNamesList);
        mockMvc.perform(get("/api/v1/processtrkr/batchFetchFilePrcsTrackCorrIdByStsKey")
                        .param("fileType","Filetype")
                        .param("FilePrcsStatus", String.valueOf(FilePrcsStatus.MESSAGE_RECEIVED))
                        .param("getOnlyOneClientFileInBatch","false"))
                .andExpect(status().is2xxSuccessful())
                .andReturn();
    }

    @Test
    void batchError() throws Exception {
        List<String> fileNames = new ArrayList<>();
        FilePrcsErrorBatch filePrcsErrorBatch = new FilePrcsErrorBatch("insrtUserId",fileNames,"errorMsg","PrcsNm","prcsId","batchrunId");
        when(service.batchErrorInsert(filePrcsErrorBatch)).thenReturn(filePrcsErrorBatch.getFilePrcsNameList());
        String jsonInput = objectMapper.writeValueAsString(filePrcsErrorBatch);
        mockMvc.perform(post("/api/v1/processtrkr/batchAddFilePrcsError")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(jsonInput))
                .andExpect(status().is2xxSuccessful())
                .andReturn();
    }

    @Test
    void healthCheck() throws Exception {
        mockMvc.perform(get("/api/v1/processtrkr/health-check")).andExpect(status().is2xxSuccessful()).andReturn();
    }

    @Test
    void increaseRetryCountByFilePrcsNameIn_shouldReturnCount() throws Exception {
        List<String> fileNames = List.of("file1", "file2");
        when(service.increaseRetryCountByFilePrcsNameIn(fileNames)).thenReturn(2);

        String jsonRequest = objectMapper.writeValueAsString(fileNames);

        mockMvc.perform(post("/api/v1/processtrkr/increaseRetryCountForFileNames")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(jsonRequest))
                .andExpect(status().isOk())
                .andExpect(content().json("2"));
    }

    @Test
    void findEventTriggerBodiesByFileTypeAndFilePrcsStsKeyAndMaxRetryCount_shouldReturnList() throws Exception {
        List<EventTriggerBody> result = List.of(new EventTriggerBody());
        when(service.findEventTriggerBodiesByFileTypeAndFilePrcsStsKeyAndMaxRetryCount("type", 0, 3L)).thenReturn(result);

        mockMvc.perform(get("/api/v1/processtrkr/batchFetchEventTriggerBodies")
                        .param("fileType", "type")
                        .param("maxRetryCount", "3"))
                .andExpect(status().isOk());
    }
}