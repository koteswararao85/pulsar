package com.optum.dc.cdw.processtracker.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.UNPROCESSABLE_ENTITY)
public class DataFieldsMismatch extends RuntimeException{

    public DataFieldsMismatch(String msg){
        super(msg);
    }
}
