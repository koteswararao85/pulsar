package com.optum.dc.cdw.processtracker.model;

public class EventHeader {

    String eventId;
    String parentEventId;
    String correlationId;
    String timestamp;
    String category;
    String type;
    String publisher;

    public EventHeader() {

    }


    public EventHeader(String eventId, String parentEventId, String correlationId, String timestamp, String category,
                       String type, String publisher) {
        super();
        this.eventId = eventId;
        this.parentEventId = parentEventId;
        this.correlationId = correlationId;
        this.timestamp = timestamp;
        this.category = category;
        this.type = type;
        this.publisher = publisher;
    }

    /**
     * @return the eventId
     */
    public String getEventId() {
        return eventId;
    }
    /**
     * @param eventId the eventId to set
     */
    public void setEventId(String eventId) {
        this.eventId = eventId;
    }
    /**
     * @return the parentEventId
     */
    public String getParentEventId() {
        return parentEventId;
    }
    /**
     * @param parentEventId the parentEventId to set
     */
    public void setParentEventId(String parentEventId) {
        this.parentEventId = parentEventId;
    }
    /**
     * @return the correlationId
     */
    public String getCorrelationId() {
        return correlationId;
    }
    /**
     * @param correlationId the correlationId to set
     */
    public void setCorrelationId(String correlationId) {
        this.correlationId = correlationId;
    }
    /**
     * @return the timestamp
     */
    public String getTimestamp() {
        return timestamp;
    }
    /**
     * @param timestamp the timestamp to set
     */
    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }
    /**
     * @return the category
     */
    public String getCategory() {
        return category;
    }
    /**
     * @param category the category to set
     */
    public void setCategory(String category) {
        this.category = category;
    }
    /**
     * @return the type
     */
    public String getType() {
        return type;
    }
    /**
     * @param type the type to set
     */
    public void setType(String type) {
        this.type = type;
    }
    /**
     * @return the publisher
     */
    public String getPublisher() {
        return publisher;
    }
    /**
     * @param publisher the publisher to set
     */
    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }


    @Override
    public String toString() {
        return "EventHeader [eventId=" + eventId + ", parentEventId=" + parentEventId + ", correlationId="
                + correlationId + ", timestamp=" + timestamp + ", category=" + category + ", type=" + type
                + ", publisher=" + publisher + "]";
    }

}
