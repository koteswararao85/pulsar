package com.optum.dc.cdw.processtracker.util;

public enum DataTopic {
    PLAN,
    PROVIDER,
    MEMBER,
    LAB,
    QUALITY_CPA,
    RISK_CPA,
    PSEUDO_CLAIMS,
    PHARMACY_BV,
    PHARMACY,
    MEMBERGLOBALID,
    CLAIM,
    MEMBER_BV,
    MEDICARE_MEMBERGLOBALID
}
