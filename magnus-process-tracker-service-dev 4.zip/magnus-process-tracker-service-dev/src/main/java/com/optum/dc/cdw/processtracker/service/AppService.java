package com.optum.dc.cdw.processtracker.service;

import com.optum.dc.cdw.processtracker.dto.*;
import com.optum.dc.cdw.processtracker.entity.*;
import com.optum.dc.cdw.processtracker.exception.DataFieldsMismatch;
import com.optum.dc.cdw.processtracker.exception.DataNotFoundException;
import com.optum.dc.cdw.processtracker.repository.*;
import com.optum.dc.cdw.processtracker.util.DataTopic;
import com.optum.dc.cdw.processtracker.util.FilePrcsStatus;
import com.optum.dc.cdw.processtracker.util.FilePrcsTrackCorrIdColumnsEnum;
import com.optum.dc.cdw.processtracker.util.FilePrcsTrackMapper;
import com.optum.dc.cdw.processtracker.util.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.data.domain.Sort;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
@Slf4j
public class AppService {

    @Autowired
    private FilePrcsTrackImp filePrcsTrackImp;
    @Autowired
    private  FilePrcsTrackErrorImp filePrcsTrackErrorImp;
    @Autowired
    private  FilePrcsTrackCorrIdImp filePrcsTrackCorrIdImp;

    @Autowired
    private FilePrcsTrackAuditImp filePrcsTrackAuditImp;

    @Autowired
    private  FilePrcsTrackMapper filePrcsTrackMapper;

    @Autowired
    private FilePrcsTrackCorrIdJdbc filePrcsTrackCorrIdJdbc;

    @Autowired
    private ClientDataTopicDeploymentEnablementRepository clientDataTopicDeploymentEnablementRepository;

    @Autowired
    private EventHelper eventHelper;

    @Autowired
    private FilePrcsTrackCorrIdService filePrcsTrackCorrIdService;

    @Autowired
    private FilePrcsTrackDuplicateService filePrcsTrackDuplicateService;

    @Autowired
    private FilePrcsTrackUpdateService filePrcsTrackUpdateService;

    @Autowired
    private FilePrcsBatchService filePrcsBatchService;


    private static final ZoneId CHICAGO_ZONE_ID = ZoneId.of("America/Chicago");
    private static final String TRACKER_API_NAME = "Tracker.API";
    public FilePrcsTrack addFilePrcsTrack(FilePrcsTrack filePrcsTrack){
        filePrcsTrack.setInsrtDttm(ZonedDateTime.now(CHICAGO_ZONE_ID).toLocalDateTime());
        filePrcsTrack.setUpdtDttm(ZonedDateTime.now(CHICAGO_ZONE_ID).toLocalDateTime());
        filePrcsTrack.setFilePrcsStsKey(filePrcsTrack.getFilePrcsStatus().getValue());
        filePrcsTrack.setFilePrcsType(filePrcsTrack.getFilePrcsTypeEnum().name());
        try {
            return attemptSave(filePrcsTrack);
        }catch (DataIntegrityViolationException ex){
            log.error("DataIntegrityViolationException caught for filePrcsName: {}. Handling duplicate.", filePrcsTrack.getFilePrcsName().replace('\n', '_').replace('\r', '_'));
            return filePrcsTrackDuplicateService.handleDuplicateFilePrcsTrack(filePrcsTrack);
        }
    }
    private FilePrcsTrack attemptSave(FilePrcsTrack filePrcsTrack) {
        FilePrcsTrack savedTrack = filePrcsTrackImp.saveAndFlush(filePrcsTrack);
        log.info("file prcs track is added {}", savedTrack.getFilePrcsKey());
        savedTrack.setFilePrcsTypeEnum(filePrcsTrack.getFilePrcsTypeEnum());
        savedTrack.setFilePrcsStatus(filePrcsTrack.getFilePrcsStatus());
        return savedTrack;
    }

    

    public FilePrcsTrackUpdate updateFilePrcsTrack(FilePrcsTrackUpdate filePrcsTrackUpdate){
        return filePrcsTrackUpdateService.updateFilePrcsTrack(filePrcsTrackUpdate);
    }

    @Transactional
    public FilePrcsTrackError addFilePrcsTrackError(FilePrcsTrackError filePrcsTrackError){
        filePrcsTrackError.setInsrtDttm(ZonedDateTime.now(CHICAGO_ZONE_ID).toLocalDateTime());
        filePrcsTrackError.setFilePrcsKey(null);

        // Set default error status if not provided
        if (filePrcsTrackError.getFilePrcsStatus() == null) {
            filePrcsTrackError.setFilePrcsStatus(FilePrcsStatus.ERROR);
        }

        Optional<FilePrcsTrack> existFileTrack = filePrcsTrackImp.findByFilePrcsNameLike(filePrcsTrackError.getFilePrcsName());
        if(existFileTrack.isPresent()){
            if(filePrcsTrackError.getFilePrcsKey()!=null && existFileTrack.get().getFilePrcsKey()!=filePrcsTrackError.getFilePrcsKey()){
               log.info("incorrect filePrcsKey is provided");
            }
            if(filePrcsTrackError.getSourceSystem()!=null && existFileTrack.get().getSourceSystem()!=filePrcsTrackError.getSourceSystem()){
                log.info("incorrect sourceSystem is provided");
            }
            else {
                filePrcsTrackError.setSourceSystem(existFileTrack.get().getSourceSystem());
            }
            filePrcsTrackError.setFilePrcsKey(existFileTrack.get().getFilePrcsKey());
        }
        FilePrcsTrackError filePrcsTrackError1 =filePrcsTrackErrorImp.save(filePrcsTrackError);
        log.info("FilePrcsTrackError is added {}",filePrcsTrackError1.getFilePrcsTrackErrorSk());

        // Determine the failure event type based on the file name
        eventHelper.sendFailureEvent(filePrcsTrackError);
        FilePrcsTrackUpdate filePrcsTrackUpdate = filePrcsTrackMapper.filePrcsTrackErrorToFilePrcsTrackUpdate(filePrcsTrackError);
        try {
            updateFilePrcsTrack(filePrcsTrackUpdate);
            log.info("FilePrcsTrack is updated with status ERROR");
        }catch (Exception ex){
            log.info("Failed to Update FilePrcsTrack due to {}", ex.getMessage());
        }
        return filePrcsTrackError1;
    }

    

    public FilePrcsTrack trackAndCreateFilePrcsKey(FilePrcs filePrcs){
        FilePrcsTrack filePrcsTrack=filePrcsTrackMapper.filePrcsToFilePrcsTrack(filePrcs);
        FilePrcsTrack filePrcsTrackUpdated = addFilePrcsTrack(filePrcsTrack);

        // Only add a new CorrId record if the file track was not a duplicate.
        if (filePrcsTrackUpdated.getFilePrcsStatus() != FilePrcsStatus.DUPLICATE_FILE_NAME) {
            FilePrcsTrackCorrId filePrcsTrackCorrId = filePrcsTrackMapper.filePrcsToFilePrcsTrackCorrID(filePrcs);
            filePrcsTrackCorrId.setFilePrcsKey(filePrcsTrackUpdated.getFilePrcsKey());
            filePrcsTrackCorrIdService.addFilePrcsTrackCorrId(filePrcsTrackCorrId);
        }

        return filePrcsTrackUpdated;
    }

    @Transactional
    public int batchUpdateFilePrcsTrack(FilePrcsStatusBatchUpdate filePrcsTrackUpdateList){
        long startTime = System.currentTimeMillis();
        int updatedList = filePrcsTrackImp.updateUpdtUserIdAndUpdtDttmAndFilePrcsStsKeyAndBatchRunIdByFilePrcsNameIn(
                filePrcsTrackUpdateList.getUpdtUserId(),
                ZonedDateTime.now(CHICAGO_ZONE_ID).toLocalDateTime(),
                filePrcsTrackUpdateList.getFilePrcsStatus().getValue(),
                filePrcsTrackUpdateList.getBatchRunId(),
                filePrcsTrackUpdateList.getFilePrcsNameList()
        );
        log.error("Total Time Spent in filter is: {} MilliSeconds ", System.currentTimeMillis() - startTime);

        // Determine the success event type based on the file name and send an event for list of file names in the list if it has been copied to Datahub
        if(filePrcsTrackUpdateList.getFilePrcsStatus() != null && filePrcsTrackUpdateList.getFilePrcsStatus().getValue().equals(FilePrcsStatus.COPIED_TO_DATAHUB.getValue())){
        for (String fileName : filePrcsTrackUpdateList.getFilePrcsNameList()) {
            eventHelper.sendEventIfCopiedToDatahub(fileName, filePrcsTrackUpdateList.getFilePrcsStatus());
        }}
        return updatedList;
    }

    public Collection<FilePrcsTrack> batchInsertFilePrcsTrack(Collection<FilePrcsTrack> batchFilePrcsTrack){
        return filePrcsBatchService.batchInsertFilePrcsTrack(batchFilePrcsTrack);
    }

    public Collection<FilePrcsTrackCorrId> batchInsertFilePrcsCorr(Collection<FilePrcsTrackCorrId> batchFilePrcsCorr){
        return filePrcsBatchService.batchInsertFilePrcsCorr(batchFilePrcsCorr);
    }

    @Transactional
    public Collection<FilePrcsTrack> batchTrackAndCreateFilePrcs(Collection<FilePrcs> filePrcsCollection) {
        Collection<FilePrcsTrack> filePrcsTracks = filePrcsCollection.stream().map(filePrcsTrackMapper::filePrcsToFilePrcsTrack).collect(Collectors.toList());
        Collection<FilePrcsTrack> resultsFilePrcsTracks = batchInsertFilePrcsTrack(filePrcsTracks);
        Map<String, FilePrcsTrack> resultFilePrcsMap = resultsFilePrcsTracks.stream().collect(Collectors.toMap(FilePrcsTrack::getFilePrcsName, Function.identity()));

        Collection<FilePrcsTrackCorrId> filePrcsTrackCorrIds = filePrcsCollection.stream().map(filePrcs -> {
            FilePrcsTrackCorrId temp = filePrcsTrackMapper.filePrcsToFilePrcsTrackCorrID(filePrcs);
            temp.setFilePrcsKey(resultFilePrcsMap.get(temp.getFilePrcsName()).getFilePrcsKey());
            return temp;
        }).collect(Collectors.toList());
        batchInsertFilePrcsCorr(filePrcsTrackCorrIds);

        return resultsFilePrcsTracks;
    }
    public List<String> getFileNamesByFileTyepAndFilePrcsStsKey(String fileType, String filePrcsStatusStr, FilePrcsTrackCorrIdColumnsEnum orderByColumnEnum, boolean getOnlyOneClientFileInBatch,Integer limit) throws IllegalArgumentException{
        Integer filePrcsStatus;
        String orderByColumn;
        try {
            filePrcsStatus = FilePrcsStatus.valueOf(filePrcsStatusStr).getValue();
        }catch (IllegalArgumentException e){
            String sanitizedFilePrcsStatusStr = filePrcsStatusStr.replace('\n', '_').replace('\r', '_');
            log.error("Invalid FilePrcsStatus value: " + sanitizedFilePrcsStatusStr);
            throw new IllegalArgumentException("Invalid FilePrcsStatus value: " + sanitizedFilePrcsStatusStr);
        }
        log.info("File Process Status received by File Type & File Process Key is : {} ", filePrcsStatus);
        if(!getOnlyOneClientFileInBatch){
            orderByColumn = orderByColumnEnum.getValue();
            Sort sort = Sort.by(Sort.Direction.ASC, orderByColumn);
            List<String> result = filePrcsTrackCorrIdImp.findCorrIdsByFileTypeAndStatus(fileType,filePrcsStatus,sort);
            limit = limit > result.size() ? result.size() : limit;
            return result.subList(0,limit);
        }
        orderByColumn = orderByColumnEnum.name();
        return filePrcsTrackCorrIdJdbc.findCorrIdsByFileTypeAndStatusRanked(fileType,filePrcsStatus,orderByColumn,limit);
    }

    @Transactional
    public List<String> batchErrorInsert(FilePrcsErrorBatch filePrcsErrorBatch) {
        List<FilePrcsTrackError> filePrcsTrackErrorList = filePrcsErrorBatch.getFilePrcsNameList().stream()
                .map(fileName -> new FilePrcsTrackError(filePrcsErrorBatch.getInsrtUserId(), fileName, filePrcsErrorBatch.getErrorMsg(),
                        filePrcsErrorBatch.getProcessNm(), filePrcsErrorBatch.getProcessId(),
                        ZonedDateTime.now(CHICAGO_ZONE_ID).toLocalDateTime(),
                        filePrcsErrorBatch.getFilePrcsStatus() != null ? filePrcsErrorBatch.getFilePrcsStatus() : FilePrcsStatus.ERROR))
                .toList();

        List<FilePrcsTrack> filePrcsTrackList = filePrcsTrackImp.findByFilePrcsNameIn(filePrcsErrorBatch.getFilePrcsNameList());
        Map<String, Long> filePrcsNameToFilePrcsKeyMap = filePrcsTrackList.stream()
                .collect(Collectors.toMap(FilePrcsTrack::getFilePrcsName, FilePrcsTrack::getFilePrcsKey));

        filePrcsTrackErrorList.forEach(filePrcsTrackError ->
                filePrcsTrackError.setFilePrcsKey(filePrcsNameToFilePrcsKeyMap.get(filePrcsTrackError.getFilePrcsName())));

        // Use default ERROR status (6) if filePrcsStatus is null
        int statusValue = filePrcsErrorBatch.getFilePrcsStatus() != null ?
                filePrcsErrorBatch.getFilePrcsStatus().getValue() :
                FilePrcsStatus.ERROR.getValue();

        filePrcsTrackImp.updateUpdtUserIdAndUpdtDttmAndFilePrcsStsKeyAndBatchRunIdByFilePrcsNameIn(
                filePrcsErrorBatch.getInsrtUserId(),
                ZonedDateTime.now(CHICAGO_ZONE_ID).toLocalDateTime(),
                statusValue,
                filePrcsErrorBatch.getBatchRunId(),
                filePrcsErrorBatch.getFilePrcsNameList());

        filePrcsTrackErrorImp.saveAllAndFlush(filePrcsTrackErrorList);

        // Determine the failure event type based on the file name and send a failure event for each file name in the list
        for (FilePrcsTrackError filePrcsTrackError : filePrcsTrackErrorList) {
            eventHelper.sendFailureEvent(filePrcsTrackError);
        }
        return filePrcsErrorBatch.getFilePrcsNameList();
    }

    @Transactional
    public List<EventTriggerBody> findEventTriggerBodiesByFileTypeAndFilePrcsStsKeyAndMaxRetryCount(String fileType, Integer filePrcsStsKey, Long maxRetryCount){
        return filePrcsTrackCorrIdJdbc.findEventTriggerBodiesByFileTypeAndFilePrcsStsKeyAndMaxRetryCount(fileType,filePrcsStsKey,maxRetryCount);
    }

    @Transactional
    public int increaseRetryCountByFilePrcsNameIn(List<String> filePrcsNames){
        return filePrcsTrackImp.increaseRetryCountByFilePrcsNameIn(filePrcsNames,ZonedDateTime.now(CHICAGO_ZONE_ID).toLocalDateTime());
    }

    @Transactional
    public List<ClientDataTopicDeploymentEnablement> insertClientDataTopics(ClientDataTopicRequest request, Boolean flag) {
        List<ClientDataTopicDeploymentEnablement> entities = new ArrayList<>();
        for (Long subCliSk : request.getSubCliSk()) {
            for (DataTopic dataTopic : request.getDataTopic()) {
                ClientDataTopicDeploymentEnablement entity = clientDataTopicDeploymentEnablementRepository.findBySubCliSkAndDataTopic(subCliSk, dataTopic)
                        .orElse(new ClientDataTopicDeploymentEnablement());
                entity.setSubCliSk(subCliSk);
                entity.setDataTopic(dataTopic);
                entity.setIsActive(flag);
                entity.setUpdtDttm(ZonedDateTime.now(CHICAGO_ZONE_ID).toLocalDateTime());
                entity.setUpdateDescription(request.getUpdateDescription());
                entity.setUpdateUser(request.getUpdateUser());
                entities.add(entity);
            }
        }
        return clientDataTopicDeploymentEnablementRepository.saveAll(entities);
    }

}