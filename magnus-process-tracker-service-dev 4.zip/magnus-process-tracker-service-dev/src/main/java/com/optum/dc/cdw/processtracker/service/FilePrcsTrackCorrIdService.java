package com.optum.dc.cdw.processtracker.service;

import com.optum.dc.cdw.processtracker.entity.FilePrcsTrackCorrId;
import com.optum.dc.cdw.processtracker.repository.FilePrcsTrackCorrIdImp;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.time.ZoneId;
import java.time.ZonedDateTime;

@Service
@Slf4j
public class FilePrcsTrackCorrIdService {

    @Autowired
    private FilePrcsTrackCorrIdImp filePrcsTrackCorrIdImp;

    private static final ZoneId CHICAGO_ZONE_ID = ZoneId.of("America/Chicago");

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public FilePrcsTrackCorrId addFilePrcsTrackCorrId(FilePrcsTrackCorrId filePrcsTrackCorrId){
        filePrcsTrackCorrId.setInsrtDttm(ZonedDateTime.now(CHICAGO_ZONE_ID).toLocalDateTime());
        filePrcsTrackCorrId.setUpdtDttm(ZonedDateTime.now(CHICAGO_ZONE_ID).toLocalDateTime());
        FilePrcsTrackCorrId filePrcsTrackCorrId1=filePrcsTrackCorrIdImp.save(filePrcsTrackCorrId);
        log.info("FilePrcsTrackCorrId is added {}",filePrcsTrackCorrId1.getFilePrcsTrackCorrIdSk());
        return filePrcsTrackCorrId1;
    }
}


