package com.optum.dc.cdw.processtracker.model;

public class EventBody {

    int cliSk;
    int subCliSk;
    String clntGuid;
    String subClntGuid;
    String additionalInfo;

    public EventBody() {

    }

    public EventBody(int cliSk, int subCliSk, String clntGuid, String subClntGuid, String additionalInfo) {
        super();
        this.cliSk = cliSk;
        this.subCliSk = subCliSk;
        this.clntGuid = clntGuid;
        this.subClntGuid = subClntGuid;
        this.additionalInfo = additionalInfo;
    }

    /**
     * @return the cliSk
     */
    public int getCliSk() {
        return cliSk;
    }
    /**
     * @param cliSk the cliSk to set
     */
    public void setCliSk(int cliSk) {
        this.cliSk = cliSk;
    }
    /**
     * @return the subCliSk
     */
    public int getSubCliSk() {
        return subCliSk;
    }
    /**
     * @param subCliSk the subCliSk to set
     */
    public void setSubCliSk(int subCliSk) {
        this.subCliSk = subCliSk;
    }
    /**
     * @return the clntGuid
     */
    public String getClntGuid() {
        return clntGuid;
    }
    /**
     * @param clntGuid the clntGuid to set
     */
    public void setClntGuid(String clntGuid) {
        this.clntGuid = clntGuid;
    }
    /**
     * @return the subClntGuid
     */
    public String getSubClntGuid() {
        return subClntGuid;
    }
    /**
     * @param subClntGuid the subClntGuid to set
     */
    public void setSubClntGuid(String subClntGuid) {
        this.subClntGuid = subClntGuid;
    }
    /**
     * @return the additionalInfo
     */
    public String getAdditionalInfo() {
        return additionalInfo;
    }
    /**
     * @param additionalInfo the additionalInfo to set
     */
    public void setAdditionalInfo(String additionalInfo) {
        this.additionalInfo = additionalInfo;
    }


    @Override
    public String toString() {
        return "EventBody [cliSk=" + cliSk + ", subCliSk=" + subCliSk + ", clntGuid=" + clntGuid + ", subClntGuid="
                + subClntGuid + ", additionalInfo=" + additionalInfo + "]";
    }



}