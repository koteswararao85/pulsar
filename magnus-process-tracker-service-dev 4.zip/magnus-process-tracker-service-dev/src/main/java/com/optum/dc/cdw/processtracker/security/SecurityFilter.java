package com.optum.dc.cdw.processtracker.security;

import com.optum.dc.cdw.processtracker.exception.JwtValidationException;
import io.jsonwebtoken.*;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import static com.optum.dc.cdw.processtracker.util.Constants.HSTS_HEADER;
import static com.optum.dc.cdw.processtracker.util.Constants.HSTS_HEADER_VALUE;

@Component
@Slf4j
public class SecurityFilter extends HttpFilter {

    public static final String AUTHORIZATION = "Authorization";
    private static final String BEARER_TOKEN_REGEX = "Bearer [A-Za-z0-9\\-\\._~\\+\\/]+=*";
    private static final String BEARER = "Bearer ";
    @Value("${azure.aad.authority}")
    private String authority;

    @Value("${azure.aad.aud}")
    private String aud;
    @Value("${azure.aad.iss}")
    private String iss;
    @Value("${azure.aad.scope}")
    private String scope;

    @Autowired
    private SigningKeyResolver signingKeyResolver;

    private final Map<String, Date> authDetails = new HashMap<>();

    @Value("${azure.aad.filter-enabled:true}")
    private boolean filterEnabled;

    @Override
    public void doFilter(HttpServletRequest request, HttpServletResponse response, FilterChain chain) throws ServletException, IOException {

//        log.info("Authentication header: {}", request.getHeader(AUTHORIZATION));
        long startTime = System.currentTimeMillis();
        log.info(" Initiating SecurityFilter ...");
        String requestURI = request.getRequestURI();
        String sanitizedRequestURI = requestURI.replace("\n", "").replace("\r", "");
        log.info("RequestURI Received :: url: {} :: type: {}", sanitizedRequestURI,request.getMethod());
        response.addHeader(HSTS_HEADER,HSTS_HEADER_VALUE);

        // Don't do anything with CORS preflight requests
        if ("OPTIONS".equals(request.getMethod())) {
            chain.doFilter(request, response);
            return;
        }
        if (!filterEnabled) {
            chain.doFilter(request, response);
            return;
        }

        // allow health-details url
        if(requestURI.equalsIgnoreCase("/api/v1/processtrkr/health-check")  && request.getMethod().equals("GET")){
            chain.doFilter(request, response);
            return;
        } else if (requestURI.equalsIgnoreCase("/") && request.getMethod().equals("GET")) {
            setResponseToReturn(response, HttpServletResponse.SC_OK);
            return;
        }else if (requestURI.equalsIgnoreCase("/robots933456.txt") && request.getMethod().equals("GET")) {
            setResponseToReturn(response, HttpServletResponse.SC_NOT_FOUND);
            return;
        }
        if (request.getHeader(AUTHORIZATION) == null
                || StringUtils.isEmpty(request.getHeader(AUTHORIZATION))
                || !request.getHeader(AUTHORIZATION).matches(BEARER_TOKEN_REGEX)) {
            log.error("Auth Token Received from request :{} is null or empty or invalid pattern ", sanitizedRequestURI);
            String sanitizedAuthHeader = "";
            if (request.getHeader(AUTHORIZATION) != null) {
                sanitizedAuthHeader = request.getHeader(AUTHORIZATION).replace("\n", "").replace("\r", "");
            }
            log.error("Auth Token:: {} ", sanitizedAuthHeader);
            log.error("Total Time Spent in filter is: {} MilliSeconds ", System.currentTimeMillis() - startTime);

            setResponseToReturn(response, HttpServletResponse.SC_UNAUTHORIZED);
            return;
        }
        log.info("Time to before auth token fetch for request {} is: {}",sanitizedRequestURI,System.currentTimeMillis() - startTime);
        String token = request.getHeader(AUTHORIZATION);
        log.info("Time to fetch auth token for request {} is: {}",sanitizedRequestURI,System.currentTimeMillis() - startTime);
        token = token.trim().replaceFirst(BEARER, "");

        try {
            log.info("AuthDetails map size: {}, time taken before checks: {}",authDetails.size(),System.currentTimeMillis() - startTime);
            if (!authDetails.isEmpty() && authDetails.containsKey(token)) {
                var whenToInvalidate = new Date(System.currentTimeMillis());
                Date authValidTime = authDetails.get(token);
                if (authValidTime.after(whenToInvalidate)) {
                    log.info("Total Time Spent in cache validating access token for request {} is: {} MilliSeconds ", sanitizedRequestURI, System.currentTimeMillis() - startTime);
                    chain.doFilter(request, response);
                    return;
                } else {
                    log.warn("Token has expired");
                }
            }
//        log.info("Access Token: {}", token);
//        verify auth token
//        There are three steps to verify the token.
//        First, verify the signature of the token to ensure the token was issued by Azure Active Directory.
//        Second, verify the claims in the token based on the business logic.
//        Verify if the token is not expired


            Jws<Claims> claims = validateAccessToken(token);
            log.info("Validated! Got a token with the following claims: ");
            log.info("Issuer: " + claims.getBody().getIssuer());
            log.info("Audience: " + claims.getBody().getAudience());
            log.info("Issued at: " + claims.getBody().getIssuedAt());
            log.info("Expires on: " + claims.getBody().getExpiration());
            authDetails.put(token, claims.getBody().getExpiration());
            log.info("Total Time Spent in validating access token for request {} is: {} MilliSeconds ", sanitizedRequestURI, System.currentTimeMillis() - startTime);
//            if (claims.getBody().getExpiration().after(Calendar.getInstance().getTime())) {
//                log.error("Token has expired");
//                log.error("Total Time Spent in validating the token is: {} MilliSeconds ", System.currentTimeMillis() - startTime);
//                setResponseToReturn(response, HttpServletResponse.SC_UNAUTHORIZED);
//                return;
//            }
            chain.doFilter(request, response);
        } catch (Exception e) {
            log.error("Total Time Spent in filter is: {} MilliSeconds ", System.currentTimeMillis() - startTime);
            log.error("Error Validating the token:", e);
            setResponseToReturn(response, HttpServletResponse.SC_UNAUTHORIZED);

        }
        ThreadContext.clearAll();

    }

    private void setResponseToReturn(HttpServletResponse response, int statusCode) throws IOException {
        response.resetBuffer();
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        response.addHeader("Strict-Transport-Security","max-age=2592000");
        response.setStatus(statusCode);
        response.flushBuffer();
    }

    private Jws<Claims> validateAccessToken(String accessToken) throws Exception {
        Jws<Claims> claims;
        try {
            claims = Jwts.parser()
                    .setSigningKeyResolver(signingKeyResolver)
                    .requireAudience(aud)
                    .requireIssuer(iss)
                    .parseClaimsJws(accessToken);
        } catch (SignatureException ex) {
            throw new JwtValidationException("Jwt validation failed: invalid signature", ex);
        } catch (ExpiredJwtException ex) {
            throw new JwtValidationException("Jwt validation failed: access token us expired", ex);
        } catch (MissingClaimException ex) {
            throw new JwtValidationException("Jwt validation failed: missing required claim", ex);
        } catch (IncorrectClaimException ex) {
            throw new JwtValidationException("Jwt validation failed: required claim has incorrect value", ex);
        } catch (Exception ex) {
            throw new JwtValidationException("Jwt validation failed: error validating the token", ex);
        }
        return claims;
    }
}
