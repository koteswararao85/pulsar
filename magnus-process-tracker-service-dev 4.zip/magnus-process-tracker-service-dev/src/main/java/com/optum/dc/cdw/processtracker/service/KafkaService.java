package com.optum.dc.cdw.processtracker.service;

import com.optum.dc.cdw.processtracker.model.Event;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class KafkaService {
    @Autowired
    private KafkaTemplate<String, Event> kafkaTemplate;
    @Value("${spring.kafka.producer.topic}")
    String gcpKafkaTopic;
    public boolean sendEvent(Event event) {
        try {
            kafkaTemplate.send(gcpKafkaTopic, "", event);
            return true;
        } catch (Exception e) {
            log.error("Error while sending event to kafka", e);
            return false;
        }
    }
}
