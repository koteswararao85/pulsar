package com.optum.dc.cdw.processtracker.dto;

import com.optum.dc.cdw.processtracker.util.FilePrcsStatus;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
public class FilePrcsErrorBatch {
    @NotNull
    private String insrtUserId;
    private List<String> filePrcsNameList;
    @NotNull
    private String errorMsg;
    private String processNm;
    private String processId;
    private String batchRunId;

    private FilePrcsStatus filePrcsStatus = FilePrcsStatus.ERROR;

    // Custom all-args constructor to maintain backward compatibility
    public FilePrcsErrorBatch(String insrtUserId, List<String> filePrcsNameList,
                              String errorMsg, String processNm, String processId,
                              String batchRunId) {
        this.insrtUserId = insrtUserId;
        this.filePrcsNameList = filePrcsNameList;
        this.errorMsg = errorMsg;
        this.processNm = processNm;
        this.processId = processId;
        this.batchRunId = batchRunId;
        this.filePrcsStatus = FilePrcsStatus.ERROR;
    }

    // New constructor with filePrcsStatus parameter
    public FilePrcsErrorBatch(String insrtUserId, List<String> filePrcsNameList,
                              String errorMsg, String processNm, String processId,
                              String batchRunId, FilePrcsStatus filePrcsStatus) {
        this.insrtUserId = insrtUserId;
        this.filePrcsNameList = filePrcsNameList;
        this.errorMsg = errorMsg;
        this.processNm = processNm;
        this.processId = processId;
        this.batchRunId = batchRunId;
        this.filePrcsStatus = filePrcsStatus != null ? filePrcsStatus : FilePrcsStatus.ERROR;
    }
}
