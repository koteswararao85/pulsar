package com.optum.dc.cdw.processtracker.util;

public enum FilePrcsType {
    IN,
    OUT;
}
