package com.optum.dc.cdw.processtracker.util;


/**
 * Determines the event type based on the filename prefix.
 * return the event type as a string, or null if the prefix is unknown
 */

public class FileBundlingHelper {
    public static String determineEventType(String filename, boolean isSuccess) {
        String eventTypeSuffix = isSuccess ? "Success" : "Failed";
        if (filename.startsWith("PROVIDER_")) {
            return "Provider.MagnusLoad." + eventTypeSuffix;
        } else if (filename.startsWith("MEMBER_BV_")) {
            return "MemberBV.MagnusLoad." + eventTypeSuffix;
        } else if (filename.startsWith("MEMBER_") && !filename.contains("GLBID")) {
            return "Member.MagnusLoad." + eventTypeSuffix;
        } else if (filename.startsWith("MEMBER_") && filename.contains("GLBID")) {
            return "GlobalId.MagnusLoad." + eventTypeSuffix;
        } else if (filename.startsWith("MINCLM_")) {
            return "MedicalClaims.MagnusLoad." + eventTypeSuffix;
        } else if (filename.startsWith("PHARMACY_")) {
            return "PharmacyClaims.MagnusLoad." + eventTypeSuffix;
        } else if (filename.startsWith("LAB_")) {
            return "LabResults.MagnusLoad." + eventTypeSuffix;
        } else if (filename.startsWith("RISKGAPS_")) {
            return "RiskGaps.MagnusLoad." + eventTypeSuffix;
        } else if (filename.startsWith("QUALITYGAPS_")) {
            return "QualityGaps.MagnusLoad." + eventTypeSuffix;
        } else if (filename.startsWith("PLAN_")) {
            return "Plan.MagnusLoad." + eventTypeSuffix;
        } else {
            return null;
        }
    }
}
