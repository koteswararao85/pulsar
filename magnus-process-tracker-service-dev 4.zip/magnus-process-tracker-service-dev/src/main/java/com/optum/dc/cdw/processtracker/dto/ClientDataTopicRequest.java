package com.optum.dc.cdw.processtracker.dto;

import com.optum.dc.cdw.processtracker.util.DataTopic;
import lombok.Data;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import java.util.List;

@Data
public class ClientDataTopicRequest {
    @NotEmpty(message = "subCliSk must not be null or empty")
    private List<Long> subCliSk;

    @NotEmpty(message = "dataTopic must not be null or empty")
    private List<DataTopic> dataTopic;

    private String updateDescription;

    @NotNull(message = "updateUser must not be null")
    @NotEmpty(message = "updateUser must not be empty")
    private String updateUser;
}
