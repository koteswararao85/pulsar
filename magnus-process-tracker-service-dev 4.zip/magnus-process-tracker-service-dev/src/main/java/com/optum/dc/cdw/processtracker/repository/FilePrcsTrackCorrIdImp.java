package com.optum.dc.cdw.processtracker.repository;

import com.optum.dc.cdw.processtracker.entity.FilePrcsTrackCorrId;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;


@Repository
public interface FilePrcsTrackCorrIdImp extends JpaRepository<FilePrcsTrackCorrId,Long> {

    @Query("SELECT c.filePrcsName FROM FilePrcsTrackCorrId c " +
            "INNER JOIN FilePrcsTrack t ON c.filePrcsKey = t.filePrcsKey " +
            "WHERE c.fileType = ?1 AND t.filePrcsStsKey = ?2")
    List<String> findCorrIdsByFileTypeAndStatus(String fileType, Integer status, Sort sort);

}
