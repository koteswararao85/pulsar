package com.optum.dc.cdw.processtracker.dto;

import com.optum.dc.cdw.processtracker.util.FilePrcsStatus;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class FilePrcsTrackUpdate {

    @NotNull
    private String updtUserId;
    private Long filePrcsKey;
    private String filePrcsName;
    private FilePrcsStatus filePrcsStatus;
    private Long fileSize;
    private Integer attempts;
    private Integer totalCount;
    private Long prntFilePrcsKey;
    private String sourceSystem;
    private String batchRunId;
}
