package com.optum.dc.cdw.processtracker.configuration;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "azure.aad")
@NoArgsConstructor
@Getter
@Setter
public class AADAuthorizationConfig {
  private Boolean authorizationEnabled;
  private String authority;
  private String jwtTokenEndpoint;
  private String clientId;
  private String clientSecret;
  private String scope;
  private String grantType;
  private String practiceAssistScope;
}
