package com.optum.dc.cdw.processtracker.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.optum.dc.cdw.processtracker.util.Constants;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@Table(name = "FILE_PRCS_TRACK_CORR_ID",schema = Constants.SCHEMA)
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper=false)
public class FilePrcsTrackCorrId extends AuditTrack {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "FILE_PRCS_TRACK_CORR_ID_SK")
    private Long filePrcsTrackCorrIdSk;

    @Column(name = "FILE_PRCS_KEY")
    @NotNull
    private Long filePrcsKey;

    @Column(name = "FILE_PRCS_NAME")
    @Size(max = 500)
    @NotNull
    private String filePrcsName;

    @Column(name = "STORAGE_URL_ID")
    @Size(max = 500)
    private String storageUrlID;

    @Column(name = "RUN_ID")
    @Size(max = 64)
    private String runID;

    @Column(name = "CORRELATION_ID")
    @NotNull
    @Size(max = 100)
    private String correlationId;

    @Column(name = "STORAGE_ACCOUNT")
    @Size(max = 100)
    private String storageAccount;

    @Column(name = "FILE_PATH")
    @Size(max = 200)
    private String filePath;

    @Column(name = "FILE_NAME")
    @Size(max = 100)
    private String fileName;

    @Column(name = "BAD_ROWS")
    private Long badRows;

    @Column(name = "CLEAN_ROWS")
    private Long cleanRows;

    @Column(name = "TOTAL_ROWS")
    private Long totalRows;

    @Column(name = "FILE_SIZE")
    private Long fileSize;

    @Column(name = "STATUS")
    @Size(max = 50)
    private String status;

    @Column(name = "BATCH_START_TIME")
    @Size(max = 255)
    private String batchStartTIme;

    @Column(name = "CHASE_PROCESS_ID")
    @Size(max = 255)
    private String chaseProcessId;

    @Column(name = "CLIENT_NAME")
    @Size(max = 255)
    private String clientName;

    @Column(name = "CLIENT_ID")
    @Size(max = 255)
    private String clientId;

    @Column(name = "FILE_TYPE")
    @Size(max = 255)
    private String fileType;

    @Column(name = "LOB")
    @Size(max = 255)
    private String lob;

    @Column(name = "RECORD_COUNT")
    private Long recordCount;

    @Column(name = "DRTS_CLIENT_ID")
    @Size(max = 255)
    private String drtsClientId;

    @Column(name = "DRTS_CLIENT_NAME")
    @Size(max = 255)
    private String drtsClientName;

    @Column(name = "DRTS_CONTRACT_ID")
    @Size(max = 255)
    private String drtsContractId;

    @Column(name = "PAID_DATE")
    @Size(max = 255)
    private String paidDate;

    @Column(name = "ORIG_SOURCE_INFO")
    @Size(max = 255)
    private String origSourceInfo;

    @Column(name = "EVENT_MESSAGE")
    private String eventMessage;

    @Column(name = "EVENT_TRIGGER_BODY")
    private String eventTriggerBody;

    public FilePrcsTrackCorrId(@NotNull LocalDateTime insrtDttm, @NotNull @Size(max = 20) String insrtUserId, LocalDateTime updtDttm, String updtUserId, Long filePrcsTrackCorrIdSk, Long filePrcsKey, String filePrcsName, String storageUrlID, String runID, String correlationId, String storageAccount, String filePath, String fileName, Long badRows, Long cleanRows, Long totalRows, Long fileSize, String status, String batchStartTIme, String chaseProcessId, String clientName, String clientId, String fileType, String lob, Long recordCount, String drtsClientId, String drtsClientName, String drtsContractId, String paidDate, String origSourceInfo, String eventMessage, String eventTriggerBody) {
        super(insrtDttm, insrtUserId, updtDttm, updtUserId);
        this.filePrcsTrackCorrIdSk = filePrcsTrackCorrIdSk;
        this.filePrcsKey = filePrcsKey;
        this.filePrcsName = filePrcsName;
        this.storageUrlID = storageUrlID;
        this.runID = runID;
        this.correlationId = correlationId;
        this.storageAccount = storageAccount;
        this.filePath = filePath;
        this.fileName = fileName;
        this.badRows = badRows;
        this.cleanRows = cleanRows;
        this.totalRows = totalRows;
        this.fileSize = fileSize;
        this.status = status;
        this.batchStartTIme = batchStartTIme;
        this.chaseProcessId = chaseProcessId;
        this.clientName = clientName;
        this.clientId = clientId;
        this.fileType = fileType;
        this.lob = lob;
        this.recordCount = recordCount;
        this.drtsClientId = drtsClientId;
        this.drtsClientName = drtsClientName;
        this.drtsContractId = drtsContractId;
        this.paidDate = paidDate;
        this.origSourceInfo = origSourceInfo;
        this.eventMessage = eventMessage;
        this.eventTriggerBody = eventTriggerBody;
    }
}
