package com.optum.dc.cdw.processtracker.repository;

import com.optum.dc.cdw.processtracker.entity.FilePrcsTrack;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

@Repository
public interface FilePrcsTrackImp extends JpaRepository<FilePrcsTrack, Long> {
    boolean existsByFilePrcsNameLike(@NonNull String filePrcsName);

    Optional<FilePrcsTrack> findByFilePrcsNameLike(@NonNull String filePrcsName);

    List<FilePrcsTrack> findByFilePrcsNameIn(@NonNull Collection<String> filePrcsNames);

    @Transactional
    @Modifying
    @Query("""
            update FilePrcsTrack f set f.updtUserId = ?1, f.updtDttm = ?2, f.filePrcsStsKey = ?3, f.batchRunId = ?4
            where f.filePrcsName in ?5""")
    int updateUpdtUserIdAndUpdtDttmAndFilePrcsStsKeyAndBatchRunIdByFilePrcsNameIn(String updtUserId, LocalDateTime updtDttm, Integer filePrcsStsKey, String batchRunId, List<String> filePrcsName);

    @Transactional
    @Modifying
    @Query("UPDATE FilePrcsTrack f SET f.retryCount = f.retryCount + 1,f.updtDttm = :updtDttm WHERE f.filePrcsName IN :filePrcsNames")
    int increaseRetryCountByFilePrcsNameIn(List<String> filePrcsNames,LocalDateTime updtDttm);
}