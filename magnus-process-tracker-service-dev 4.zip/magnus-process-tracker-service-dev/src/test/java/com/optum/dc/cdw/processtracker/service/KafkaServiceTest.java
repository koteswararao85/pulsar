package com.optum.dc.cdw.processtracker.service;

import com.optum.dc.cdw.processtracker.model.Event;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.kafka.core.KafkaTemplate;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class KafkaServiceTest {

    @Mock
    private KafkaTemplate<String, Event> kafkaTemplate;

    @InjectMocks
    private KafkaService kafkaService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        // Set topic value directly since @Value won't work in unit test
        kafkaService.gcpKafkaTopic = "test-topic";
    }

    @Test
    void sendEvent_success() {
        Event event = new Event();
        when(kafkaTemplate.send(anyString(), anyString(), any(Event.class))).thenReturn(null);

        boolean result = kafkaService.sendEvent(event);

        assertTrue(result);
        verify(kafkaTemplate, times(1)).send("test-topic", "", event);
    }

    @Test
    void sendEvent_exception() {
        Event event = new Event();
        when(kafkaTemplate.send(anyString(), anyString(), any(Event.class)))
                .thenThrow(new RuntimeException("Kafka error"));

        boolean result = kafkaService.sendEvent(event);

        assertFalse(result);
        verify(kafkaTemplate, times(1)).send("test-topic", "", event);
    }
}