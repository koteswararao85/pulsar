package com.optum.dc.cdw.processtracker.service;

import com.optum.dc.cdw.processtracker.entity.FilePrcsTrack;
import com.optum.dc.cdw.processtracker.entity.FilePrcsTrackAudit;
import com.optum.dc.cdw.processtracker.entity.FilePrcsTrackError;
import com.optum.dc.cdw.processtracker.exception.DataNotFoundException;
import com.optum.dc.cdw.processtracker.repository.FilePrcsTrackAuditImp;
import com.optum.dc.cdw.processtracker.repository.FilePrcsTrackErrorImp;
import com.optum.dc.cdw.processtracker.repository.FilePrcsTrackImp;
import com.optum.dc.cdw.processtracker.util.FilePrcsTrackMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

class FilePrcsTrackDuplicateServiceTest {

    @Mock
    private FilePrcsTrackImp filePrcsTrackImp;
    @Mock
    private FilePrcsTrackAuditImp filePrcsTrackAuditImp;
    @Mock
    private FilePrcsTrackErrorImp filePrcsTrackErrorImp;
    @Mock
    private FilePrcsTrackMapper filePrcsTrackMapper;

    @InjectMocks
    private FilePrcsTrackDuplicateService service;

    @BeforeEach
    void setUp(){
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void handleDuplicate_success() {
        FilePrcsTrack incoming = new FilePrcsTrack();
        incoming.setFilePrcsName("file");

        FilePrcsTrack existing = new FilePrcsTrack();
        existing.setFilePrcsName("file");
        existing.setFilePrcsType("IN");
        existing.setFilePrcsKey(1L);

        when(filePrcsTrackImp.findByFilePrcsNameLike("file")).thenReturn(Optional.of(existing));
        when(filePrcsTrackMapper.filePrcsTrackToFilePrcsTrackAudit(any(FilePrcsTrack.class))).thenReturn(new FilePrcsTrackAudit());
        when(filePrcsTrackAuditImp.saveAndFlush(any(FilePrcsTrackAudit.class))).thenReturn(new FilePrcsTrackAudit());
        when(filePrcsTrackMapper.filePrcsTrackToFilePrcsTrackError(any(FilePrcsTrack.class))).thenReturn(new FilePrcsTrackError());
        when(filePrcsTrackErrorImp.saveAndFlush(any(FilePrcsTrackError.class))).thenReturn(new FilePrcsTrackError());

        FilePrcsTrack result = service.handleDuplicateFilePrcsTrack(incoming);
        assertEquals(existing, result);
        assertNotNull(result.getFilePrcsStatus());
        assertEquals("IN", result.getFilePrcsType());
        assertNotNull(result.getFilePrcsTypeEnum());
    }

    @Test
    void handleDuplicate_missingExisting_throws() {
        FilePrcsTrack incoming = new FilePrcsTrack();
        incoming.setFilePrcsName("file");
        when(filePrcsTrackImp.findByFilePrcsNameLike("file")).thenReturn(Optional.empty());
        RuntimeException ex = assertThrows(RuntimeException.class, () -> service.handleDuplicateFilePrcsTrack(incoming));
        assertTrue(ex.getCause() instanceof DataNotFoundException);
    }
}


