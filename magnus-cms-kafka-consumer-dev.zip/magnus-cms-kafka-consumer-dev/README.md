# magnus-cms-kafka-consumer
Kafka consumer for cms data

### Building this module on your local machine

```
mvn clean install
```

# Build docker image, push to azure repository and run from local
* docker login -u cregmagnuscusdev cregmagnuscusdev.azurecr.io with acr credential
* docker build -t magnus-cms-kafka-event-consumer:latest .
* docker tag magnus-cms-kafka-event-consumer:latest cregmagnuscusdev.azurecr.io/cregmagnuscusdev/magnus-cms-kafka-event-consumer:latest
* docker push cregmagnuscusdev.azurecr.io/cregmagnuscusdev/magnus-cms-kafka-event-consumer:latest
* docker run -it -p 8080:8080 magnus-cms-kafka-event-consumer:latest

# Azure login
* $  az login
* $  az account set -s bff0c133-c56b-4467-aa3a-9592e052d757