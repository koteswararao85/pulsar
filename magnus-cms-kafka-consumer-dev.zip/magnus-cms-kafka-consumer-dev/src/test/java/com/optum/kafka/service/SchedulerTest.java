package com.optum.kafka.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectReader;
import com.optum.kafka.Models.ADFMsg;
import com.optum.kafka.Models.EventTriggerBody;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class SchedulerTest {

    @InjectMocks
    private Scheduler scheduler;

    @Mock
    private ADFTriggerService adfTriggerService;

    @Mock
    private TrackerApi trackerApi;

    @Spy
    private ObjectMapper objectMapper = new ObjectMapper();

    private final List<String> fileTypes = Arrays.asList("MMR", "TRR", "MOR PART C", "MOR PART D", "MOR PART C ANNUAL", "MOR PART D ANNUAL", "TRR 2017", "TRR 2025", "MAO002", "MAO004", "MSO");

    Integer dataTopicListLength = fileTypes.size();

    @BeforeEach
    public void setUp() {
        ReflectionTestUtils.setField(scheduler, "maxRetryAttempts", 3L);
        ReflectionTestUtils.setField(scheduler, "fixedDelay", "300000");
        scheduler.init(); // Initialize the reader
    }

    @Test
    public void testPerformTask_SuccessfulProcessing() throws MalformedURLException {
        // Prepare test data
        String fileType = "MMR";
        String eventTriggerBodyJson = "{\"fileName\":\"test.parquet\",\"folderPath\":\"container/folder\"}";

        EventTriggerBody eventTriggerBody = new EventTriggerBody();
        eventTriggerBody.setFilePrcsName("file1");
        eventTriggerBody.setEventTriggerBody(eventTriggerBodyJson);

        List<EventTriggerBody> eventTriggerBodies = Collections.singletonList(eventTriggerBody);
        ResponseEntity<List<EventTriggerBody>> response = new ResponseEntity<>(eventTriggerBodies, HttpStatus.OK);
        ResponseEntity<List<EventTriggerBody>> emptyResponse = new ResponseEntity<>(Collections.emptyList(), HttpStatus.OK);

        // Mock the API calls - default to empty response
        when(trackerApi.fetchEventTriggerBodies(anyString(), anyLong())).thenReturn(emptyResponse);
        // Override for specific file type
        when(trackerApi.fetchEventTriggerBodies(eq(fileType), anyLong())).thenReturn(response);

        // Execute
        scheduler.performTask();

        // Verify
        verify(trackerApi, times(dataTopicListLength)).fetchEventTriggerBodies(anyString(), eq(3L));
        verify(trackerApi).increaseRetryCountByFilePrcsNameIn(anyList());
        verify(adfTriggerService).ADFTriggerByEventTriggerMessages(anyList());
    }

    @Test
    public void testPerformTask_NoFilesToProcess() throws MalformedURLException {
        // Mock empty response for all file types
        ResponseEntity<List<EventTriggerBody>> emptyResponse = new ResponseEntity<>(
                Collections.emptyList(), HttpStatus.OK);

        when(trackerApi.fetchEventTriggerBodies(anyString(), anyLong())).thenReturn(emptyResponse);

        // Execute
        scheduler.performTask();

        // Verify no processing occurred
        verify(trackerApi, times(dataTopicListLength)).fetchEventTriggerBodies(anyString(), eq(3L));
        verify(trackerApi, never()).increaseRetryCountByFilePrcsNameIn(anyList());
        verify(adfTriggerService, never()).ADFTriggerByEventTriggerMessages(anyList());
    }

    @Test
    public void testPerformTask_DeserializationFailure() throws MalformedURLException {
        // Prepare test data with invalid JSON
        String fileType = "MMR";
        String invalidJson = "{invalid-json}";

        EventTriggerBody eventTriggerBody = new EventTriggerBody();
        eventTriggerBody.setFilePrcsName("file2");
        eventTriggerBody.setEventTriggerBody(invalidJson);

        List<EventTriggerBody> eventTriggerBodies = Collections.singletonList(eventTriggerBody);
        ResponseEntity<List<EventTriggerBody>> response = new ResponseEntity<>(eventTriggerBodies, HttpStatus.OK);
        ResponseEntity<List<EventTriggerBody>> emptyResponse = new ResponseEntity<>(Collections.emptyList(), HttpStatus.OK);

        // Mock the API call
        when(trackerApi.fetchEventTriggerBodies(anyString(), anyLong())).thenReturn(emptyResponse);
        when(trackerApi.fetchEventTriggerBodies(eq(fileType), anyLong())).thenReturn(response);

        // Execute
        scheduler.performTask();

        // Verify error handling
        verify(trackerApi, times(dataTopicListLength)).fetchEventTriggerBodies(anyString(), eq(3L));
        verify(trackerApi).increaseRetryCountByFilePrcsNameIn(Collections.emptyList());
        verify(adfTriggerService).ADFTriggerByEventTriggerMessages(Collections.emptyList());
    }

    @Test
    public void testPerformTask_ApiFailure() throws MalformedURLException {
        // Mock API failure
        ResponseEntity<List<EventTriggerBody>> errorResponse = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        when(trackerApi.fetchEventTriggerBodies(anyString(), anyLong())).thenReturn(errorResponse);

        // Execute
        scheduler.performTask();

        // Verify error handling
        verify(trackerApi, times(dataTopicListLength)).fetchEventTriggerBodies(anyString(), eq(3L));
        verify(trackerApi, never()).increaseRetryCountByFilePrcsNameIn(anyList());
        verify(adfTriggerService, never()).ADFTriggerByEventTriggerMessages(anyList());
    }

    @Test
    public void testPerformTask_RetryCountUpdateFailure() throws MalformedURLException {
        // Prepare test data
        String fileType = "MMR";
        String eventTriggerBodyJson = "{\"fileName\":\"test.parquet\",\"folderPath\":\"container/folder\"}";

        EventTriggerBody eventTriggerBody = new EventTriggerBody();
        eventTriggerBody.setFilePrcsName("file3");
        eventTriggerBody.setEventTriggerBody(eventTriggerBodyJson);

        List<EventTriggerBody> eventTriggerBodies = Collections.singletonList(eventTriggerBody);
        ResponseEntity<List<EventTriggerBody>> response = new ResponseEntity<>(eventTriggerBodies, HttpStatus.OK);
        ResponseEntity<List<EventTriggerBody>> emptyResponse = new ResponseEntity<>(Collections.emptyList(), HttpStatus.OK);

        // Mock API calls with retry count update failure
        when(trackerApi.fetchEventTriggerBodies(anyString(), anyLong())).thenReturn(emptyResponse);
        when(trackerApi.fetchEventTriggerBodies(eq(fileType), anyLong())).thenReturn(response);

        // Make increaseRetryCountByFilePrcsNameIn throw an exception
        doThrow(new RuntimeException("Failed to update retry count"))
                .when(trackerApi).increaseRetryCountByFilePrcsNameIn(anyList());

        // Execute
        scheduler.performTask();

        // Verify error handling but still proceed with ADF trigger
        verify(trackerApi, times(dataTopicListLength)).fetchEventTriggerBodies(anyString(), eq(3L));
        verify(trackerApi).increaseRetryCountByFilePrcsNameIn(anyList());
        verify(adfTriggerService).ADFTriggerByEventTriggerMessages(anyList());
    }

    @Test
    public void testPerformTask_MultipleFileTypes() throws MalformedURLException {
        // Prepare test data for two file types
        String fileType1 = "MMR";
        String fileType2 = "TRR";

        String eventTriggerBodyJson1 = "{\"fileName\":\"mmr.parquet\",\"folderPath\":\"container/lab\"}";
        String eventTriggerBodyJson2 = "{\"fileName\":\"trr.parquet\",\"folderPath\":\"container/claim\"}";

        EventTriggerBody eventTriggerBody1 = new EventTriggerBody();
        eventTriggerBody1.setFilePrcsName("file4");
        eventTriggerBody1.setEventTriggerBody(eventTriggerBodyJson1);

        EventTriggerBody eventTriggerBody2 = new EventTriggerBody();
        eventTriggerBody2.setFilePrcsName("file5");
        eventTriggerBody2.setEventTriggerBody(eventTriggerBodyJson2);

        ResponseEntity<List<EventTriggerBody>> response1 = new ResponseEntity<>(
                Collections.singletonList(eventTriggerBody1), HttpStatus.OK);
        ResponseEntity<List<EventTriggerBody>> response2 = new ResponseEntity<>(
                Collections.singletonList(eventTriggerBody2), HttpStatus.OK);
        ResponseEntity<List<EventTriggerBody>> emptyResponse = new ResponseEntity<>(
                Collections.emptyList(), HttpStatus.OK);

        // Default response for any file type
        when(trackerApi.fetchEventTriggerBodies(anyString(), anyLong())).thenReturn(emptyResponse);

        // Override for specific file types
        when(trackerApi.fetchEventTriggerBodies(eq(fileType1), anyLong())).thenReturn(response1);
        when(trackerApi.fetchEventTriggerBodies(eq(fileType2), anyLong())).thenReturn(response2);

        // Execute
        scheduler.performTask();

        // Verify processing for both file types
        verify(trackerApi, times(dataTopicListLength)).fetchEventTriggerBodies(anyString(), eq(3L));
        verify(trackerApi, times(2)).increaseRetryCountByFilePrcsNameIn(anyList());
        verify(adfTriggerService, times(2)).ADFTriggerByEventTriggerMessages(anyList());
    }

    @Test
    public void testPerformTask_MalformedURLException() throws MalformedURLException {
        // Prepare test data
        String fileType = "MMR";
        String eventTriggerBodyJson = "{\"fileName\":\"test.parquet\",\"folderPath\":\"container/folder\"}";

        EventTriggerBody eventTriggerBody = new EventTriggerBody();
        eventTriggerBody.setFilePrcsName("file6");
        eventTriggerBody.setEventTriggerBody(eventTriggerBodyJson);

        List<EventTriggerBody> eventTriggerBodies = Collections.singletonList(eventTriggerBody);
        ResponseEntity<List<EventTriggerBody>> response = new ResponseEntity<>(eventTriggerBodies, HttpStatus.OK);

        // Mock API call for the specific file type
        when(trackerApi.fetchEventTriggerBodies(eq(fileType), anyLong())).thenReturn(response);

        // Mock ADFTriggerService to throw MalformedURLException
        doThrow(new MalformedURLException("Invalid URL"))
                .when(adfTriggerService).ADFTriggerByEventTriggerMessages(anyList());

        // Execute and verify exception is propagated
        assertThrows(MalformedURLException.class, () -> scheduler.performTask());

        // Verify processing attempted
        verify(trackerApi, atLeastOnce()).fetchEventTriggerBodies(anyString(), eq(3L));
        verify(trackerApi, atLeastOnce()).increaseRetryCountByFilePrcsNameIn(anyList());
    }

    @Test
    public void testInit() {
        // Create a new scheduler to test init method
        Scheduler newScheduler = new Scheduler();

        // Execute init method
        newScheduler.init();

        // Verify reader is initialized (using reflection to check private field)
        ObjectReader reader = (ObjectReader) ReflectionTestUtils.getField(newScheduler, "reader");
        assertNotNull(reader, "Reader should be initialized");
    }

}