package com.optum.kafka;

import com.optum.kafka.Listener.IronGateDataConsumer;
import com.optum.kafka.configuration.TokenHandler;
import com.optum.kafka.service.ADFTriggerService;
import com.optum.kafka.service.TrackerApi;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.web.client.RestTemplate;


@Configuration
@ActiveProfiles("junits")
public class MagnusKafkaConsumerApplicationTests {

	@Bean
	public TrackerApi trackerApi(){
		return new TrackerApi();
	}

	@Bean
	public RestTemplate restTemplate(){
		return new RestTemplate();
	}

	@Bean
	public TokenHandler tokenHandler(){
		return new TokenHandler();
	}

	@Bean
	public ADFTriggerService adfTriggerService(){
		return new ADFTriggerService();
	}

	@Bean
	public IronGateDataConsumer ironGateDataConsumer(){
		return new IronGateDataConsumer();
	}


}
