package com.optum.kafka.service;

import com.optum.kafka.Models.*;
import com.optum.kafka.configuration.TokenHandler;
import com.optum.kafka.util.ConsumerConstants;
import com.optum.kafka.util.FilePrcsStatus;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class TrackerApiTest {

    @InjectMocks
    private TrackerApi trackerApi;

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private TokenHandler tokenHandler;

    private final String TEST_URL = "http://test-api.com/";
    private final String TEST_TOKEN = "test-token-123";

    @BeforeEach
    public void setUp() {
        ReflectionTestUtils.setField(trackerApi, "url", TEST_URL);
        when(tokenHandler.getToken()).thenReturn(TEST_TOKEN);
    }




    @Test
    public void testCreateTrackError_Success() {
        // Setup
        FilePrcsTrackError trackError = new FilePrcsTrackError();
        trackError.setFilePrcsName("testFile");
        trackError.setErrorMsg("Test error message");

        ResponseEntity<FilePrcsTrackError> expectedResponse =
                new ResponseEntity<>(trackError, HttpStatus.OK);

        when(restTemplate.postForEntity(
                eq(TEST_URL + "processtrkr/addFilePrcsTrackError"),
                any(HttpEntity.class),
                eq(FilePrcsTrackError.class)
        )).thenReturn(expectedResponse);

        // Execute
        ResponseEntity<FilePrcsTrackError> response = trackerApi.createTrackError(trackError);

        // Verify
        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(trackError, response.getBody());

        // Verify HTTP entity
        ArgumentCaptor<HttpEntity<FilePrcsTrackError>> captor =
                ArgumentCaptor.forClass(HttpEntity.class);
        verify(restTemplate).postForEntity(
                eq(TEST_URL + "processtrkr/addFilePrcsTrackError"),
                captor.capture(),
                eq(FilePrcsTrackError.class)
        );

        HttpEntity<FilePrcsTrackError> capturedEntity = captor.getValue();
        assertEquals(MediaType.APPLICATION_JSON, capturedEntity.getHeaders().getContentType());
        assertEquals("Bearer " + TEST_TOKEN, capturedEntity.getHeaders().getFirst("Authorization"));
        assertEquals(ConsumerConstants.KAFKA_CONUMSER, capturedEntity.getBody().getInsrtUserId());
        assertEquals(ConsumerConstants.KAFKA_CONUMSER, capturedEntity.getBody().getUpdtUserId());
    }

    @Test
    public void testCreateTrackError_EmptyToken() {
        // Setup
        when(tokenHandler.getToken()).thenReturn("");
        FilePrcsTrackError trackError = new FilePrcsTrackError();

        // Execute
        ResponseEntity<FilePrcsTrackError> response = trackerApi.createTrackError(trackError);

        // Verify
        assertNotNull(response);
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        verify(restTemplate, never()).postForEntity(
                anyString(),
                any(HttpEntity.class),
                eq(FilePrcsTrackError.class)
        );
    }

    @Test
    public void testCreateTrackError_ApiException() {
        // Setup
        FilePrcsTrackError trackError = new FilePrcsTrackError();
        when(restTemplate.postForEntity(
                eq(TEST_URL + "processtrkr/addFilePrcsTrackError"),
                any(HttpEntity.class),
                eq(FilePrcsTrackError.class)
        )).thenThrow(new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR));

        // Execute
        ResponseEntity<FilePrcsTrackError> response = trackerApi.createTrackError(trackError);

        // Verify
        assertNotNull(response);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
    }

    @Test
    public void testCreateTrackErrorBatch_Success() {
        // Setup
        List<String> fileNames = Arrays.asList("file1", "file2");
        String errorMsg = "Test batch error";
        FilePrcsErrorBatch errorBatch = new FilePrcsErrorBatch("", fileNames, errorMsg, "", "", "");

        ResponseEntity<FilePrcsErrorBatch> expectedResponse =
                new ResponseEntity<>(errorBatch, HttpStatus.OK);

        when(restTemplate.postForEntity(
                eq(TEST_URL + "processtrkr/batchAddFilePrcsError"),
                any(HttpEntity.class),
                eq(FilePrcsErrorBatch.class)
        )).thenReturn(expectedResponse);

        // Execute
        ResponseEntity<FilePrcsErrorBatch> response = trackerApi.createTrackErrorBatch(errorBatch);

        // Verify
        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(errorBatch, response.getBody());

        // Verify HTTP entity
        ArgumentCaptor<HttpEntity<FilePrcsErrorBatch>> captor =
                ArgumentCaptor.forClass(HttpEntity.class);
        verify(restTemplate).postForEntity(
                eq(TEST_URL + "processtrkr/batchAddFilePrcsError"),
                captor.capture(),
                eq(FilePrcsErrorBatch.class)
        );

        HttpEntity<FilePrcsErrorBatch> capturedEntity = captor.getValue();
        assertEquals(MediaType.APPLICATION_JSON, capturedEntity.getHeaders().getContentType());
        assertEquals("Bearer " + TEST_TOKEN, capturedEntity.getHeaders().getFirst("Authorization"));
        assertEquals(ConsumerConstants.KAFKA_CONUMSER, capturedEntity.getBody().getInsrtUserId());
    }



    @Test
    public void testTrackAndCreateFile_Success() {
        // Setup
        FilePrcs filePrcs = new FilePrcs();
        filePrcs.setFilePrcsName("testFile");
        filePrcs.setFileType("TEST");

        FilePrcsTrack expectedTrack = new FilePrcsTrack();
        expectedTrack.setFilePrcsName("testFile");

        ResponseEntity<FilePrcsTrack> expectedResponse =
                new ResponseEntity<>(expectedTrack, HttpStatus.CREATED);

        when(restTemplate.postForEntity(
                eq(TEST_URL + "processtrkr/trackAndCreateFilePrcsKey"),
                any(HttpEntity.class),
                eq(FilePrcsTrack.class)
        )).thenReturn(expectedResponse);

        // Execute
        ResponseEntity<FilePrcsTrack> response = trackerApi.trackAndCreateFile(filePrcs);

        // Verify
        assertNotNull(response);
        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertEquals(expectedTrack, response.getBody());
    }

    @Test
    public void testTrackAndCreateFile_ApiException() {
        // Setup
        FilePrcs filePrcs = new FilePrcs();
        filePrcs.setFilePrcsName("testFile");

        when(restTemplate.postForEntity(
                eq(TEST_URL + "processtrkr/trackAndCreateFilePrcsKey"),
                any(HttpEntity.class),
                eq(FilePrcsTrack.class)
        )).thenThrow(new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR));

        // No need to mock tokenHandler.getToken() again as it's already mocked in setUp()

        // Mock createTrackError to avoid actual API call
        when(restTemplate.postForEntity(
                eq(TEST_URL + "processtrkr/addFilePrcsTrackError"),
                any(HttpEntity.class),
                eq(FilePrcsTrackError.class)
        )).thenReturn(new ResponseEntity<>(new FilePrcsTrackError(), HttpStatus.OK));

        // Execute
        ResponseEntity<FilePrcsTrack> response = trackerApi.trackAndCreateFile(filePrcs);

        // Verify
        assertNotNull(response);
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());

        // Verify that createTrackError was called
        verify(restTemplate).postForEntity(
                eq(TEST_URL + "processtrkr/addFilePrcsTrackError"),
                any(HttpEntity.class),
                eq(FilePrcsTrackError.class)
        );
    }

    @Test
    public void testFetchEventTriggerBodies_Success() {
        // Setup
        String fileType = "TEST";
        Long maxRetryCount = 3L;

        EventTriggerBody body1 = new EventTriggerBody();
        body1.setFilePrcsName("file1");
        body1.setEventTriggerBody("{\"test\":\"data\"}");

        List<EventTriggerBody> expectedBodies = Collections.singletonList(body1);
        ResponseEntity<List<EventTriggerBody>> expectedResponse =
                new ResponseEntity<>(expectedBodies, HttpStatus.OK);

        when(restTemplate.exchange(
                eq(TEST_URL + "/processtrkr/batchFetchEventTriggerBodies?fileType=" + fileType + "&maxRetryCount=" + maxRetryCount),
                eq(HttpMethod.GET),
                any(HttpEntity.class),
                any(ParameterizedTypeReference.class)
        )).thenReturn(expectedResponse);

        // Execute
        ResponseEntity<List<EventTriggerBody>> response = trackerApi.fetchEventTriggerBodies(fileType, maxRetryCount);

        // Verify
        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(expectedBodies, response.getBody());
    }

    @Test
    public void testFetchEventTriggerBodies_ApiException() {
        // Setup
        String fileType = "TEST";
        Long maxRetryCount = 3L;

        when(restTemplate.exchange(
                anyString(),
                eq(HttpMethod.GET),
                any(HttpEntity.class),
                any(ParameterizedTypeReference.class)
        )).thenThrow(new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR));

        // Execute
        ResponseEntity<List<EventTriggerBody>> response = trackerApi.fetchEventTriggerBodies(fileType, maxRetryCount);

        // Verify
        assertNotNull(response);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
    }

    @Test
    public void testIncreaseRetryCountByFilePrcsNameIn_Success() {
        // Setup
        List<String> fileNames = Arrays.asList("file1", "file2");
        ResponseEntity<Integer> expectedResponse = new ResponseEntity<>(2, HttpStatus.OK);

        when(restTemplate.postForEntity(
                eq(TEST_URL + "processtrkr/increaseRetryCountForFileNames"),
                any(HttpEntity.class),
                eq(Integer.class)
        )).thenReturn(expectedResponse);

        // Execute
        ResponseEntity<Integer> response = trackerApi.increaseRetryCountByFilePrcsNameIn(fileNames);

        // Verify
        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(2, response.getBody());

        // Verify HTTP entity
        ArgumentCaptor<HttpEntity<List<String>>> captor =
                ArgumentCaptor.forClass(HttpEntity.class);
        verify(restTemplate).postForEntity(
                eq(TEST_URL + "processtrkr/increaseRetryCountForFileNames"),
                captor.capture(),
                eq(Integer.class)
        );

        HttpEntity<List<String>> capturedEntity = captor.getValue();
        assertEquals(MediaType.APPLICATION_JSON, capturedEntity.getHeaders().getContentType());
        assertEquals("Bearer " + TEST_TOKEN, capturedEntity.getHeaders().getFirst("Authorization"));
        assertEquals(fileNames, capturedEntity.getBody());
    }

    @Test
    public void testIncreaseRetryCountByFilePrcsNameIn_ApiException() {
        // Setup
        List<String> fileNames = Arrays.asList("file1", "file2");

        when(restTemplate.postForEntity(
                eq(TEST_URL + "processtrkr/increaseRetryCountForFileNames"),
                any(HttpEntity.class),
                eq(Integer.class)
        )).thenThrow(new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR));

        // Mock createTrackErrorBatch to avoid actual API call
        when(restTemplate.postForEntity(
                contains("batchAddFilePrcsError"),
                any(HttpEntity.class),
                eq(FilePrcsErrorBatch.class)
        )).thenReturn(new ResponseEntity<>(new FilePrcsErrorBatch(), HttpStatus.OK));

        // Execute
        ResponseEntity<Integer> response = trackerApi.increaseRetryCountByFilePrcsNameIn(fileNames);

        // Verify
        assertNotNull(response);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());

        // Verify error batch creation
        verify(restTemplate).postForEntity(
                contains("batchAddFilePrcsError"),
                any(HttpEntity.class),
                eq(FilePrcsErrorBatch.class)
        );
    }

    @Test
    public void testBatchUpdateFilePrcsTrack_Success() {
        // Setup
        List<String> fileNames = Arrays.asList("file1", "file2");
        FilePrcsStatus status = FilePrcsStatus.SUCCESS;
        ResponseEntity<Integer> expectedResponse = new ResponseEntity<>(2, HttpStatus.OK);

        when(restTemplate.postForEntity(
                eq(TEST_URL + "processtrkr/batchUpdateFilePrcsTrack"),
                any(HttpEntity.class),
                eq(Integer.class)
        )).thenReturn(expectedResponse);

        // Execute
        ResponseEntity<Integer> response = trackerApi.batchUpdateFilePrcsTrack(fileNames, status);

        // Verify
        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(2, response.getBody());

        // Verify HTTP entity
        ArgumentCaptor<HttpEntity<FilePrcsStatusBatchUpdate>> captor =
                ArgumentCaptor.forClass(HttpEntity.class);
        verify(restTemplate).postForEntity(
                eq(TEST_URL + "processtrkr/batchUpdateFilePrcsTrack"),
                captor.capture(),
                eq(Integer.class)
        );

        HttpEntity<FilePrcsStatusBatchUpdate> capturedEntity = captor.getValue();
        assertEquals(MediaType.APPLICATION_JSON, capturedEntity.getHeaders().getContentType());
        assertEquals("Bearer " + TEST_TOKEN, capturedEntity.getHeaders().getFirst("Authorization"));
        assertEquals(fileNames, capturedEntity.getBody().getFilePrcsNameList());
        assertEquals(status, capturedEntity.getBody().getFilePrcsStatus());
        assertEquals(ConsumerConstants.KAFKA_CONUMSER, capturedEntity.getBody().getUpdtUserId());
    }

    @Test
    public void testBatchUpdateFilePrcsTrack_ApiException() {
        // Setup
        List<String> fileNames = Arrays.asList("file1", "file2");
        FilePrcsStatus status = FilePrcsStatus.SUCCESS;

        when(restTemplate.postForEntity(
                eq(TEST_URL + "processtrkr/batchUpdateFilePrcsTrack"),
                any(HttpEntity.class),
                eq(Integer.class)
        )).thenThrow(new HttpClientErrorException(HttpStatus.BAD_REQUEST));

        // Mock createTrackErrorBatch to avoid actual API call
        when(restTemplate.postForEntity(
                contains("batchAddFilePrcsError"),
                any(HttpEntity.class),
                eq(FilePrcsErrorBatch.class)
        )).thenReturn(new ResponseEntity<>(new FilePrcsErrorBatch(), HttpStatus.OK));

        // Execute
        ResponseEntity<Integer> response = trackerApi.batchUpdateFilePrcsTrack(fileNames, status);

        // Verify
        assertNotNull(response);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());

        // Verify error batch creation
        verify(restTemplate).postForEntity(
                contains("batchAddFilePrcsError"),
                any(HttpEntity.class),
                eq(FilePrcsErrorBatch.class)
        );
    }
}