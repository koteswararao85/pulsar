package com.optum.kafka.service;

import com.optum.kafka.Models.ADFMsg;
import com.optum.kafka.Models.FilePrcs;
import com.optum.kafka.Models.FilePrcsTrackError;
import com.optum.kafka.util.FilePrcsStatus;
import com.optum.kafka.util.IrongateClassMapper;
import org.junit.jupiter.api.*;
import org.mockito.*;
import org.springframework.http.*;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import java.net.MalformedURLException;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

class ADFTriggerServiceTest {

    @InjectMocks
    private ADFTriggerService adfTriggerService;

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private TrackerApi trackerApi;

    // Test values for @Value fields
    private final String grantType = "client_credentials";
    private final String clientId = "test-client-id";
    private final String clientSecret = "test-client-secret";
    private final String resource = "test-resource";
    private final String tokenUrl = "https://token.url";
    private final String subscriptionId = "sub-id";
    private final String resourceGroupName = "rg";
    private final String adfFactoryName = "factory";

    @BeforeEach
    void setUp() throws Exception {
        MockitoAnnotations.openMocks(this);
        setField(adfTriggerService, "grantType", grantType);
        setField(adfTriggerService, "clientId", clientId);
        setField(adfTriggerService, "clientSecret", clientSecret);
        setField(adfTriggerService, "resource", resource);
        setField(adfTriggerService, "tokenUrl", tokenUrl);
        setField(adfTriggerService, "subscriptionId", subscriptionId);
        setField(adfTriggerService, "resourceGroupName", resourceGroupName);
        setField(adfTriggerService, "adfFactoryName", adfFactoryName);
        adfTriggerService.init();
    }

    @Test
    void testADFTriggerByEventTriggerMessages_successAndError() throws MalformedURLException {
        ADFMsg msg1 = new ADFMsg();
        msg1.setFileName("file1.parquet");
        msg1.setFileType("MMR");
        ADFMsg msg2 = new ADFMsg();
        msg2.setFileName("file2.parquet");
        msg2.setFileType("TRR");
        List<ADFMsg> adfMsgList = Arrays.asList(msg1, msg2);

        // Token request
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        MultiValueMap<String, String> inputMap = new LinkedMultiValueMap<>();
        inputMap.add("grant_type", grantType);
        inputMap.add("client_id", clientId);
        inputMap.add("client_secret", clientSecret);
        inputMap.add("resource", resource);
        HttpEntity<MultiValueMap<String, String>> entity = new HttpEntity<>(inputMap, headers);

        when(restTemplate.postForEntity(eq(tokenUrl), any(HttpEntity.class), eq(String.class)))
                .thenReturn(new ResponseEntity<>("{\"access_token\":\"Token\"}", HttpStatus.OK));

        when(restTemplate.exchange(
                contains("pl_cms_dataintake_file"),
                eq(HttpMethod.POST),
                any(HttpEntity.class),
                eq(String.class)
        )).thenReturn(new ResponseEntity<>("Success", HttpStatus.OK));

        when(trackerApi.batchUpdateFilePrcsTrack(anyList(), any(FilePrcsStatus.class)))
                .thenReturn(new ResponseEntity<>(2, HttpStatus.OK));

        List<String> result = adfTriggerService.ADFTriggerByEventTriggerMessages(adfMsgList);

        assertEquals(2, result.size());
        assertTrue(result.contains("file1.parquet"));
        assertTrue(result.contains("file2.parquet"));

        // Error scenario
        when(restTemplate.exchange(
                anyString(),
                eq(HttpMethod.POST),
                any(HttpEntity.class),
                eq(String.class)
        )).thenThrow(new RuntimeException("Time out"));

        when(trackerApi.createTrackError(any(FilePrcsTrackError.class)))
                .thenReturn(new ResponseEntity<>(HttpStatus.OK));

        List<String> errorResult = adfTriggerService.ADFTriggerByEventTriggerMessages(adfMsgList);

        assertTrue(errorResult.isEmpty());
        verify(trackerApi, atLeastOnce()).createTrackError(any(FilePrcsTrackError.class));
    }

    @Test
    void testADFTriggerIronGate_successAndError() throws MalformedURLException {
        FilePrcs filePrcs = new FilePrcs();
        filePrcs.setFilePrcsName("filePrcsName");
        filePrcs.setFileType("MMR");
        filePrcs.setRecordCount(10);
        filePrcs.setStorageUrlID("https://storageurl.com/con-db/dir/path/file.parquet");

        IrongateClassMapper irongateClassMapper = new IrongateClassMapper();
        ADFMsg msg = irongateClassMapper.mapFilePrcsToADFMsgIronGate(filePrcs, "ironGateStorageAccount");

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        MultiValueMap<String, String> inputMap = new LinkedMultiValueMap<>();
        inputMap.add("grant_type", grantType);
        inputMap.add("client_id", clientId);
        inputMap.add("client_secret", clientSecret);
        inputMap.add("resource", resource);
        HttpEntity<MultiValueMap<String, String>> entity = new HttpEntity<>(inputMap, headers);

        HttpHeaders adfHeaders = new HttpHeaders();
        adfHeaders.set("Authorization", "Bearer Token");
        adfHeaders.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<ADFMsg> httpEntity = new HttpEntity<>(msg, adfHeaders);

        when(restTemplate.postForEntity(eq(tokenUrl), any(HttpEntity.class), eq(String.class)))
                .thenReturn(new ResponseEntity<>("{\"access_token\":\"Token\"}", HttpStatus.OK));
        when(restTemplate.exchange(anyString(), eq(HttpMethod.POST), any(HttpEntity.class), eq(String.class)))
                .thenReturn(new ResponseEntity<>("ADF triggered Successfully", HttpStatus.OK));

        assertEquals("filePrcsName", adfTriggerService.ADFTrigger(filePrcs, "ironGateStorageAccount"));

        // Error scenario
        when(restTemplate.exchange(anyString(), eq(HttpMethod.POST), any(HttpEntity.class), eq(String.class)))
                .thenThrow(new RuntimeException("Time out"));
        when(trackerApi.createTrackError(any())).thenReturn(new ResponseEntity<>(HttpStatus.OK));

        assertEquals(filePrcs.getFilePrcsName(), adfTriggerService.ADFTrigger(filePrcs, "ironGateStorageAccount"));
    }

    @Test
    void testGetOauthToken_successAndError() throws Exception {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        MultiValueMap<String, String> inputMap = new LinkedMultiValueMap<>();
        inputMap.add("grant_type", grantType);
        inputMap.add("client_id", clientId);
        inputMap.add("client_secret", clientSecret);
        inputMap.add("resource", resource);
        HttpEntity<MultiValueMap<String, String>> entity = new HttpEntity<>(inputMap, headers);

        when(restTemplate.postForEntity(eq(tokenUrl), any(HttpEntity.class), eq(String.class)))
                .thenReturn(new ResponseEntity<>("{\"access_token\":\"Token\"}", HttpStatus.OK));

        assertEquals("Token", adfTriggerService.getOauthToken());

        when(restTemplate.postForEntity(eq(tokenUrl), any(HttpEntity.class), eq(String.class)))
                .thenThrow(new RuntimeException("Time out"));

        assertThrows(Exception.class, () -> adfTriggerService.getOauthToken());
    }

    // Utility for setting private fields via reflection
    private static void setField(Object target, String fieldName, Object value) {
        try {
            java.lang.reflect.Field field = target.getClass().getDeclaredField(fieldName);
            field.setAccessible(true);
            field.set(target, value);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}






