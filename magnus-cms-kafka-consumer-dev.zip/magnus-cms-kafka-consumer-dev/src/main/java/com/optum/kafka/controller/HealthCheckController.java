package com.optum.kafka.controller;

import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HealthCheckController {

    @GetMapping("/api/v1/cms-kafka/health-check")
    public ResponseEntity<String> systemHealthCheck(){
        return new ResponseEntity<>("Service is up", HttpStatusCode.valueOf(200));
    }
}
