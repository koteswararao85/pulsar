package com.optum.kafka.Models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class FilePrcsTrackError {

    private Long filePrcsKey;
    private String filePrcsName;
    private String errorMsg;
    private String processNm;
    private String processId;
    private LocalDateTime insrtDttm;
    private String insrtUserId;
    private LocalDateTime updtDttm;
    private String updtUserId;
}
