package com.optum.kafka.configuration;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectReader;
import com.optum.kafka.Models.TokenResponse;
import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;



@Slf4j
@Component
public class TokenHandler {

    @Value("${processTracker.tokenUrl}")
    private String tokenUrl;

    @Value("${processTracker.client-id}")
    private String clientId;

    @Value("${processTracker.client-secret}")
    private String clientSecret;

    @Value("${processTracker.scope}")
    private String scope;

    private static ObjectReader reader;
    @PostConstruct
    public void init() {
        ObjectMapper jsonParser = new ObjectMapper();
        jsonParser.configure(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
        jsonParser.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        this.reader = jsonParser.readerFor(TokenResponse.class);
    }

    public String getToken() {
        HttpPost httpPost = new HttpPost(tokenUrl);

        List<NameValuePair> urlParameters = new ArrayList<>();
        urlParameters.add(new BasicNameValuePair("client_id", clientId));
        urlParameters.add(new BasicNameValuePair("client_secret", clientSecret));
        urlParameters.add(new BasicNameValuePair("grant_type", "client_credentials"));
        urlParameters.add(new BasicNameValuePair("scope", scope));

        try(CloseableHttpClient httpClient = HttpClients.createDefault()) {
            httpPost.setEntity(new UrlEncodedFormEntity(urlParameters));

            HttpResponse response = httpClient.execute(httpPost);
            log.info("Token request sent");

            String responseBody = EntityUtils.toString(response.getEntity());
            log.debug("Token request response received");

            TokenResponse tokenResponse = reader.readValue(responseBody);

            if (tokenResponse.getError() != null) {
                log.error("Failed to obtain token [{}]: Error description omitted for security reasons", tokenResponse.getErrorCodes().stream().map(String::valueOf).collect(Collectors.joining(", ")));
                return "";
            }

            log.info("Token obtained successfully");
            return tokenResponse.getAccessToken();

        } catch(IOException e) {
            log.error("Failed to obtain token: {}", e.getMessage());
        }
        return "";
    }
}
