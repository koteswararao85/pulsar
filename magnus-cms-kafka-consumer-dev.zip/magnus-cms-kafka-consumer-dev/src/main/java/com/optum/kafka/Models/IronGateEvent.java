package com.optum.kafka.Models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import com.fasterxml.jackson.annotation.JsonProperty;
import org.apache.avro.generic.GenericRecord;

@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode
public class IronGateEvent {
    private String eventTypeVersion;
    private String eventId;
    private String eventType;
    private String correlationId; 
    private Long fileLoadInfoSk;
    private Long fileInfoSk;
    private String configuredFileName;
    private String configuredFilePattern;
    private String loadedFileName;
    private Long fileRecordsCount;
    private String fileLoadDate;
    private String ownershipType;
    private String teamName;
    private String outputFileName;
    private IronGateOutputFileStorageType outputFileStorageType;
    private String outputFilePath;
    private String eventTime;
    private String fileType;
    private String version;

@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode
    public static class IronGateOutputFileStorageType {
        @JsonProperty("azure")
        private String azure;
    }

    public IronGateEvent(GenericRecord record) {
        Object eventTypeVersionObj = record.get("eventTypeVersion");
        this.eventTypeVersion = eventTypeVersionObj != null ? eventTypeVersionObj.toString() : null;

        Object eventIdObj = record.get("eventId");
        this.eventId = eventIdObj != null ? eventIdObj.toString() : null;

        Object eventTypeObj = record.get("eventType");
        this.eventType = eventTypeObj != null ? eventTypeObj.toString() : null;

        Object correlationIdObj = record.get("correlationId");
        this.correlationId = correlationIdObj != null ? correlationIdObj.toString() : null;

        Object fileLoadInfoSkObj = record.get("fileLoadInfoSk");
        this.fileLoadInfoSk = fileLoadInfoSkObj != null ? Long.valueOf(fileLoadInfoSkObj.toString()) : null;

        Object fileInfoSkObj = record.get("fileInfoSk");
        this.fileInfoSk = fileInfoSkObj != null ? Long.valueOf(fileInfoSkObj.toString()) : null;

        Object configuredFileNameObj = record.get("configuredFileName");
        this.configuredFileName = configuredFileNameObj != null ? configuredFileNameObj.toString() : null;

        Object configuredFilePatternObj = record.get("configuredFilePattern");
        this.configuredFilePattern = configuredFilePatternObj != null ? configuredFilePatternObj.toString() : null;

        Object loadedFileNameObj = record.get("loadedFileName");
        this.loadedFileName = loadedFileNameObj != null ? loadedFileNameObj.toString() : null;

        Object fileRecordsCountObj = record.get("fileRecordsCount");
        this.fileRecordsCount = fileRecordsCountObj != null ? Long.valueOf(fileRecordsCountObj.toString()) : null;

        Object fileLoadDateObj = record.get("fileLoadDate");
        this.fileLoadDate = fileLoadDateObj != null ? fileLoadDateObj.toString() : null;

        Object ownershipTypeObj = record.get("ownershipType");
        this.ownershipType = ownershipTypeObj != null ? ownershipTypeObj.toString() : null;

        Object teamNameObj = record.get("teamName");
        this.teamName = teamNameObj != null ? teamNameObj.toString() : null;

        Object outputFileNameObj = record.get("outputFileName");
        this.outputFileName = outputFileNameObj != null ? outputFileNameObj.toString() : null;

        Object outputFileStorageTypeObj = record.get("outputFileStorageType");
        if (outputFileStorageTypeObj instanceof GenericRecord) {
            GenericRecord storageRecord = (GenericRecord) outputFileStorageTypeObj;
            Object azureObj = storageRecord.get("azure");
            this.outputFileStorageType = azureObj != null
                    ? new IronGateOutputFileStorageType(azureObj.toString())
                    : null;
        } else {
            this.outputFileStorageType = null;
        }

        Object outputFilePathObj = record.get("outputFilePath");
        this.outputFilePath = outputFilePathObj != null ? outputFilePathObj.toString() : null;

        Object eventTimeObj = record.get("eventTime");
        this.eventTime = eventTimeObj != null ? eventTimeObj.toString() : null;

        Object fileTypeObj = record.get("fileType");
        this.fileType = fileTypeObj != null ? fileTypeObj.toString() : null;

        Object versionObj = record.get("version");
        this.version = versionObj != null ? versionObj.toString() : null;
    }
}


