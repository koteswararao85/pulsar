package com.optum.kafka.Models;

import com.optum.kafka.util.FilePrcsStatus;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class FilePrcsStatusBatchUpdate {
    private List<String> filePrcsNameList;
    @NotNull
    private String updtUserId;
    @NotNull
    private FilePrcsStatus filePrcsStatus;
    private String batchRunId;
}
