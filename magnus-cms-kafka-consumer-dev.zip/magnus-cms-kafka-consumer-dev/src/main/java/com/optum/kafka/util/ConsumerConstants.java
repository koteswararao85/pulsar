package com.optum.kafka.util;

import java.util.Set;

public class ConsumerConstants {
    private ConsumerConstants() {
    }
    public static final String KAFKA_CONUMSER = "CMS_KAFKA_CONSUMER";
    public static final String PIPELINE_NAME = "pl_cms_dataintake_file";
    public static final String DATAINTAKE_FILE = "_dataintake_file";
    // public static final Set<String> NON_CLIENT_FILE_TYPES =  Set.of("PAFDAILYSTATUS","CMS_PRECL");
}
