package com.optum.kafka.Models;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Collection;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TokenResponse {

    @JsonProperty("token_type")
    private String tokenType;
    @JsonProperty("expires_in")
    private int expiresIn;
    @JsonProperty("ext_expires_in")
    private int extExpiresIn;
    @JsonProperty("access_token")
    private String accessToken;
    @JsonProperty("error")
    private String error;
    @JsonProperty("error_description")
    private String errorDescription;
    @JsonProperty("error_codes")
    private Collection<Long> errorCodes;
    @JsonProperty("timestamp")
    private String timestamp;
    @JsonProperty("trace_id")
    private String traceId;
    @JsonProperty("correlation_id")
    private String correlationId;
}
