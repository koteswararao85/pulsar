package com.optum.kafka.Listener;

import com.optum.kafka.Models.IronGateEvent;
import com.optum.kafka.Models.FilePrcs;
import com.optum.kafka.Models.FilePrcsTrack;
import com.optum.kafka.service.TrackerApi;
import org.apache.avro.Schema;
import org.apache.avro.generic.GenericData;
import org.apache.avro.generic.GenericRecord;
import org.junit.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.kafka.support.Acknowledgment;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

class IronGateDataConsumerTest {

    @Mock
    private Acknowledgment acknowledgment;

    private GenericRecord record;

    @Mock
    private TrackerApi trackerApi;

    @InjectMocks
    private IronGateDataConsumer irongateDataConsumer;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        // Set the required @Value field via reflection
        setField(irongateDataConsumer, "ironGateStorageAccount", "test-storage-account");
        // Initialize the ObjectReader via @PostConstruct
        irongateDataConsumer.init();
    }

    @Test
    void testConsumeEvent_SuccessfulDeserialization() throws Exception {
        // Arrange
        String jsonMessage = "{"
                + "\"eventTypeVersion\":\"v1\","
                + "\"eventId\":\"2377\","
                + "\"eventType\":\"FilePublished\","
                + "\"eventTime\":\"2025-07-03 03:25:24\","
                + "\"correlationId\":\"2377\","
                + "\"fileLoadInfoSk\":2377,"
                + "\"fileInfoSk\":397,"
                + "\"configuredFileName\":\"P.Fxxxxx.MONMEMD.Dyymmdd.Thhmmsst\","
                + "\"configuredFilePattern\":\"P.Fxxxxx.MONMEMD.Dyymmdd.Thhmmsst\","
                + "\"loadedFileName\":\"P.FH6870.MONMEMD.D250503.T0536412\","
                + "\"fileRecordsCount\":35,"
                + "\"fileLoadDate\":\"2025-07-03 08:22:59.973\","
                + "\"ownershipType\":\"Owned\","
                + "\"teamName\":\"CMS Data Service\","
                + "\"outputFileName\":\"2377_397.parquet\","
                + "\"outputFileStorageType\":{\"azure\":\"irongate-test\"},"
                + "\"outputFilePath\":\"outbound_files/2377_397.parquet\","
                + "\"fileType\":\"MMR\","
                + "\"version\":\"1\""
                + "}";

        record = getAvroRecord();
        when(trackerApi.trackAndCreateFile(any(FilePrcs.class)))
                .thenReturn(new ResponseEntity<>(new FilePrcsTrack(), HttpStatus.OK));

        // Act
        irongateDataConsumer.consumeEvent(record, acknowledgment);

        // Assert
        verify(trackerApi, times(1)).trackAndCreateFile(any(FilePrcs.class));
        verify(acknowledgment, times(1)).acknowledge();
    }

    @Test
    void testIronGateEventConstructorFromAvroSchema() {
        GenericRecord record = getAvroRecord();

        IronGateEvent ironGateEvent = new IronGateEvent(record);

        Assert.assertEquals("eventTypeVersion", ironGateEvent.getEventTypeVersion());
        Assert.assertEquals("eventId", ironGateEvent.getEventId());
        Assert.assertEquals("eventType", ironGateEvent.getEventType());
        Assert.assertEquals("correlationId", ironGateEvent.getCorrelationId());
        Assert.assertEquals(1, (long) ironGateEvent.getFileLoadInfoSk());
        Assert.assertEquals(2, (long) ironGateEvent.getFileInfoSk());
        Assert.assertEquals("configuredFileName", ironGateEvent.getConfiguredFileName());
        Assert.assertEquals("configuredFilePattern", ironGateEvent.getConfiguredFilePattern());
        Assert.assertEquals("loadedFileName", ironGateEvent.getLoadedFileName());
        Assert.assertEquals(1, (long) ironGateEvent.getFileRecordsCount());
        Assert.assertEquals("fileLoadDate", ironGateEvent.getFileLoadDate());
        Assert.assertEquals("ownershipType", ironGateEvent.getOwnershipType());
        Assert.assertEquals("teamName", ironGateEvent.getTeamName());
        Assert.assertEquals("outputFileName", ironGateEvent.getOutputFileName());
        Assert.assertEquals("outputFilePath", ironGateEvent.getOutputFilePath());
        Assert.assertEquals("eventTime", ironGateEvent.getEventTime());
        Assert.assertEquals("azure", ironGateEvent.getOutputFileStorageType().getAzure());
    }

    // Utility for setting private fields via reflection
    private static void setField(Object target, String fieldName, Object value) {
        try {
            java.lang.reflect.Field field = target.getClass().getDeclaredField(fieldName);
            field.setAccessible(true);
            field.set(target, value);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private static GenericRecord getAvroRecord() {
        String schemaString = "{\n" +
                "  \"type\": \"record\",\n" +
                "  \"name\": \"FilePublishedEvent\",\n" +
                "  \"namespace\": \"com.optum.rqns.irongatex.publish\",\n" +
                "  \"fields\": [\n" +
                "    { \"name\": \"eventTypeVersion\", \"type\": \"string\" },\n" +
                "    { \"name\": \"eventId\", \"type\": \"string\" },\n" +
                "    { \"name\": \"eventType\", \"type\": \"string\" },\n" +
                "    { \"name\": \"eventTime\", \"type\": \"string\" },\n" +
                "    { \"name\": \"correlationId\", \"type\": \"string\" },\n" +
                "    { \"name\": \"fileLoadInfoSk\", \"type\": \"int\" },\n" +
                "    { \"name\": \"fileInfoSk\", \"type\": \"int\" },\n" +
                "    { \"name\": \"configuredFileName\", \"type\": \"string\" },\n" +
                "    { \"name\": \"configuredFilePattern\", \"type\": \"string\" },\n" +
                "    { \"name\": \"loadedFileName\", \"type\": \"string\" },\n" +
                "    { \"name\": \"fileRecordsCount\", \"type\": \"int\" },\n" +
                "    { \"name\": \"fileLoadDate\", \"type\": \"string\" },\n" +
                "    { \"name\": \"ownershipType\", \"type\": \"string\" },\n" +
                "    { \"name\": \"teamName\", \"type\": \"string\" },\n" +
                "    { \"name\": \"outputFileName\", \"type\": \"string\" },\n" +
                "    {\n" +
                "      \"name\": \"outputFileStorageType\",\n" +
                "      \"type\": {\n" +
                "        \"type\": \"record\",\n" +
                "        \"name\": \"OutputFileStorageType\",\n" +
                "        \"fields\": [\n" +
                "          { \"name\": \"azure\", \"type\": \"string\" }\n" +
                "        ]\n" +
                "      }\n" +
                "    },\n" +
                "    { \"name\": \"outputFilePath\", \"type\": \"string\" },\n" +
                "    { \"name\": \"fileType\", \"type\": \"string\" },\n" +
                "    { \"name\": \"version\", \"type\": \"string\" },\n" +
                "    { \"name\": \"contractNumber\", \"type\": \"string\" },\n" +
                "    {\n" +
                "      \"name\": \"additionalInfo\",\n" +
                "      \"type\": {\n" +
                "        \"type\": \"map\",\n" +
                "        \"values\": \"string\"\n" +
                "      }\n" +
                "    }\n" +
                "  ]\n" +
                "}";

        Schema schema = new Schema.Parser().parse(schemaString);

        String outputFileStorageTypeSchemaString = "{\n" +
                "        \"type\": \"record\",\n" +
                "        \"name\": \"OutputFileStorageType\",\n" +
                "        \"fields\": [\n" +
                "          { \"name\": \"azure\", \"type\": \"string\" }\n" +
                "        ]\n" +
                "      }";

        Schema outputFileStorageTypeSchema = new Schema.Parser().parse(outputFileStorageTypeSchemaString);

        GenericRecord record = new GenericData.Record(schema);
        GenericRecord outputFileStorageType = new GenericData.Record(outputFileStorageTypeSchema);
        record.put("eventTypeVersion", "eventTypeVersion");
        record.put("eventId", "eventId");
        record.put("eventType", "eventType");
        record.put("correlationId", "correlationId");
        record.put("fileLoadInfoSk", 1);
        record.put("fileInfoSk", 2);
        record.put("configuredFileName", "configuredFileName");
        record.put("configuredFilePattern", "configuredFilePattern");
        record.put("loadedFileName", "loadedFileName");
        record.put("fileRecordsCount", 1);
        record.put("fileLoadDate", "fileLoadDate");
        record.put("ownershipType", "ownershipType");
        record.put("teamName", "teamName");
        record.put("outputFileName", "outputFileName");
        record.put("outputFilePath", "outputFilePath");
        record.put("eventTime", "eventTime");

        outputFileStorageType.put("azure", "azure");
        record.put("outputFileStorageType", outputFileStorageType);
        return record;
    }
}