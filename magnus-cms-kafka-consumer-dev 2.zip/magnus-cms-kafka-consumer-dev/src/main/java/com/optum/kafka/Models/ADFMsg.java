package com.optum.kafka.Models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ADFMsg {
    private String clientId;
    private String fileName;
    private String fileType;
    private String lob;
    private String location;
    private String storage;
    private String container;
    private Long dataCount;
    private String correlationId;
    private String version;
    private Long fileLoadInfoSk;
    private Long fileInfoSk;
}
