package com.optum.kafka.util;

public class ConsumerConstants {
    private ConsumerConstants() {
    }
    public static final String KAFKA_CONUMSER = "CMS_KAFKA_CONSUMER";
    public static final String PIPELINE_NAME = "pl_cms_dataintake_file";
    public static final String DATAINTAKE_FILE = "_dataintake_file";
    public static final String LOG_ADF_URL = "ADF URL : {}";
    public static final String LOG_GETTING_TOKEN = "Getting Token from Auth provider";
    public static final String LOG_OAUTH_TOKEN_EMPTY = "Oauth Token is empty";
    public static final String LOG_OAUTH_TOKEN_RETRIEVED = "Oauth Token retrieved";
    public static final String HEADER_AUTHORIZATION = "Authorization";
    public static final String BEARER_PREFIX = "Bearer ";
    // public static final Set<String> NON_CLIENT_FILE_TYPES =  Set.of("PAFDAILYSTATUS","CMS_PRECL");
}
