package com.optum.kafka.util;

import lombok.Getter;

@Getter
public enum ErrorCodes {

    AZURE_ADF_OAUTH_TOKEN_GENERATE_ERROR(0,"azure token generation  error "),

    AZURE_ADF_PIPELINE_ERROR(1,"ADF pipeline error  message");

    private final int code;

    private final String description;
    ErrorCodes(int code, String description) {
        this.code = code;
        this.description = description;
    }
}
