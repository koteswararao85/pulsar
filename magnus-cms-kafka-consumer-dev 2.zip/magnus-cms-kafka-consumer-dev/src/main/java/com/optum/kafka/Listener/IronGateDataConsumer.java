package com.optum.kafka.Listener;

import java.net.MalformedURLException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectReader;

import jakarta.annotation.PostConstruct;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;
import com.optum.kafka.Models.FilePrcs;
import com.optum.kafka.Models.FilePrcsTrack;
import com.optum.kafka.Models.IronGateEvent;
import com.optum.kafka.util.IrongateClassMapper;
import com.optum.kafka.service.TrackerApi;
import org.apache.avro.generic.GenericRecord;

import lombok.extern.slf4j.Slf4j;
@Component
@Slf4j
public class IronGateDataConsumer {
    // @Autowired
    // private ObjectMapper objectMapper;
    
    @Autowired
    private TrackerApi trackerApi;

    private ObjectReader reader;

    @Value("${spring.kafka.consumer.irongate-sa}")
    private String ironGateStorageAccount;

    @PostConstruct
    public void init() {
        // Configuring ObjectMapper for JSON parsing.
        ObjectMapper jsonParser = new ObjectMapper();
        jsonParser.configure(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
        jsonParser.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        reader = jsonParser.readerFor(IronGateEvent.class);
    }
    
    @KafkaListener(topics = "${spring.kafka.consumer.irongate-topic}", id = "${spring.kafka.consumer.irongate-group-id}")
    public void consumeEvent(@Payload GenericRecord record, Acknowledgment acknowledgment) throws MalformedURLException {
        IronGateEvent event = null;
        try {
            log.info("Received message: {}", record);
            // Deserialize the record value into an IronGateEvent object
            event = new IronGateEvent(record);
            log.info("Converted to IronGateEvent: {}", event);
        } catch (Exception e) {
            // Log the error if deserialization fails
            log.error("Error processing message: {}", e.getMessage());
            return;
        }
        // If the event object is deserialized
        if (event != null) {
    
            FilePrcs filePrcs = IrongateClassMapper.setFilePrcsFromIronGateEvent(event, ironGateStorageAccount);
            
            log.info("FilePrcs object created from the message");
            ResponseEntity<FilePrcsTrack> response = trackerApi.trackAndCreateFile(filePrcs);
            if (!response.getStatusCode().is2xxSuccessful()) {
                log.info("Failed to create tracking for object {}", record);
                return;
            }
    
            acknowledgment.acknowledge();
            log.info("Consumed message from Kafka");
    
        }
    }
}
