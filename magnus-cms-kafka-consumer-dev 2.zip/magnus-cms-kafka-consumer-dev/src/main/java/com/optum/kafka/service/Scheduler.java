package com.optum.kafka.service;


import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectReader;
import com.optum.kafka.Models.ADFMsg;
import com.optum.kafka.Models.EventTriggerBody;
import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import net.javacrumbs.shedlock.spring.annotation.SchedulerLock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;



@Component
@Slf4j
public class Scheduler {

    @Autowired
    private ADFTriggerService adfTriggerService;

    @Autowired
    private TrackerApi trackerApi;

    @Value("${processTracker.max-retry-attempts}")
    private Long maxRetryAttempts;

    @Value("${scheduler.fixedDelay}")
    private String fixedDelay;

    private final List<String> fileTypes = Arrays.asList("MMR", "TRR", "MOR PART C", "MOR PART D", "MOR PART C ANNUAL", "MOR PART D ANNUAL", "TRR 2017", "TRR 2025", "MAO002", "MAO004", "MSO");

    private static ObjectReader reader;

    @PostConstruct
    public void init() {
        ObjectMapper jsonParser = new ObjectMapper();
        jsonParser.configure(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
        jsonParser.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        this.reader = jsonParser.readerFor(ADFMsg.class);
    }


//    @Scheduled(fixedDelayString = "${scheduler.fixedDelay}")
    @Scheduled(fixedDelay = 300000) // 5 minutes in milliseconds
    @SchedulerLock(name = "cms_consumer_scheduler", lockAtMostFor = "PT5M", lockAtLeastFor = "PT3M")
    public void performTask() throws MalformedURLException {
        log.info("Scheduler started at : " + System.currentTimeMillis());
        for (String fileType : fileTypes) {
            List<String> filePrcsNames = new ArrayList<>();
            List<ADFMsg> adfMsgList = new ArrayList<>();
            String sanitizedFileType = fileType.replace('\n', '_').replace('\r', '_');
            log.info("Fetching event trigger bodies for fileType: " + sanitizedFileType);
            ResponseEntity<List<EventTriggerBody>> response = trackerApi.fetchEventTriggerBodies(fileType, maxRetryAttempts);

            if (response.getBody() == null || response.getBody().isEmpty()) {
                log.info("No Files present to process for fileType: " + fileType);
                continue;
            }

            String sanitizedResponseBody = response.getBody().toString().replace('\n', '_').replace('\r', '_');
            log.info("Response received for fileType: " + fileType + ". Status code: " + response.getStatusCode() + " and files: " + sanitizedResponseBody);
            if (response.getStatusCode().is2xxSuccessful()) {
                List<EventTriggerBody> eventTriggerBodies = response.getBody();
                for (EventTriggerBody eventTriggerBody : eventTriggerBodies) {
                    try {
                        ADFMsg adfMsg = reader.readValue(eventTriggerBody.getEventTriggerBody());
                        log.info("Deserialized AnrADFMsg for fileType " + sanitizedFileType + ": " + adfMsg.toString().replace("\n", "").replace("\r", ""));
                        adfMsgList.add(adfMsg);
                        filePrcsNames.add(eventTriggerBody.getFilePrcsName());
                    } catch (Exception e) {
                        log.error("Failed to deserialize eventTriggerBody for fileType " + fileType, e);
                    }
                }
                try {
                    trackerApi.increaseRetryCountByFilePrcsNameIn(filePrcsNames);
                } catch (Exception ex) {
                    log.error("Failed to increment the Retry count for " + fileType, ex);
                }
                log.info("Triggering ADF pipelines for fileType: " + fileType);
                adfTriggerService.ADFTriggerByEventTriggerMessages(adfMsgList);
            } else {
                log.error("Failed to fetch event trigger bodies for fileType: " + fileType + ". Status code: " + response.getStatusCode());
            }
        }
    }
}
