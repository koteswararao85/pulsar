package com.optum.kafka.util;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.optum.kafka.Models.ADFMsg;
import com.optum.kafka.Models.FilePrcs;
import com.optum.kafka.Models.IronGateEvent;
import java.net.MalformedURLException;
import java.net.URL;

public class IrongateClassMapper {

    private static final ObjectWriter objectWriter;

    static {
        ObjectMapper objectMapper = new ObjectMapper();
        objectWriter = objectMapper.writer();
    }

    public static FilePrcs setFilePrcsFromIronGateEvent(IronGateEvent event, String ironGateStorageAccount) throws MalformedURLException {
        FilePrcs filePrcs = new FilePrcs();
        filePrcs.setCorrelationId(event.getCorrelationId());
        filePrcs.setFilePrcsName(event.getOutputFileName());
        filePrcs.setFilePath(event.getOutputFilePath()); //outputfilepath
        filePrcs.setFileName(event.getOutputFileName());
        filePrcs.setStorageAccount(ironGateStorageAccount); 
        filePrcs.setStorageUrlID("https://"+ ironGateStorageAccount + ".dfs.core.windows.net/" + event.getOutputFileStorageType().getAzure() + "/"  + event.getOutputFilePath()); 
        filePrcs.setOrigSourceInfo("RQS");
        filePrcs.setInsrtUserId(ConsumerConstants.KAFKA_CONUMSER);
        filePrcs.setUpdtUserId(ConsumerConstants.KAFKA_CONUMSER);
        filePrcs.setRecordCount(Math.toIntExact(event.getFileRecordsCount()));
        filePrcs.setFilePrcsStatus(FilePrcsStatus.MESSAGE_RECEIVED);
        filePrcs.setFilePrcsTypeEnum(FilePrcsType.IN); 
        filePrcs.setFileType(event.getFileType()); 
        filePrcs.setRetryCount(0L);
        filePrcs.setEventMessage(event.toString());

        try {
            filePrcs.setEventTriggerBody(objectWriter.writeValueAsString(mapIronGateEventToADFMsg(event, ironGateStorageAccount)));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return filePrcs;
    }

    public static ADFMsg mapIronGateEventToADFMsg(IronGateEvent event, String ironGateStorageAccount) throws MalformedURLException {
        ADFMsg adfMsg = new ADFMsg();

        URL storageaccounturl = new URL("https://"+ ironGateStorageAccount + ".dfs.core.windows.net/" + event.getOutputFileStorageType().getAzure() + "/"  + event.getOutputFilePath()); 
        String path = storageaccounturl.getPath();
        
        adfMsg.setFileName(event.getOutputFileName());        
        adfMsg.setFileType(event.getFileType()); 
        adfMsg.setLocation(event.getOutputFilePath());
        adfMsg.setStorage(ironGateStorageAccount);
        adfMsg.setContainer(path.split("/")[1]);
        adfMsg.setDataCount((long) Math.toIntExact(event.getFileRecordsCount()));
        adfMsg.setCorrelationId(event.getCorrelationId());
        adfMsg.setVersion(event.getVersion());
        adfMsg.setFileLoadInfoSk((long) Math.toIntExact(event.getFileLoadInfoSk()));
        adfMsg.setFileInfoSk((long) Math.toIntExact(event.getFileInfoSk()));


        return adfMsg;
    }

    public ADFMsg mapFilePrcsToADFMsgIronGate(FilePrcs filePrcs, String ironGateStorageAccount) throws MalformedURLException {
        ADFMsg adfMsg=new ADFMsg();
        URL storageaccounturl = new URL(filePrcs.getStorageUrlID());
        String path = storageaccounturl.getPath();

        adfMsg.setFileName(filePrcs.getFileName());
        adfMsg.setFileType(filePrcs.getFileType());
        adfMsg.setLocation(filePrcs.getFilePath());
        adfMsg.setStorage(ironGateStorageAccount);
        adfMsg.setContainer(path.split("/")[1]);
        adfMsg.setDataCount((long) Math.toIntExact(filePrcs.getRecordCount()));
        adfMsg.setCorrelationId(filePrcs.getCorrelationId());
        return adfMsg;
    }

}