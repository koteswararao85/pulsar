package com.optum.kafka.util;

public enum FilePrcsType {
    IN,
    OUT;
}
