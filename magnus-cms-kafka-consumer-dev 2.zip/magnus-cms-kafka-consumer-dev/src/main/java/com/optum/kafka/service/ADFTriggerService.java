package com.optum.kafka.service;


import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectReader;
import com.optum.kafka.Models.ADFMsg;
import com.optum.kafka.Models.FilePrcs;
import com.optum.kafka.Models.FilePrcsTrackError;
import com.optum.kafka.util.IrongateClassMapper;
import com.optum.kafka.util.ConsumerConstants;
import com.optum.kafka.util.FilePrcsStatus;
import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import static com.optum.kafka.util.ErrorCodes.AZURE_ADF_OAUTH_TOKEN_GENERATE_ERROR;
import static com.optum.kafka.util.ErrorCodes.AZURE_ADF_PIPELINE_ERROR;


import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.List;

@Service
@Slf4j
public class ADFTriggerService {
    @Value("${azure.Oauth.azure-token-url}")
    private String tokenUrl;
    @Value("${azure.Oauth.grant-type}")
    private String grantType;
    @Value("${azure.Oauth.client-id}")
    private String clientId;
    @Value("${azure.Oauth.client-key}")
    private String clientSecret;

    @Value("${azure.Oauth.resource}")
    private String resource;

    @Value("${azure.adfConfiguration.subscription-Id}")
    private String subscriptionId;


    @Value("${azure.adfConfiguration.resource-group-name}")
    private String resourceGroupName;

    @Value("${azure.adfConfiguration.factory-name}")
    private String adfFactoryName;

    @Autowired
    private TrackerApi trackerApi;

    @Autowired
    private RestTemplate template;

    private ObjectReader reader;

    @PostConstruct
    public void init() {
        ObjectMapper jsonParser = new ObjectMapper();
        jsonParser.configure(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
        jsonParser.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        this.reader = jsonParser.readerFor(JsonNode.class);
    }

    private String sanitizeLogMessage(String fileName) {
        return fileName.replace("\n", "").replace("\r", "");
    }

    private HttpHeaders buildJsonAuthHeaders(String tokenValue) {
        HttpHeaders headers = new HttpHeaders();
        headers.set(ConsumerConstants.HEADER_AUTHORIZATION, ConsumerConstants.BEARER_PREFIX + tokenValue);
        headers.setContentType(MediaType.APPLICATION_JSON);
        return headers;
    }

    private String buildAdfUrlForFileType(String fileType) {
        if ("MSO".equalsIgnoreCase(fileType)) {
            return getADFTriggerUrl("pl_" + fileType.toLowerCase() + ConsumerConstants.DATAINTAKE_FILE);
        }
        return getADFTriggerUrl(ConsumerConstants.PIPELINE_NAME);
    }

    private void processSingleAdfMessage(ADFMsg adfMsg, List<String> filePrcsNames) throws Exception {
        log.info("Trigger ADF Pipeline started with the file {}", sanitizeLogMessage(adfMsg.getFileName()));
        String tokenValue = getOauthToken();
        log.debug("Generated azure token completed");
        String adfUrl = buildAdfUrlForFileType(adfMsg.getFileType());
        HttpHeaders adfHeaders = buildJsonAuthHeaders(tokenValue);
        log.info("Sending ADF Msg to ADF pipeline {}", sanitizeLogMessage(adfMsg.toString()));
        HttpEntity<ADFMsg> requestEntity = new HttpEntity<>(adfMsg, adfHeaders);
        log.debug("Constructing ADF URL {}", sanitizeLogMessage(adfUrl));
        log.info(ConsumerConstants.LOG_ADF_URL, sanitizeLogMessage(adfUrl));
        template.exchange(adfUrl, HttpMethod.POST, requestEntity, String.class);
        filePrcsNames.add(adfMsg.getFileName());
        log.info("Trigger ADF Pipeline completed");
    }

    @Retryable
    public String ADFTrigger(FilePrcs filePrcs, String ironGateStorageAccount) throws MalformedURLException {
        IrongateClassMapper mapper  = new IrongateClassMapper();
        ADFMsg adfMsg = mapper.mapFilePrcsToADFMsgIronGate(filePrcs, ironGateStorageAccount);
        String tokenValue = null;
        try{
            log.info(" trigger ADF Pipeline started with the file {} ", sanitizeLogMessage(filePrcs.getFilePrcsName()) );
            tokenValue = getOauthToken();
            log.debug(" generated azure token completed  ");
            String adfUrl = getADFTriggerUrl(ConsumerConstants.PIPELINE_NAME);
            HttpHeaders adfHeaders = buildJsonAuthHeaders(tokenValue);
            log.info("Sending ADF Msg to ADF pipeline {}", sanitizeLogMessage(adfMsg.toString()));
            HttpEntity<ADFMsg> requestEntity = new HttpEntity<>(adfMsg, adfHeaders);
            log.debug(" constructing ADF URL   {} ", sanitizeLogMessage(adfUrl));
            log.info(ConsumerConstants.LOG_ADF_URL, sanitizeLogMessage(adfUrl));
            template.exchange(adfUrl, HttpMethod.POST, requestEntity, String.class);
            log.info(" trigger ADF Pipeline completed");
        } catch (Exception exception) {
            log.error(" Exception occurred while triggering ADF pipeline the message stack trace: {}, exception name: {}, error code : {} , error description : {}  " ,
                    exception.getStackTrace(), exception.getMessage(), AZURE_ADF_PIPELINE_ERROR.name(),  AZURE_ADF_PIPELINE_ERROR.getDescription());
            FilePrcsTrackError trackError = new FilePrcsTrackError(null, filePrcs.getFilePrcsName(),"Failed to invoke ADF pipeline due to :"+exception.getMessage(),null,null,null, ConsumerConstants.KAFKA_CONUMSER,null, ConsumerConstants.KAFKA_CONUMSER);
            String adfUrl = getADFTriggerUrl(ConsumerConstants.PIPELINE_NAME);
            log.info(ConsumerConstants.LOG_ADF_URL, sanitizeLogMessage(adfUrl));
            trackerApi.createTrackError(trackError);
        }
        return filePrcs.getFilePrcsName();
    }


    @Retryable
    public List<String> ADFTriggerByEventTriggerMessages(List<ADFMsg> adfMsgList) throws MalformedURLException {
        List<String> filePrcsNames = new ArrayList<>();
        int batchSize = 100; // Define batch size
        for (int i = 0; i < adfMsgList.size(); i += batchSize) {
            List<ADFMsg> batch = adfMsgList.subList(i, Math.min(i + batchSize, adfMsgList.size()));
            try {
                log.info("Processing batch of size {}", batch.size());
                for (ADFMsg adfMsg : batch) {
                    try {
                        processSingleAdfMessage(adfMsg, filePrcsNames);
                    } catch (Exception exception) {
                        log.error("Exception occurred while triggering ADF pipeline. Stack trace: {}, exception name: {}, error code: {}, error description: {}",
                                exception.getStackTrace(), exception.getMessage(), AZURE_ADF_PIPELINE_ERROR.name(), AZURE_ADF_PIPELINE_ERROR.getDescription());
                        FilePrcsTrackError trackError = new FilePrcsTrackError(null, adfMsg.getFileName(),
                                "Failed to invoke ADF pipeline due to: " + exception.getMessage(), null, null, null,
                                ConsumerConstants.KAFKA_CONUMSER, null, ConsumerConstants.KAFKA_CONUMSER);
                        String adfUrl = getADFTriggerUrl(ConsumerConstants.PIPELINE_NAME);
                        log.info(ConsumerConstants.LOG_ADF_URL, sanitizeLogMessage(adfUrl));
                        trackerApi.createTrackError(trackError);
                    }
                }
                trackerApi.batchUpdateFilePrcsTrack(filePrcsNames, FilePrcsStatus.valueOf("FILE_TRANSFER_INITIATED"));
            } catch (Exception batchException) {
                log.error("Exception occurred while processing batch. Stack trace: {}, exception name: {}, error message: {}",
                        batchException.getStackTrace(), batchException.getClass().getName(), batchException.getMessage());
            }
        }
        return filePrcsNames;
    }



    private String getADFTriggerUrl(String pipeline) {
        StringBuilder adfFactoryURL = new StringBuilder("https://management.azure.com/subscriptions/");
        adfFactoryURL.append(subscriptionId);
        adfFactoryURL.append("/resourceGroups/");
        adfFactoryURL.append(resourceGroupName);
        adfFactoryURL.append("/providers/Microsoft.DataFactory/factories/");
        adfFactoryURL.append(adfFactoryName);
        adfFactoryURL.append("/pipelines/");
        adfFactoryURL.append(pipeline);
        adfFactoryURL.append("/createRun?api-version=2018-06-01");
        return adfFactoryURL.toString();
    }
    @Retryable
    public String getOauthToken() throws Exception {

        try {
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
            MultiValueMap<String, String> inputMap = new LinkedMultiValueMap<>();
            inputMap.add("grant_type", grantType);
            inputMap.add("client_id", clientId);
            inputMap.add("client_secret", clientSecret);
            inputMap.add("resource", resource);
            HttpEntity<MultiValueMap<String, String>> entity = new HttpEntity<>(inputMap, headers);
            ResponseEntity<String> response = template.postForEntity(tokenUrl, entity, String.class);
            return reader.readTree(response.getBody()).get("access_token").asText();
        } catch (Exception exception) {

            log.error(" Exception occurred while getting ADF Oauth token pipeline the message stack trace: {}, exception name: {}, error code : {} , error description : {}  " ,
                    exception.getStackTrace(), exception.getMessage(), AZURE_ADF_OAUTH_TOKEN_GENERATE_ERROR.name(),  AZURE_ADF_OAUTH_TOKEN_GENERATE_ERROR.getDescription());

            throw exception;
        }
    }
}
