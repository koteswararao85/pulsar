package com.optum.magnusopsieventconsumer.configuration;

import com.optum.magnusopsieventconsumer.util.AvroDeserializer;
import com.optum.rqns.events.v1.analytics.AnalyticsEvent;
import com.optum.rqns.events.v1.ccdgateway.DDGAPCPGapFileInfo;
import org.apache.kafka.clients.admin.AdminClient;
import org.apache.kafka.clients.admin.AdminClientConfig;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.config.SslConfigs;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.core.KafkaAdmin;
import org.springframework.kafka.listener.ContainerProperties;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.util.HashMap;
import java.util.Map;

@Configuration
@EnableKafka
public class KafkaConsumerConfig {

    @Value("${spring.kafka.maxPollRecords}")
    private String maxPollRecords;

    @Value("${spring.kafka.heartBeatInterval}")
    private String heartBeatInterval;

    @Value("${spring.kafka.sessionTimeOut}")
    private String sessionTimeOut;

    @Value("${spring.kafka.maxPollIntervalMsConfig}")
    private String maxPollIntervalMsConfig;

    @Value("${spring.kafka.concurrency}")
    private int concurrency;

    @Value("${spring.kafka.autoCommitReset}")
    private String autoCommitReset;

    @Value("${spring.kafka.autoCommit}")
    private Boolean autoCommit;

    private Map<String, Object> kafkaProperties(String bootstrapAddress, String groupId, String truststoreLocation, String truststorePassword, String keystoreLocation, String keystorePassword, String securityProtocol) {
        Map<String, Object> props = new HashMap<>();
        props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapAddress);
        props.put(ConsumerConfig.GROUP_ID_CONFIG, groupId);
        props.put(ConsumerConfig.CLIENT_ID_CONFIG, groupId + "-magnus");
        props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, AvroDeserializer.class);
        props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, autoCommit);
        props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, autoCommitReset);
        props.put(ConsumerConfig.MAX_POLL_RECORDS_CONFIG, maxPollRecords);
        props.put(ConsumerConfig.HEARTBEAT_INTERVAL_MS_CONFIG, heartBeatInterval);
        props.put(ConsumerConfig.SESSION_TIMEOUT_MS_CONFIG, sessionTimeOut);
        props.put(ConsumerConfig.MAX_POLL_INTERVAL_MS_CONFIG, maxPollIntervalMsConfig);
        props.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG, truststoreLocation);
        props.put(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG, truststorePassword);
        props.put(SslConfigs.SSL_KEYSTORE_LOCATION_CONFIG, keystoreLocation);
        props.put(SslConfigs.SSL_KEYSTORE_PASSWORD_CONFIG, keystorePassword);
        props.put(AdminClientConfig.SECURITY_PROTOCOL_CONFIG, securityProtocol);
        return props;
    }

    @Bean
    public ConsumerFactory<String, AnalyticsEvent> opsiConsumerFactory(
            @Value("${spring.kafka.opsi.bootstrap-servers}") String bootstrapAddress,
            @Value("${spring.kafka.opsi.consumer.group-id}") String groupId,
            @Value("${spring.kafka.opsi.ssl.truststore.location}") String truststoreLocation,
            @Value("${spring.kafka.opsi.ssl.truststore.password}") String truststorePassword,
            @Value("${spring.kafka.opsi.ssl.keystore.location}") String keystoreLocation,
            @Value("${spring.kafka.opsi.ssl.keystore.password}") String keystorePassword,
            @Value("${spring.kafka.opsi.security.protocol}") String securityProtocol
    ) throws CertificateException, IOException, NoSuchAlgorithmException, KeyStoreException, UnrecoverableKeyException, KeyManagementException {
        Map<String, Object> props = kafkaProperties(bootstrapAddress, groupId, truststoreLocation, truststorePassword, keystoreLocation, keystorePassword, securityProtocol);
        return new DefaultKafkaConsumerFactory<>(props, new StringDeserializer(), new AvroDeserializer<>(AnalyticsEvent.class));
    }

    @Bean
    public ConcurrentKafkaListenerContainerFactory<String, AnalyticsEvent> opsiKafkaListenerContainerFactory(
            ConsumerFactory<String, AnalyticsEvent> opsiConsumerFactory
    ) {
        ConcurrentKafkaListenerContainerFactory<String, AnalyticsEvent> factory = new ConcurrentKafkaListenerContainerFactory<>();
        factory.setConsumerFactory(opsiConsumerFactory);
        factory.getContainerProperties().setAckMode(ContainerProperties.AckMode.MANUAL);
        factory.setConcurrency(concurrency);
        return factory;
    }

    @Bean
    public DefaultKafkaConsumerFactory<String, DDGAPCPGapFileInfo> digitalGatewayConsumerFactory(
            @Value("${spring.kafka.digital-gateway.bootstrap-servers}") String bootstrapAddress,
            @Value("${spring.kafka.digital-gateway.consumer.group-id}") String groupId,
            @Value("${spring.kafka.digital-gateway.ssl.truststore.location}") String truststoreLocation,
            @Value("${spring.kafka.digital-gateway.ssl.truststore.password}") String truststorePassword,
            @Value("${spring.kafka.digital-gateway.ssl.keystore.location}") String keystoreLocation,
            @Value("${spring.kafka.digital-gateway.ssl.keystore.password}") String keystorePassword,
            @Value("${spring.kafka.digital-gateway.security.protocol}") String securityProtocol
    ) throws CertificateException, IOException, NoSuchAlgorithmException, KeyStoreException, UnrecoverableKeyException, KeyManagementException {
        Map<String, Object> props = kafkaProperties(bootstrapAddress, groupId, truststoreLocation, truststorePassword, keystoreLocation, keystorePassword, securityProtocol);
        return new DefaultKafkaConsumerFactory<>(props, new StringDeserializer(), new AvroDeserializer<>(DDGAPCPGapFileInfo.class));
    }

    @Bean
    public ConcurrentKafkaListenerContainerFactory<String, DDGAPCPGapFileInfo> digitalGatewayKafkaListenerContainerFactory(
            ConsumerFactory<String, DDGAPCPGapFileInfo> digitalGatewayConsumerFactory
    ) {
        ConcurrentKafkaListenerContainerFactory<String, DDGAPCPGapFileInfo> factory = new ConcurrentKafkaListenerContainerFactory<>();
        factory.setConsumerFactory(digitalGatewayConsumerFactory);
        factory.getContainerProperties().setAckMode(ContainerProperties.AckMode.MANUAL);
        factory.setConcurrency(concurrency);
        return factory;
    }
}
