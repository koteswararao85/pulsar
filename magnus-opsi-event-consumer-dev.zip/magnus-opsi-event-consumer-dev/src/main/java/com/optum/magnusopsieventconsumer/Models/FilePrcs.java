package com.optum.magnusopsieventconsumer.Models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.optum.magnusopsieventconsumer.util.FilePrcsStatus;
import com.optum.magnusopsieventconsumer.util.FilePrcsType;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class FilePrcs {

    @JsonIgnore
    private String filePrcsType;
    @JsonIgnore
    private Long filePrcsStsKey;
    @JsonIgnore
    private Long filePrcsKey;
    private String filePrcsName;
    private FilePrcsType filePrcsTypeEnum;
    private FilePrcsStatus filePrcsStatus;
    private String storageUrlID;
    private String runID;
    private LocalDateTime insrtDttm;
    private String insrtUserId;
    private LocalDateTime updtDttm;
    private String updtUserId;
    @NotNull
    private String correlationId;
    private String storageAccount;
    private String filePath;
    private String fileName;
    private Integer badRows;
    private Integer cleanRows;
    private Integer totalRows;
    private Integer fileSize;
    private String status;
    private String batchStartTIme;
    private String chaseProcessId;
    private String clientName;
    private String clientId;
    private String fileType;
    private String lob;
    private Integer recordCount;
    private String drtsClientId;
    private String drtsClientName;
    private String drtsContractId;
    private String paidDate;
    private String origSourceInfo;
    private Long retryCount;
    private String eventMessage;
    private String eventTriggerBody;

}
