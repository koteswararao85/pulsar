package com.optum.magnusopsieventconsumer.service;


import com.optum.magnusopsieventconsumer.Models.*;
import com.optum.magnusopsieventconsumer.configuration.TokenHandler;
import com.optum.magnusopsieventconsumer.util.ConsumerConstants;
import com.optum.magnusopsieventconsumer.util.FilePrcsStatus;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

@Service
@Slf4j
public class TrackerApi {

    @Value("${processTracker.url}")
    private String url;


    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private TokenHandler tokenHandler;

    private List<String> sanitizeFileNames(List<String> fileNames) {
        return fileNames.stream()
                .map(fileName -> fileName.replace("\n", "").replace("\r", ""))
                .collect(Collectors.toList());
    }

    public ResponseEntity<FilePrcsTrackError> createTrackError(FilePrcsTrackError trackError){

        trackError.setInsrtUserId(ConsumerConstants.OPSI_CONSUMER);
        trackError.setUpdtUserId(ConsumerConstants.OPSI_CONSUMER);

        log.info("Logging Error to Tracker Error Table");

        log.info("Getting Token from Auth provider");
        String oauth2Token = tokenHandler.getToken();
        if(oauth2Token.isEmpty() || oauth2Token==null) {
            log.error("Oauth Token is empty");
            return new ResponseEntity<>(HttpStatusCode.valueOf(404));
        }
        else
            log.info("Oauth Token retrieved");

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("Authorization","Bearer " + oauth2Token);
        HttpEntity<FilePrcsTrackError> entity = new HttpEntity<>(trackError,headers);
        ResponseEntity<FilePrcsTrackError> response = new ResponseEntity<>(HttpStatusCode.valueOf(500));
        try {
            response = restTemplate.postForEntity(url + "processtrkr/addFilePrcsTrackError", entity, FilePrcsTrackError.class);
            log.info("Logged Error into the Tracker table");
        }catch (Exception ex){
            log.info("Error send the Tracker Error API :"+ ex.getMessage());
        }
        return response;
    }

    public ResponseEntity<FilePrcsErrorBatch> createTrackErrorBatch(FilePrcsErrorBatch filePrcsErrorBatch){

        filePrcsErrorBatch.setInsrtUserId(ConsumerConstants.OPSI_CONSUMER);

        log.info("Logging Error to Tracker Error Table");

        log.info("Getting Token from Auth provider");
        String oauth2Token = tokenHandler.getToken();
        if(oauth2Token.isEmpty() || oauth2Token==null) {
            log.error("Oauth Token is empty");
            return new ResponseEntity<>(HttpStatusCode.valueOf(404));
        }
        else
            log.info("Oauth Token retrieved");

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("Authorization","Bearer " + oauth2Token);
        HttpEntity<FilePrcsErrorBatch> entity = new HttpEntity<>(filePrcsErrorBatch,headers);
        ResponseEntity<FilePrcsErrorBatch> response = new ResponseEntity<>(HttpStatusCode.valueOf(500));
        try {
            response = restTemplate.postForEntity(url + "processtrkr/batchAddFilePrcsError", entity, FilePrcsErrorBatch.class);
            log.info("Logged Error into the Tracker table");
        }catch (Exception ex){
            log.info("Error send the Tracker Error API :"+ ex.getMessage());
        }
        return response;
    }

    public ResponseEntity<Collection> createBatchTrack(Collection<FilePrcs> filePrcsCollection){

        log.info("Inserting analytics entries into table");
        log.info("Getting Token from Auth provider");
        String oauth2Token = tokenHandler.getToken();
        if(oauth2Token.isEmpty() || oauth2Token==null) {
            log.error("Oauth Token is empty");
            return new ResponseEntity<>(HttpStatusCode.valueOf(404));
        }
        else
            log.info("Oauth Token retrieved");

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("Authorization","Bearer " + oauth2Token);
        HttpEntity<Collection<FilePrcs>> entity = new HttpEntity<>(filePrcsCollection,headers);
        try {
            List<String> filePrcsNames = filePrcsCollection.stream().map(FilePrcs::getFilePrcsName).toList();
            log.info("Creating Entries for FilePrcsNames [{}]", String.join(",",filePrcsNames));
            ResponseEntity<Collection> response = restTemplate.postForEntity(url + "processtrkr/batchCreateAndTrack", entity, Collection.class);
            log.info("Message inserted into tracker API");
            return response;
        }catch (Exception ex){
            for (FilePrcs filePrcs: filePrcsCollection) {
                log.info("Failed to create entry in Tracker table------Logging into error table");
                FilePrcsTrackError trackError = new FilePrcsTrackError();
                trackError.setFilePrcsName(filePrcs.getFilePrcsName());
                trackError.setErrorMsg("Failed to create Tracker for msg " + filePrcs.getFilePrcsName() + " \n \n with error :" + ex.getMessage());
                createTrackError(trackError);
            }
            return new ResponseEntity<>(HttpStatusCode.valueOf(400));
        }
    }

    public ResponseEntity<List<EventTriggerBody>> fetchEventTriggerBodies(String fileType, Long maxRetryCount){

        log.info("Retriving the event trigger bodies");
        log.info("Getting Token from Auth provider");
        String oauth2Token = tokenHandler.getToken();
        if(oauth2Token.isEmpty() || oauth2Token==null) {
            log.error("Oauth Token is empty");
            return new ResponseEntity<>(HttpStatusCode.valueOf(404));
        }
        else
            log.info("Oauth Token retrieved");

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("Authorization","Bearer " + oauth2Token);
        HttpEntity<Void> entity = new HttpEntity<>(headers);
        String urlWithParams = String.format("%s/processtrkr/batchFetchEventTriggerBodies?fileType=%s&maxRetryCount=%d", url, fileType, maxRetryCount);

        try {
            ResponseEntity<List<EventTriggerBody>> response = restTemplate.exchange(urlWithParams, HttpMethod.GET, entity, new ParameterizedTypeReference<List<EventTriggerBody>>() {});
            log.info("Event trigger bodies retrieved successfully");
            return response;
        } catch (Exception ex) {
            log.error("Error retrieving event trigger bodies: " + ex.getMessage());
            return new ResponseEntity<>(HttpStatusCode.valueOf(500));
        }
    }

    public ResponseEntity<Integer> increaseRetryCountByFilePrcsNameIn(List<String> fileNames) {

        log.info("Getting Token from Auth provider");
        String oauth2Token = tokenHandler.getToken();
        if (oauth2Token.isEmpty() || oauth2Token == null) {
            log.error("Oauth Token is empty");
            return new ResponseEntity<>(HttpStatusCode.valueOf(404));
        } else {
            log.info("Oauth Token retrieved");
        }

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("Authorization", "Bearer " + oauth2Token);
        log.info("Incrementing retry count for file names : {}", sanitizeFileNames(fileNames));
        HttpEntity<List<String>> entity = new HttpEntity<>(fileNames, headers);

        try {
            ResponseEntity<Integer> response = restTemplate.postForEntity(url + "processtrkr/increaseRetryCountForFileNames", entity, Integer.class);
            log.info("Retry count incremented successfully");
            return response;
        } catch (Exception ex) {
            log.error("Error incrementing retry count: " + ex.getMessage());
            FilePrcsErrorBatch filePrcsErrorBatch = new FilePrcsErrorBatch("",fileNames, ex.getMessage(), "","","");
            createTrackErrorBatch(filePrcsErrorBatch);
            return new ResponseEntity<>(HttpStatusCode.valueOf(500));
        }
    }


    public ResponseEntity<Integer> batchUpdateFilePrcsTrack(List<String> fileNames, FilePrcsStatus fileStatus) {

        log.info("Getting Token from Auth provider");
        String oauth2Token = tokenHandler.getToken();
        if (oauth2Token.isEmpty() || oauth2Token == null) {
            log.error("Oauth Token is empty");
            return new ResponseEntity<>(HttpStatusCode.valueOf(404));
        } else {
            log.info("Oauth Token retrieved");
        }

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("Authorization", "Bearer " + oauth2Token);
        log.info("Updating the file status for file names : {} to filestatus : {}", sanitizeFileNames(fileNames), fileStatus);
        FilePrcsStatusBatchUpdate filePrcsStatusBatchUpdate= new FilePrcsStatusBatchUpdate(fileNames,ConsumerConstants.OPSI_CONSUMER, fileStatus,"");
        HttpEntity<FilePrcsStatusBatchUpdate> entity = new HttpEntity<>(filePrcsStatusBatchUpdate, headers);

        try {
            ResponseEntity<Integer> response = restTemplate.postForEntity(url + "processtrkr/batchUpdateFilePrcsTrack", entity, Integer.class);
            log.info("Batch update for files:{} completed",sanitizeFileNames(fileNames));
            return response;
        } catch (Exception ex) {
            log.error("Error Updating filestatus for files :{} due to  " + ex.getMessage(),sanitizeFileNames(fileNames));
            FilePrcsErrorBatch filePrcsErrorBatch = new FilePrcsErrorBatch("",fileNames, ex.getMessage(), "","","");
            createTrackErrorBatch(filePrcsErrorBatch);
            return new ResponseEntity<>(HttpStatusCode.valueOf(500));
        }
    }

}
