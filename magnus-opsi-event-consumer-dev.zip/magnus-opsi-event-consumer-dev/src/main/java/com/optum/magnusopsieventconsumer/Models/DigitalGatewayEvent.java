package com.optum.magnusopsieventconsumer.Models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class DigitalGatewayEvent {
    private String clientId;
    private String fileName;
    private String fileType;
    private String lob;
    private String location;
    private String storage;
    private String container;
    private String dataCount;
    private String correlationId;
}
