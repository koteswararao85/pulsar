package com.optum.magnusopsieventconsumer.configuration;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;

import javax.sql.DataSource;

@Configuration
public class DataSourceConfiguration {

    @Value("${spring.magnus-datasource.jdbcUrl}")
    private String dbUrl;

    @Value("${spring.magnus-datasource.username}")
    private String dbUserName;

    @Value("${spring.magnus-datasource.password}")
    private String dbPassword;

    @Value("${spring.magnus-datasource.connection-timeout}")
    private String connectionTimeout;

    @Value("${spring.magnus-datasource.maximum-pool-size}")
    private String maximumPoolSize;

    @Value("${spring.magnus-datasource.minimum-idle}")
    private String minimumIdle;

    @Value("${spring.magnus-datasource.idle-timeout}")
    private String idleTimeout;

    @Bean
    public DataSource getDataSource() {
        return new HikariDataSource(getHikariConfiguration());
    }

    public HikariConfig getHikariConfiguration() {
        HikariConfig config = new HikariConfig();
        config.setJdbcUrl(dbUrl);
        config.setUsername(dbUserName);
        config.setPassword(dbPassword);
        config.setConnectionTimeout(Long.parseLong(connectionTimeout));
        config.setMaximumPoolSize(Integer.parseInt(maximumPoolSize));
        config.setMinimumIdle(Integer.parseInt(minimumIdle));
        config.setIdleTimeout(Long.parseLong(idleTimeout));
        return config;
    }


    @Bean(name = "simpleJdbcCall")
    public SimpleJdbcCall getSimpleJdbcCall() {
        return new SimpleJdbcCall(getDataSource());
    }

}