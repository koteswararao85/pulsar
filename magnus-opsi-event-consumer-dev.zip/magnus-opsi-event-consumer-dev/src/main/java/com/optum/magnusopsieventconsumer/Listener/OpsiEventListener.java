package com.optum.magnusopsieventconsumer.Listener;

import com.optum.magnusopsieventconsumer.Models.FilePrcs;
import com.optum.magnusopsieventconsumer.service.ADFTriggerService;
import com.optum.magnusopsieventconsumer.service.TrackerApi;
import com.optum.magnusopsieventconsumer.util.ClassMapper;
import com.optum.magnusopsieventconsumer.util.FilePrcsStatus;
import com.optum.magnusopsieventconsumer.util.FilePrcsType;
import com.optum.rqns.events.v1.analytics.AnalyticsEvent;
import com.optum.rqns.events.v1.ccdgateway.DDGAPCPGapFileInfo;

import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.Collection;

import static com.optum.magnusopsieventconsumer.util.LobMap.*;

@Component
@Slf4j
public class OpsiEventListener {

    @Autowired
    private ADFTriggerService adfTriggerService;

    @Autowired
    private TrackerApi trackerApi;

    @Value("${spring.lobFilter.ACA}")
    private String acaFlag;

    @Value("${spring.lobFilter.MA}")
    private String maFlag;

    @Value("${spring.lobFilter.MCAID}")
    private String mcaidFlag;

    @Value("${azure.anrConfig.url.ma}")
    private String maUrl;

    @Value("${azure.anrConfig.url.aca}")
    private String acaUrl;

    @Value("${azure.anrConfig.url.mcaid}")
    private String mcaidUrl;


    @KafkaListener(topics = "${spring.kafka.opsi.consumer.topic}", groupId = "${spring.kafka.opsi.consumer.group-id}", containerFactory = "opsiKafkaListenerContainerFactory")
    public void opsiEventConsumer(ConsumerRecord<String, AnalyticsEvent> record, Acknowledgment ack) throws IOException {
        log.info("Received msg from opsi kafka {} with key {}", record.value().toString(), record.key());

        if (!filterMessage(record.value())) {
            log.info("Message is not intended for this service");
            ack.acknowledge();
            return;
        }
        Collection<FilePrcs> filePrcsCollection = ClassMapper.analyticsToBatchFilePrcs(record.value(), FilePrcsStatus.MESSAGE_RECEIVED, FilePrcsType.IN, maUrl, acaUrl, mcaidUrl);
        ResponseEntity<Collection> response = trackerApi.createBatchTrack(filePrcsCollection);
        if (!response.getStatusCode().is2xxSuccessful()) {
            log.info("Failed to create tracking for object {}", record.value().toString());
            return;
        }
        ack.acknowledge();
    }

    @KafkaListener(topics = "${spring.kafka.digital-gateway.consumer.topic}", groupId = "${spring.kafka.digital-gateway.consumer.group-id}", containerFactory = "digitalGatewayKafkaListenerContainerFactory")
    public void digitalGatewayEventConsumer(ConsumerRecord<String, DDGAPCPGapFileInfo> record, Acknowledgment ack) {
        log.info("Received msg from digital-gateway kafka {} with key {}", record.value().toString(), record.key());
        Collection<FilePrcs> filePrcsCollection = ClassMapper.digitalGateWayEventTOBatchFilePrcs(record.value());
        ResponseEntity<Collection> response = trackerApi.createBatchTrack(filePrcsCollection);
        if (!response.getStatusCode().is2xxSuccessful()) {
            log.info("Failed to create tracking for object {}", record.value().toString());
            return;
        }
        ack.acknowledge();
    }

    public boolean filterMessage(AnalyticsEvent analyticsEvent){
        String lob = ClassMapper.getLobFromEvent(analyticsEvent);
        return (acaFlag.equalsIgnoreCase("true") && lob.equalsIgnoreCase(ACA))
                || (mcaidFlag.equalsIgnoreCase("true") && lob.equalsIgnoreCase(MCAID))
                || (maFlag.equalsIgnoreCase("true") && lob.equalsIgnoreCase(MA));
    }
}
