package com.optum.magnusopsieventconsumer.Models;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class FilePrcsErrorBatch {
    @NotNull
    private String insrtUserId;
    private List<String> filePrcsNameList;
    @NotNull
    private String errorMsg;
    private String processNm;
    private String processId;
    private String batchRunId;
}