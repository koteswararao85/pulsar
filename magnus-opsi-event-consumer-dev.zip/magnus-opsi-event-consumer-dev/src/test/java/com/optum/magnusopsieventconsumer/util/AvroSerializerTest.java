package com.optum.magnusopsieventconsumer.util;

import org.apache.avro.Schema;
import org.apache.avro.specific.SpecificRecordBase;
import org.apache.kafka.common.errors.SerializationException;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class AvroSerializerTest {

    static class DummyRecord extends SpecificRecordBase {
        public static final Schema SCHEMA = new Schema.Parser().parse(
                "{ \"type\": \"record\", \"name\": \"DummyRecord\", \"fields\": [{ \"name\": \"field\", \"type\": \"string\" }] }"
        );
        private String field;

        @Override
        public void put(int i, Object v) { field = v.toString(); }
        @Override
        public Object get(int i) { return field; }
        @Override
        public Schema getSchema() { return SCHEMA; }
    }

    @Test
    void testSerializeValidPayload() {
        AvroSerializer<DummyRecord> serializer = new AvroSerializer<>();
        DummyRecord record = new DummyRecord();
        record.put(0, "test");
        byte[] result = serializer.serialize("topic", record);
        assertNotNull(result);
        assertTrue(result.length > 0);
    }

    @Test
    void testSerializeNullPayload() {
        AvroSerializer<DummyRecord> serializer = new AvroSerializer<>();
        byte[] result = serializer.serialize("topic", null);
        assertNull(result);
    }

    @Test
    void testSerializeThrowsException() {
        AvroSerializer<SpecificRecordBase> serializer = new AvroSerializer<>();
        SpecificRecordBase badRecord = mock(SpecificRecordBase.class);
        when(badRecord.getSchema()).thenThrow(new RuntimeException("fail"));
        assertThrows(SerializationException.class, () -> serializer.serialize("topic", badRecord));
    }

    @Test
    void testConfigureAndClose() {
        AvroSerializer<DummyRecord> serializer = new AvroSerializer<>();
        serializer.configure(null, false);
        serializer.close();
        assertDoesNotThrow(serializer::close, "Serializer should close without throwing exception");
    }
}