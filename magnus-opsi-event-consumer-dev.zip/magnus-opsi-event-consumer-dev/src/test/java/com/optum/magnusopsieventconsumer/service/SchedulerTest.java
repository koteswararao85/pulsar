package com.optum.magnusopsieventconsumer.service;


import com.optum.magnusopsieventconsumer.Models.EventTriggerBody;
import com.optum.magnusopsieventconsumer.Models.FilePrcsTrackError;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.List;

import static org.mockito.Mockito.*;

class SchedulerTest {

    @InjectMocks
    private Scheduler scheduler;

    @Mock
    private TrackerApi trackerApi;

    @Mock
    private ADFTriggerService adfTriggerService;

    @BeforeEach
    void setUp() throws Exception {
        MockitoAnnotations.openMocks(this);
        java.lang.reflect.Field field = Scheduler.class.getDeclaredField("maxRetryAttempts");
        field.setAccessible(true);
        field.set(scheduler, 3L);
        scheduler.init();
    }


    @Test
    void testPerformTask_deserializationError() throws Exception {
        EventTriggerBody body = new EventTriggerBody();
        body.setEventTriggerBody("invalid_json");
        body.setFilePrcsName("file2");

        ResponseEntity<List<EventTriggerBody>> response =
                new ResponseEntity<>(List.of(body), HttpStatus.OK);

        when(trackerApi.fetchEventTriggerBodies(anyString(), anyLong())).thenReturn(response);
        when(trackerApi.increaseRetryCountByFilePrcsNameIn(anyList())).thenReturn(ResponseEntity.ok().build());
        when(trackerApi.createTrackError(any(FilePrcsTrackError.class))).thenReturn(ResponseEntity.ok().build());

        scheduler.performTask();

        verify(trackerApi, atLeastOnce()).createTrackError(any(FilePrcsTrackError.class));
    }

    @Test
    void testPerformTask_noFilesToProcess() {
        ResponseEntity<List<EventTriggerBody>> response =
                new ResponseEntity<>(null, HttpStatus.OK);

        when(trackerApi.fetchEventTriggerBodies(anyString(), anyLong())).thenReturn(response);

        scheduler.performTask();

        verify(trackerApi, atLeastOnce()).fetchEventTriggerBodies(anyString(), anyLong());
    }

    @Test
    void testPerformTask_failedFetch() {
        ResponseEntity<List<EventTriggerBody>> response =
                new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);

        when(trackerApi.fetchEventTriggerBodies(anyString(), anyLong())).thenReturn(response);

        scheduler.performTask();

        verify(trackerApi, atLeastOnce()).fetchEventTriggerBodies(anyString(), anyLong());
    }
}