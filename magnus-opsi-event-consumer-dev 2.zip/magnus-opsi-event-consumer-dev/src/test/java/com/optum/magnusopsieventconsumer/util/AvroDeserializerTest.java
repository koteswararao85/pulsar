package com.optum.magnusopsieventconsumer.util;

import org.apache.avro.Schema;
import org.apache.avro.specific.SpecificRecordBase;
import org.apache.kafka.common.errors.SerializationException;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class AvroDeserializerTest {

    public static class MockRecord extends SpecificRecordBase {
        public static final Schema SCHEMA = Schema.createRecord("MockRecord", null, null, false);
        @Override
        public void put(int i, Object v) {
            throw new UnsupportedOperationException("put() is not supported in MockRecord");
        }
        @Override
        public Object get(int i) {
            throw new UnsupportedOperationException("get() is not supported in MockRecord");
        }
        @Override
        public Schema getSchema() { return SCHEMA; }
    }

    @Test
    void testDeserializeNullData() {
        AvroDeserializer<MockRecord> deserializer = new AvroDeserializer<>(MockRecord.class);
        MockRecord result = deserializer.deserialize("test-topic", null);
        Assertions.assertNull(result);
    }

    @Test
    void testDeserializeInvalidDataThrowsException() {
        AvroDeserializer<MockRecord> deserializer = new AvroDeserializer<>(MockRecord.class);
        byte[] invalidData = new byte[]{0x01, 0x02, 0x03};
        Assertions.assertThrows(SerializationException.class, () -> {
            deserializer.deserialize("test-topic", invalidData);
        });
    }

    @Test
    void testToString() {
        AvroDeserializer<MockRecord> deserializer = new AvroDeserializer<>(MockRecord.class);
        Assertions.assertTrue(deserializer.toString().contains("MockRecord"));
    }
}