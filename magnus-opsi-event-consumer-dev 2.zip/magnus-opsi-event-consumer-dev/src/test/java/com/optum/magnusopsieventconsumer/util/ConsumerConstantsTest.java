package com.optum.magnusopsieventconsumer.util;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.Collection;
import java.util.Map;

public class ConsumerConstantsTest {

    @Test
    void testConstantValues() {
        Assertions.assertEquals("OPSI_CONSUMER", ConsumerConstants.OPSI_CONSUMER);
        Assertions.assertEquals("access_token", ConsumerConstants.ACCESS_TOKEN);
        Assertions.assertEquals("analytics-results", ConsumerConstants.OPSI_CONTAINER);
        Assertions.assertEquals("raf", ConsumerConstants.RAF);
        Assertions.assertEquals("bld_partc_base_raf", ConsumerConstants.BLD_PARTC_BASE_RAF);
        Assertions.assertEquals("analytic_gaps", ConsumerConstants.GAP);
        Assertions.assertEquals("bld_partc_esrd_raf", ConsumerConstants.BLD_PARTC_ESRD_RAF);
        Assertions.assertEquals("partc", ConsumerConstants.PARTC);
        Assertions.assertEquals("suspects_rollup", ConsumerConstants.SUSPECTS_ROLLUP);
        Assertions.assertEquals("screening_rollup", ConsumerConstants.SCREENING_ROLLUP);
        Assertions.assertEquals("scr", ConsumerConstants.SCR);
        Assertions.assertEquals("care_modality", ConsumerConstants.CARE_MODALITY);
        Assertions.assertEquals("care_priority_group", ConsumerConstants.CARE_PRIORITY);
        Assertions.assertEquals("clinical_risk_group", ConsumerConstants.CRG);
        Assertions.assertEquals("analytic_claim", ConsumerConstants.CLAIMS_TAG);
        Assertions.assertEquals("risk", ConsumerConstants.RISK);
        Assertions.assertEquals("rendering", ConsumerConstants.RENDERING);
        Assertions.assertEquals("analytic_member", ConsumerConstants.MEMBER_TAG);
        Assertions.assertEquals("quality", ConsumerConstants.QUALITY);
        Assertions.assertEquals("member_hcc_dxcounts", ConsumerConstants.MEMBER_HCC_DXCOUNTS);
        Assertions.assertEquals("member_dss_dxcounts", ConsumerConstants.MEMBER_DSS_DXCOUNTS);
        Assertions.assertEquals("member_dxcounts", ConsumerConstants.MEMBER_DXCOUNTS);
        Assertions.assertEquals("medicaid_member_dxcounts", ConsumerConstants.MCAID_MEMBER_DXCOUNTS);
    }

    @Test
    void testMembersCollection() {
        Collection<String> members = ConsumerConstants.MEMBERS;
        Assertions.assertTrue(members.contains(ConsumerConstants.BLD_PARTC_BASE_RAF));
        Assertions.assertTrue(members.contains(ConsumerConstants.BLD_PARTC_ESRD_RAF));
        Assertions.assertTrue(members.contains(ConsumerConstants.CARE_PRIORITY));
        Assertions.assertTrue(members.contains(ConsumerConstants.MEMBER_HCC_DXCOUNTS));
        Assertions.assertTrue(members.contains(ConsumerConstants.MEMBER_DXCOUNTS));
        Assertions.assertTrue(members.contains(ConsumerConstants.MCAID_MEMBER_DXCOUNTS));
        Assertions.assertTrue(members.contains(ConsumerConstants.MEMBER_DSS_DXCOUNTS));
        Assertions.assertTrue(members.contains(ConsumerConstants.CARE_MODALITY));
        Assertions.assertTrue(members.contains(ConsumerConstants.RAF));
        Assertions.assertTrue(members.contains(ConsumerConstants.CRG));
    }

    @Test
    void testClaimsCollection() {
        Collection<String> claims = ConsumerConstants.CLAIMS;
        Assertions.assertTrue(claims.contains("er_visits"));
        Assertions.assertTrue(claims.contains("annual_visits"));
        Assertions.assertTrue(claims.contains("hospital_admits"));
        Assertions.assertTrue(claims.contains("physician_visits"));
        Assertions.assertTrue(claims.contains("tele_visits"));
        Assertions.assertTrue(claims.contains(ConsumerConstants.MEMBER_HCC_DXCOUNTS));
        Assertions.assertTrue(claims.contains(ConsumerConstants.MEMBER_DXCOUNTS));
        Assertions.assertTrue(claims.contains("mbr_dx_dos_prov"));
    }

    @Test
    void testClaimsFolderNameMap() {
        Map<String, String> map = ConsumerConstants.CLAIMS_FOLDER_NAME;
        Assertions.assertEquals("ErVisits", map.get("er_visits"));
        Assertions.assertEquals("AnnualVisits", map.get("annual_visits"));
        Assertions.assertEquals("HospAdmits", map.get("hospital_admits"));
        Assertions.assertEquals("PhyVisits", map.get("physician_visits"));
        Assertions.assertEquals("TeleVisits", map.get("tele_visits"));
        Assertions.assertEquals("MbrHccDx", map.get(ConsumerConstants.MEMBER_HCC_DXCOUNTS));
        Assertions.assertEquals("MbrDssDx", map.get(ConsumerConstants.MEMBER_DSS_DXCOUNTS));
        Assertions.assertEquals("MbrDx", map.get(ConsumerConstants.MEMBER_DXCOUNTS));
        Assertions.assertEquals("MbrDx", map.get(ConsumerConstants.MCAID_MEMBER_DXCOUNTS));
        Assertions.assertEquals("MbrDxDosProv", map.get("mbr_dx_dos_prov"));
    }

    @Test
    void testRafLobNameMap() {
        Map<String, String> map = ConsumerConstants.RAFLOBNAME;
        Assertions.assertEquals("aca", map.get(LobMap.ACA));
        Assertions.assertEquals("medicaid", map.get(LobMap.MCAID));
    }
}