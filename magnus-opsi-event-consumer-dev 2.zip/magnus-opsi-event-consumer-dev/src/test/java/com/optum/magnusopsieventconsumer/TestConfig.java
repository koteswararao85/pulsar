package com.optum.magnusopsieventconsumer;

import com.optum.magnusopsieventconsumer.Listener.OpsiEventListener;
import com.optum.magnusopsieventconsumer.configuration.TokenHandler;
import com.optum.magnusopsieventconsumer.service.ADFTriggerService;
import com.optum.magnusopsieventconsumer.service.TrackerApi;
import org.apache.kafka.clients.admin.*;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.web.client.RestTemplate;

import java.util.*;

@Configuration
@ActiveProfiles("junits")
public class TestConfig {

    @Bean
    public TrackerApi trackerApi(){
        return new TrackerApi();
    }

    @Bean
    public RestTemplate restTemplate(){
        return new RestTemplate();
    }

    @Bean
    public TokenHandler tokenHandler(){
        return new TokenHandler();
    }

    @Bean
    public ADFTriggerService adfTriggerService(){
        return new ADFTriggerService();
    }

    @Bean
    public OpsiEventListener opsiEventListener(){
        return new OpsiEventListener();
    }


    @Bean
    public AdminClient adminClient(){
        // Dummy props
        Map<String, Object> props = new HashMap<>();
        props.put(AdminClientConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
        return AdminClient.create(props);
    }

}