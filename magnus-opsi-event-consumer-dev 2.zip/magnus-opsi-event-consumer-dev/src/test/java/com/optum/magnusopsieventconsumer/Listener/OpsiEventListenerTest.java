package com.optum.magnusopsieventconsumer.Listener;

import com.optum.magnusopsieventconsumer.Models.FilePrcs;
import com.optum.magnusopsieventconsumer.TestConfig;
import com.optum.magnusopsieventconsumer.service.ADFTriggerService;
import com.optum.magnusopsieventconsumer.service.TrackerApi;
import com.optum.magnusopsieventconsumer.util.ClassMapper;
import com.optum.magnusopsieventconsumer.util.FilePrcsStatus;
import com.optum.magnusopsieventconsumer.util.FilePrcsType;
import com.optum.rqns.events.v1.analytics.AnalyticsEvent;
import com.optum.rqns.events.v1.analytics.AnalyticsEventType;
import com.optum.rqns.events.v1.analytics.EventType;
import com.optum.rqns.events.v1.analytics.EventTypeVersion;
import com.optum.rqns.events.v1.ccdgateway.DDGAPCPGapFileInfo;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.MockedStatic;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Collection;

import static org.mockito.Mockito.*;

@ActiveProfiles("junits")
@SpringBootTest
@RunWith(SpringRunner.class)
@ContextConfiguration(classes = TestConfig.class)
class OpsiEventListenerTest {

    @Autowired
    private OpsiEventListener listener;

    @MockBean
    private ADFTriggerService adfTriggerService;

    @MockBean
    private TrackerApi trackerApi;

    @MockBean
    private Acknowledgment acknowledgment;

    @Test
    @Disabled
    void opsiEventConsumer() throws Exception {
        AnalyticsEventType eventType = new AnalyticsEventType();
        eventType.put(0,"101");
        AnalyticsEvent event = new AnalyticsEvent(EventTypeVersion.v1, "EventId", EventType.Completed, "CorrId", "Time", "src", "SchemaURl", "EventId", eventType);
        ConsumerRecord<String,AnalyticsEvent> record = new ConsumerRecord<>("topic", 0, 0, "key", event);
        Collection<FilePrcs> filePrcsCollection = ClassMapper.analyticsToBatchFilePrcs(event, FilePrcsStatus.MESSAGE_RECEIVED, FilePrcsType.IN,"samagnusldzonecusdev","samagnusldzonecusdev","samagnusldzonecusdev");
        when(trackerApi.createBatchTrack(filePrcsCollection)).thenReturn(new ResponseEntity<>(HttpStatusCode.valueOf(200)));
        doNothing().when(acknowledgment).acknowledge();
//        listener.eventConsumer(record, acknowledgment);
        when(trackerApi.createBatchTrack(filePrcsCollection)).thenReturn(new ResponseEntity<>(HttpStatusCode.valueOf(500)));
//        listener.eventConsumer(record, acknowledgment);
        verify(acknowledgment, times(1)).acknowledge();
        eventType.put(0,"102");
        event = new AnalyticsEvent(EventTypeVersion.v1, "EventId", EventType.Completed, "CorrId", "Time", "src", "SchemaURl", "EventId", eventType);
        record = new ConsumerRecord<>("topic", 0, 0, "key", event);
//        listener.eventConsumer(record, acknowledgment);
        verify(acknowledgment, times(2)).acknowledge();
    }

    @Test
    void opsiEventConsumerFilter() {
        AnalyticsEventType eventType = new AnalyticsEventType();
        eventType.put(0,"101");
        AnalyticsEvent event = new AnalyticsEvent(EventTypeVersion.v1, "EventId", EventType.Completed, "CorrId", "Time", "src", "SchemaURl", "EventId", eventType);
        Assertions.assertTrue(listener.filterMessage(event));
        eventType.put(0,"102");
        event = new AnalyticsEvent(EventTypeVersion.v1, "EventId", EventType.Completed, "CorrId", "Time", "src", "SchemaURl", "EventId", eventType);
        Assertions.assertFalse(listener.filterMessage(event));
        eventType.put(0,"108");
        event = new AnalyticsEvent(EventTypeVersion.v1, "EventId", EventType.Completed, "CorrId", "Time", "src", "SchemaURl", "EventId", eventType);
        Assertions.assertFalse(listener.filterMessage(event));
    }


    @Test
    void opsiEventConsumer_shouldAcknowledgeOnSuccessAndFailure() throws Exception {
        AnalyticsEventType eventType = new AnalyticsEventType();
        eventType.put(0,"101");
        AnalyticsEvent event = new AnalyticsEvent(EventTypeVersion.v1, "EventId", EventType.Completed, "CorrId", "Time", "src", "SchemaURl", "EventId", eventType);
        ConsumerRecord<String,AnalyticsEvent> record = new ConsumerRecord<>("topic", 0, 0, "key", event);
        Collection<FilePrcs> filePrcsCollection = ClassMapper.analyticsToBatchFilePrcs(event, FilePrcsStatus.MESSAGE_RECEIVED, FilePrcsType.IN,"maUrl","acaUrl","mcaidUrl");
        when(trackerApi.createBatchTrack(filePrcsCollection)).thenReturn(new ResponseEntity<>(HttpStatusCode.valueOf(200)));
        doNothing().when(acknowledgment).acknowledge();

        listener.opsiEventConsumer(record, acknowledgment);
        verify(acknowledgment, times(1)).acknowledge();

        when(trackerApi.createBatchTrack(filePrcsCollection)).thenReturn(new ResponseEntity<>(HttpStatusCode.valueOf(500)));
        listener.opsiEventConsumer(record, acknowledgment);
        // Should not acknowledge again since status is not 2xx
        verify(acknowledgment, times(1)).acknowledge();
    }


    @Test
    void digitalGatewayEventConsumer_shouldAcknowledgeOnSuccessAndFailure() {
        DDGAPCPGapFileInfo fileInfo = mock(DDGAPCPGapFileInfo.class);
        ConsumerRecord<String, DDGAPCPGapFileInfo> record = new ConsumerRecord<>("topic", 0, 0, "key", fileInfo);
        Collection<FilePrcs> filePrcsCollection = mock(Collection.class);

        try (MockedStatic<ClassMapper> classMapperMock = mockStatic(ClassMapper.class)) {
            classMapperMock.when(() -> ClassMapper.digitalGateWayEventTOBatchFilePrcs(fileInfo)).thenReturn(filePrcsCollection);
            when(trackerApi.createBatchTrack(filePrcsCollection)).thenReturn(new ResponseEntity<>(HttpStatusCode.valueOf(200)));
            doNothing().when(acknowledgment).acknowledge();

            listener.digitalGatewayEventConsumer(record, acknowledgment);
            verify(acknowledgment, times(1)).acknowledge();

            when(trackerApi.createBatchTrack(filePrcsCollection)).thenReturn(new ResponseEntity<>(HttpStatusCode.valueOf(500)));
            listener.digitalGatewayEventConsumer(record, acknowledgment);
            verify(acknowledgment, times(1)).acknowledge();
        }
    }
}