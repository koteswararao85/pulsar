package com.optum.magnusopsieventconsumer.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.optum.magnusopsieventconsumer.Models.EventTriggerBody;
import com.optum.magnusopsieventconsumer.Models.FilePrcs;
import com.optum.magnusopsieventconsumer.Models.FilePrcsErrorBatch;
import com.optum.magnusopsieventconsumer.Models.FilePrcsStatusBatchUpdate;
import com.optum.magnusopsieventconsumer.Models.FilePrcsTrackError;
import com.optum.magnusopsieventconsumer.TestConfig;
import com.optum.magnusopsieventconsumer.configuration.TokenHandler;
import com.optum.magnusopsieventconsumer.util.ConsumerConstants;
import com.optum.magnusopsieventconsumer.util.FilePrcsStatus;
import com.optum.magnusopsieventconsumer.util.FilePrcsType;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.RestTemplate;

import java.util.Collection;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

@ActiveProfiles("junits")
@SpringBootTest
@RunWith(SpringRunner.class)
@ContextConfiguration(classes = TestConfig.class)
class TrackerApiTest {

    @Value("${processTracker.url}")
    private String url;

    @Autowired
    private TrackerApi trackerApi;

    @MockBean
    private RestTemplate restTemplate;

    @MockBean
    private TokenHandler tokenHandler;

    private ObjectMapper mapper = new ObjectMapper();

    @Test
    void createBatchTrackTest() {
        FilePrcs filePrcs = new FilePrcs();
        filePrcs.setFilePrcsName("FilePrcsName");
        filePrcs.setFilePrcsStatus(FilePrcsStatus.MESSAGE_RECEIVED);
        filePrcs.setFilePrcsTypeEnum(FilePrcsType.IN);
        Collection<FilePrcs> filePrcsCollection = List.of(filePrcs);
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("Authorization", "Bearer " + "Token");
        HttpEntity<Collection<FilePrcs>> entity = new HttpEntity<>(filePrcsCollection, headers);

        when(tokenHandler.getToken()).thenReturn("Token");
        when(restTemplate.postForEntity(url + "processtrkr/batchCreateAndTrack", entity, Collection.class))
                .thenReturn(new ResponseEntity<>(List.of("File is inserted"), HttpStatusCode.valueOf(200)));
        Assertions.assertEquals(new ResponseEntity<>(List.of("File is inserted"), HttpStatusCode.valueOf(200)),
                trackerApi.createBatchTrack(filePrcsCollection));

        when(restTemplate.postForEntity(eq(url + "processtrkr/addFilePrcsTrackError"), any(), eq(FilePrcsTrackError.class)))
                .thenReturn(new ResponseEntity<>(new FilePrcsTrackError(), HttpStatusCode.valueOf(200)));
        when(restTemplate.postForEntity(url + "processtrkr/batchCreateAndTrack", entity, Collection.class))
                .thenThrow(new RuntimeException("api failed"));
        Assertions.assertEquals(new ResponseEntity<>(HttpStatusCode.valueOf(400)),
                trackerApi.createBatchTrack(filePrcsCollection));

        when(tokenHandler.getToken()).thenReturn("");
        Assertions.assertEquals(new ResponseEntity<>(HttpStatusCode.valueOf(404)),
                trackerApi.createBatchTrack(filePrcsCollection));
    }

    @Test
    void createTrackError() {
        FilePrcsTrackError trackError = new FilePrcsTrackError(null, "FilePrcsName", "Error_msg", null, null, null,
                ConsumerConstants.OPSI_CONSUMER, null, ConsumerConstants.OPSI_CONSUMER);
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("Authorization", "Bearer " + "Token");
        HttpEntity<FilePrcsTrackError> entity = new HttpEntity<>(trackError, headers);

        when(tokenHandler.getToken()).thenReturn("Token");
        when(restTemplate.postForEntity(url + "processtrkr/addFilePrcsTrackError", entity, FilePrcsTrackError.class))
                .thenReturn(new ResponseEntity<>(trackError, HttpStatusCode.valueOf(200)));
        Assertions.assertEquals(new ResponseEntity<>(trackError, HttpStatusCode.valueOf(200)),
                trackerApi.createTrackError(trackError));

        when(restTemplate.postForEntity(url + "processtrkr/addFilePrcsTrackError", entity, FilePrcsTrackError.class))
                .thenThrow(new RuntimeException("api failed"));
        Assertions.assertEquals(new ResponseEntity<>(HttpStatusCode.valueOf(500)),
                trackerApi.createTrackError(trackError));

        when(tokenHandler.getToken()).thenReturn("");
        Assertions.assertEquals(new ResponseEntity<>(HttpStatusCode.valueOf(404)),
                trackerApi.createTrackError(trackError));
    }

    @Test
    void createTrackErrorBatchTest() {
        FilePrcsErrorBatch batch = new FilePrcsErrorBatch();
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("Authorization", "Bearer " + "Token");
        HttpEntity<FilePrcsErrorBatch> entity = new HttpEntity<>(batch, headers);

        when(tokenHandler.getToken()).thenReturn("Token");
        when(restTemplate.postForEntity(url + "processtrkr/batchAddFilePrcsError", entity, FilePrcsErrorBatch.class))
                .thenReturn(new ResponseEntity<>(batch, HttpStatusCode.valueOf(200)));
        Assertions.assertEquals(new ResponseEntity<>(batch, HttpStatusCode.valueOf(200)),
                trackerApi.createTrackErrorBatch(batch));

        when(restTemplate.postForEntity(url + "processtrkr/batchAddFilePrcsError", entity, FilePrcsErrorBatch.class))
                .thenThrow(new RuntimeException("api failed"));
        Assertions.assertEquals(new ResponseEntity<>(HttpStatusCode.valueOf(500)),
                trackerApi.createTrackErrorBatch(batch));

        when(tokenHandler.getToken()).thenReturn("");
        Assertions.assertEquals(new ResponseEntity<>(HttpStatusCode.valueOf(404)),
                trackerApi.createTrackErrorBatch(batch));
    }

    @Test
    void batchUpdateFilePrcsTrackTest() {
        List<String> fileNames = List.of("file1", "file2");
        FilePrcsStatus status = FilePrcsStatus.MESSAGE_RECEIVED;
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("Authorization", "Bearer " + "Token");
        FilePrcsStatusBatchUpdate batchUpdate = new FilePrcsStatusBatchUpdate(fileNames, ConsumerConstants.OPSI_CONSUMER, status, "");
        HttpEntity<FilePrcsStatusBatchUpdate> entity = new HttpEntity<>(batchUpdate, headers);

        when(tokenHandler.getToken()).thenReturn("Token");
        when(restTemplate.postForEntity(url + "processtrkr/batchUpdateFilePrcsTrack", entity, Integer.class))
                .thenReturn(new ResponseEntity<>(1, HttpStatusCode.valueOf(200)));
        Assertions.assertEquals(new ResponseEntity<>(1, HttpStatusCode.valueOf(200)),
                trackerApi.batchUpdateFilePrcsTrack(fileNames, status));

        when(restTemplate.postForEntity(url + "processtrkr/batchUpdateFilePrcsTrack", entity, Integer.class))
                .thenThrow(new RuntimeException("fail"));
        when(restTemplate.postForEntity(eq(url + "processtrkr/batchAddFilePrcsError"), any(), eq(FilePrcsErrorBatch.class)))
                .thenReturn(new ResponseEntity<>(HttpStatusCode.valueOf(200)));
        Assertions.assertEquals(new ResponseEntity<>(HttpStatusCode.valueOf(500)),
                trackerApi.batchUpdateFilePrcsTrack(fileNames, status));

        when(tokenHandler.getToken()).thenReturn("");
        Assertions.assertEquals(new ResponseEntity<>(HttpStatusCode.valueOf(404)),
                trackerApi.batchUpdateFilePrcsTrack(fileNames, status));
    }

    @Test
    void fetchEventTriggerBodiesTest() {
        String fileType = "type";
        Long maxRetry = 2L;
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("Authorization", "Bearer " + "Token");
        HttpEntity<Void> entity = new HttpEntity<>(headers);
        String urlWithParams = String.format("%s/processtrkr/batchFetchEventTriggerBodies?fileType=%s&maxRetryCount=%d", url, fileType, maxRetry);

        when(tokenHandler.getToken()).thenReturn("Token");
        when(restTemplate.exchange(eq(urlWithParams), eq(HttpMethod.GET), eq(entity),
                any(ParameterizedTypeReference.class)))
                .thenReturn(new ResponseEntity<>(List.of(new EventTriggerBody()), HttpStatus.OK));
        Assertions.assertEquals(new ResponseEntity<>(List.of(new EventTriggerBody()), HttpStatus.OK),
                trackerApi.fetchEventTriggerBodies(fileType, maxRetry));

        when(restTemplate.exchange(eq(urlWithParams), eq(HttpMethod.GET), eq(entity),
                any(ParameterizedTypeReference.class)))
                .thenThrow(new RuntimeException("fail"));
        Assertions.assertEquals(new ResponseEntity<>(HttpStatusCode.valueOf(500)),
                trackerApi.fetchEventTriggerBodies(fileType, maxRetry));

        when(tokenHandler.getToken()).thenReturn("");
        Assertions.assertEquals(new ResponseEntity<>(HttpStatusCode.valueOf(404)),
                trackerApi.fetchEventTriggerBodies(fileType, maxRetry));
    }

    @Test
    void increaseRetryCountByFilePrcsNameInTest() {
        List<String> fileNames = List.of("file1");
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("Authorization", "Bearer " + "Token");
        HttpEntity<List<String>> entity = new HttpEntity<>(fileNames, headers);

        when(tokenHandler.getToken()).thenReturn("Token");
        when(restTemplate.postForEntity(url + "processtrkr/increaseRetryCountForFileNames", entity, Integer.class))
                .thenReturn(new ResponseEntity<>(1, HttpStatusCode.valueOf(200)));
        Assertions.assertEquals(new ResponseEntity<>(1, HttpStatusCode.valueOf(200)),
                trackerApi.increaseRetryCountByFilePrcsNameIn(fileNames));

        when(restTemplate.postForEntity(url + "processtrkr/increaseRetryCountForFileNames", entity, Integer.class))
                .thenThrow(new RuntimeException("fail"));
        when(restTemplate.postForEntity(eq(url + "processtrkr/batchAddFilePrcsError"), any(), eq(FilePrcsErrorBatch.class)))
                .thenReturn(new ResponseEntity<>(HttpStatusCode.valueOf(200)));
        Assertions.assertEquals(new ResponseEntity<>(HttpStatusCode.valueOf(500)),
                trackerApi.increaseRetryCountByFilePrcsNameIn(fileNames));

        when(tokenHandler.getToken()).thenReturn("");
        Assertions.assertEquals(new ResponseEntity<>(HttpStatusCode.valueOf(404)),
                trackerApi.increaseRetryCountByFilePrcsNameIn(fileNames));
    }
}