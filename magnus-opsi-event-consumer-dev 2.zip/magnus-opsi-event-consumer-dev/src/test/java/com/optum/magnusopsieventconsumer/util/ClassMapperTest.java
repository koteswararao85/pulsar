package com.optum.magnusopsieventconsumer.util;

import com.optum.magnusopsieventconsumer.Models.AnrADFMsg;
import com.optum.magnusopsieventconsumer.Models.FilePrcs;
import com.optum.rqns.events.v1.analytics.AnalyticsEvent;
import com.optum.rqns.events.v1.analytics.AnalyticsEventType;
import com.optum.rqns.events.v1.ccdgateway.DDGAPCPGapFileInfo;
import org.apache.avro.Schema;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;


public class ClassMapperTest {

    @Test
    void testNonNullString() {
        assertEquals("", ClassMapper.nonNullString(null));
        assertEquals("", ClassMapper.nonNullString(""));
        assertEquals("abc", ClassMapper.nonNullString("abc"));
    }

    @Test
    void testGetLobFromEventReturnsEmptyOnNull() {
        AnalyticsEvent event = new AnalyticsEvent();
        event.setData(new AnalyticsEventType());
        assertEquals("", ClassMapper.getLobFromEvent(event));
    }


    @Test
    void testAnalyticsToBatchFilePrcsThrowsExceptionOnBadSerialization() {
        AnalyticsEvent event = new AnalyticsEvent();
        AnalyticsEventType data = new AnalyticsEventType() {
            @Override
            public Schema getSchema() {
                return new Schema.Parser().parse("{\"type\":\"record\",\"name\":\"Test\",\"fields\":[{\"name\":\"badRunId\",\"type\":\"string\"}]}");
            }
            @Override
            public Object get(String field) {
                if ("badRunId".equals(field)) return "value";
                return null;
            }
        };
        event.setData(data);
        Assertions.assertThrows(RuntimeException.class, () -> {
            ClassMapper.analyticsToBatchFilePrcs(event, FilePrcsStatus.MESSAGE_RECEIVED, FilePrcsType.IN, null, null, null);
        });
    }


    @Test
    void testFilePrcsToADFMsgLobStorage() {
        FilePrcs filePrcs = new FilePrcs();
        filePrcs.setFileType("TYPE");
        filePrcs.setFilePrcsName("prcsName");
        filePrcs.setLob("MA");
        filePrcs.setFilePath("path");
        filePrcs.setRecordCount(5);
        AnrADFMsg msg = ClassMapper.FilePrcsToADFMsg(filePrcs, "maUrl", "acaUrl", "mcaidUrl");
        assertEquals("maUrl", msg.getStorage());

        filePrcs.setLob("ACA");
        msg = ClassMapper.FilePrcsToADFMsg(filePrcs, "maUrl", "acaUrl", "mcaidUrl");
        assertEquals("acaUrl", msg.getStorage());

        filePrcs.setLob("MCAID");
        msg = ClassMapper.FilePrcsToADFMsg(filePrcs, "maUrl", "acaUrl", "mcaidUrl");
        assertEquals("mcaidUrl", msg.getStorage());
    }

    @Test
    void testDigitalGateWayEventTOBatchFilePrcsException() {
        DDGAPCPGapFileInfo event = new DDGAPCPGapFileInfo();
        event.setFileName(null); // will cause substring exception
        event.setClientId("cid");
        event.setFileType("TYPE");
        event.setLob("LOB");
        event.setLocation("loc/");
        event.setStorage("storage");
        event.setContainer("container");
        event.setDataCount("10");
        event.setCorrelationId("corrId");
        Assertions.assertThrows(RuntimeException.class, () -> {
            ClassMapper.digitalGateWayEventTOBatchFilePrcs(event);
        });
    }

    @Test
    void testMapDigitalGatewayFilePrcsToADFMsg() {
        FilePrcs filePrcs = new FilePrcs();
        filePrcs.setFileType("TYPE");
        filePrcs.setFilePrcsName("DG_sensitive_gaps_test");
        filePrcs.setLob("LOB");
        filePrcs.setFilePath("loc/file.csv");
        filePrcs.setRecordCount(10);
        filePrcs.setStorageAccount("storage");
        AnrADFMsg msg = ClassMapper.mapDigitalGatewayFilePrcsToADFMsg(filePrcs, "container");
        assertEquals("TYPE", msg.getAnalytics());
        assertEquals("container", msg.getContainer());
        assertEquals("DG_sensitive_gaps_test", msg.getFilePrcsName());
        assertEquals("LOB", msg.getLob());
        assertEquals("loc/file.csv", msg.getSourceLocation());
        assertEquals("10", msg.getRecCount());
        assertEquals("storage", msg.getStorage());
        Assertions.assertTrue(msg.getDescLocation().contains("digital_gateway_sensitive_gaps"));
    }

    @Test
    void testMapDigitalGatewayFilePrcsToADFMsgException() {
        FilePrcs filePrcs = new FilePrcs();
        filePrcs.setFileType("TYPE");
        filePrcs.setFilePrcsName(null); // will cause NPE
        filePrcs.setLob("LOB");
        filePrcs.setFilePath("loc/file.csv");
        filePrcs.setRecordCount(10);
        filePrcs.setStorageAccount("storage");
        Assertions.assertThrows(RuntimeException.class, () -> {
            ClassMapper.mapDigitalGatewayFilePrcsToADFMsg(filePrcs, "container");
        });
    }

    private FilePrcs baseFilePrcs() {
        FilePrcs f = new FilePrcs();
        f.setClientId("cid");
        f.setChaseProcessId("pid");
        f.setRunID("rid");
        return f;
    }

    @Test
    void testCrgType() {
        FilePrcs f = baseFilePrcs();
        f.setFileType("CRG");
        String url = ClassMapper.deriveSourceUrl(f);
        assertTrue(url.contains("/Crg/"));
    }

    @Test
    void testDefaultType() {
        FilePrcs f = baseFilePrcs();
        f.setFileType("UNKNOWN_TYPE");
        String url = ClassMapper.deriveSourceUrl(f);
        assertTrue(url.contains("/Unknown_type/"));
    }


    @Test
    void testDigitalGateWayEventTOBatchFilePrcsExceptionOnNullFileName() {
        DDGAPCPGapFileInfo event = new DDGAPCPGapFileInfo();
        event.setFileName(null); // will cause substring exception
        event.setClientId("cid");
        event.setFileType("TYPE");
        event.setLob("LOB");
        event.setLocation("loc/");
        event.setStorage("storage");
        event.setContainer("container");
        event.setDataCount("10");
        event.setCorrelationId("corrId");

        Assertions.assertThrows(RuntimeException.class, () -> {
            ClassMapper.digitalGateWayEventTOBatchFilePrcs(event);
        });
    }

}