package com.optum.magnusopsieventconsumer.service;

import com.optum.magnusopsieventconsumer.Models.AnrADFMsg;
import com.optum.magnusopsieventconsumer.Models.FilePrcs;
import com.optum.magnusopsieventconsumer.TestConfig;
import com.optum.magnusopsieventconsumer.util.ClassMapper;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.*;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

@ActiveProfiles("junits")
@SpringBootTest
@RunWith(SpringRunner.class)
@ContextConfiguration(classes = TestConfig.class)
class ADFTriggerServiceTest {

    @Autowired
    private ADFTriggerService adfTriggerService;

    @MockBean
    private RestTemplate restTemplate;

    @MockBean
    private TrackerApi trackerApi;

    @Value("${azure.Oauth.grant-type}")
    private String grantType;
    @Value("${azure.Oauth.client-id}")
    private String clientId;
    @Value("${azure.Oauth.client-key}")
    private String clientSecret;
    @Value("${azure.Oauth.resource}")
    private String resource;
    @Value("${azure.Oauth.azure-token-url}")
    private String tokenUrl;

    @Value("${azure.anrConfig.url.ma}")
    private String maUrl;

    @Value("${azure.anrConfig.url.aca}")
    private String acaUrl;

    @Value("${azure.anrConfig.url.mcaid}")
    private String mcaidUrl;

    @Test
    void getOauthToken() throws Exception {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        MultiValueMap<String, String> inputMap = new LinkedMultiValueMap<>();
        inputMap.add("grant_type", grantType);
        inputMap.add("client_id", clientId);
        inputMap.add("client_secret", clientSecret);
        inputMap.add("resource", resource);
        HttpEntity<MultiValueMap<String, String>> entity = new HttpEntity<>(inputMap, headers);

        when( restTemplate.postForEntity(tokenUrl,entity,String.class)).thenReturn(new ResponseEntity<String>("{\"access_token\":\"Token\"}", HttpStatusCode.valueOf(200)));

        Assertions.assertEquals("Token",adfTriggerService.getOauthToken());

        when(restTemplate.postForEntity(tokenUrl,entity,String.class)).thenThrow(new RuntimeException("Time out"));

        Assertions.assertThrows(Exception.class,() -> adfTriggerService.getOauthToken());

    }

    @Test
    void batchADFTriggersTest() throws Exception {
        FilePrcs filePrcs = new FilePrcs();
        filePrcs.setFilePrcsName("filePrcsName");
        filePrcs.setFileType("fileType");
        filePrcs.setLob("MA");
        filePrcs.setRecordCount(12);
        Collection<FilePrcs> filePrcsCollection = List.of(filePrcs);
        ClassMapper mapper = new ClassMapper();
        AnrADFMsg msg = mapper.FilePrcsToADFMsg(filePrcs,maUrl,acaUrl,mcaidUrl);
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        MultiValueMap<String, String> inputMap = new LinkedMultiValueMap<>();
        inputMap.add("grant_type", grantType);
        inputMap.add("client_id", clientId);
        inputMap.add("client_secret", clientSecret);
        inputMap.add("resource", resource);
        HttpEntity<MultiValueMap<String, String>> entity = new HttpEntity<>(inputMap, headers);
        HttpHeaders adfHeaders = new HttpHeaders();
        adfHeaders.set("Authorization", "Bearer " + "Token");
        adfHeaders.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<AnrADFMsg> httpEntity = new HttpEntity<>(msg,adfHeaders);
        when(restTemplate.postForEntity(tokenUrl,entity,String.class)).thenReturn(new ResponseEntity<String>("{\"access_token\":\"Token\"}", HttpStatusCode.valueOf(200)));
        when(restTemplate.exchange(anyString(), eq(HttpMethod.POST), eq(httpEntity), eq(String.class))).thenReturn(new ResponseEntity<>("ADF triggered Successfully",HttpStatusCode.valueOf(200)));
        List<String> successfulTriggers = List.of("filePrcsName");
        Assertions.assertEquals(successfulTriggers,adfTriggerService.batchADFTriggers(filePrcsCollection));

        when(restTemplate.exchange(anyString(), eq(HttpMethod.POST), eq(httpEntity), eq(String.class))).thenThrow(new RuntimeException("Time out"));
        when(trackerApi.createTrackError(any())).thenReturn(new ResponseEntity<>(HttpStatusCode.valueOf(200)));
        Assertions.assertThrows(RuntimeException.class,()->adfTriggerService.batchADFTriggers(filePrcsCollection));
    }

    @Test
    void triggerADF_shouldCallDGAndGenericPipelinesAndBatchUpdate() throws Exception {
        AnrADFMsg dgMsg = new AnrADFMsg();
        dgMsg.setFilePrcsName("DG_testfile");
        AnrADFMsg genericMsg = new AnrADFMsg();
        genericMsg.setFilePrcsName("GEN_file");
        List<AnrADFMsg> msgs = List.of(dgMsg, genericMsg);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        MultiValueMap<String, String> inputMap = new LinkedMultiValueMap<>();
        inputMap.add("grant_type", grantType);
        inputMap.add("client_id", clientId);
        inputMap.add("client_secret", clientSecret);
        inputMap.add("resource", resource);
        HttpEntity<MultiValueMap<String, String>> entity = new HttpEntity<>(inputMap, headers);

        when(restTemplate.postForEntity(tokenUrl, entity, String.class))
                .thenReturn(new ResponseEntity<String>("{\"access_token\":\"Token\"}", HttpStatusCode.valueOf(200)));
        when(restTemplate.exchange(anyString(), eq(HttpMethod.POST), any(HttpEntity.class), eq(String.class)))
                .thenReturn(new ResponseEntity<>("ok", HttpStatusCode.valueOf(200)));
        when(trackerApi.batchUpdateFilePrcsTrack(anyList(), any())).thenReturn(new ResponseEntity<>(1, HttpStatusCode.valueOf(200)));

        List<String> successful = adfTriggerService.triggerADF(msgs);
        Assertions.assertEquals(List.of("DG_testfile", "GEN_file"), successful);
    }

    @Test
    void triggerADF_shouldCreateTrackErrorOnFailure() throws Exception {
        AnrADFMsg bad = new AnrADFMsg();
        bad.setFilePrcsName("GEN_bad");
        List<AnrADFMsg> msgs = List.of(bad);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        MultiValueMap<String, String> inputMap = new LinkedMultiValueMap<>();
        inputMap.add("grant_type", grantType);
        inputMap.add("client_id", clientId);
        inputMap.add("client_secret", clientSecret);
        inputMap.add("resource", resource);
        HttpEntity<MultiValueMap<String, String>> entity = new HttpEntity<>(inputMap, headers);

        when(restTemplate.postForEntity(tokenUrl, entity, String.class))
                .thenReturn(new ResponseEntity<String>("{\"access_token\":\"Token\"}", HttpStatusCode.valueOf(200)));
        when(restTemplate.exchange(anyString(), eq(HttpMethod.POST), any(HttpEntity.class), eq(String.class)))
                .thenThrow(new RuntimeException("fail"));
        when(trackerApi.createTrackError(any())).thenReturn(new ResponseEntity<>(HttpStatusCode.valueOf(200)));

        Assertions.assertThrows(Exception.class, () -> adfTriggerService.triggerADF(msgs));
    }

}