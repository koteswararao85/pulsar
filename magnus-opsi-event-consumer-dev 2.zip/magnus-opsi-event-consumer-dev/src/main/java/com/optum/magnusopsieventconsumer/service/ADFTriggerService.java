package com.optum.magnusopsieventconsumer.service;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectReader;
import com.optum.magnusopsieventconsumer.Models.*;
import com.optum.magnusopsieventconsumer.util.ClassMapper;
import com.optum.magnusopsieventconsumer.util.ConsumerConstants;
import com.optum.magnusopsieventconsumer.util.FilePrcsStatus;
import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import static com.optum.magnusopsieventconsumer.util.ConsumerConstants.ACCESS_TOKEN;
import static com.optum.magnusopsieventconsumer.util.ErrorCodes.AZURE_ADF_OAUTH_TOKEN_GENERATE_ERROR;
import static com.optum.magnusopsieventconsumer.util.ErrorCodes.AZURE_ADF_PIPELINE_ERROR;

@Service
@Slf4j
public class ADFTriggerService {

    @Value("${azure.Oauth.azure-token-url}")
    private String tokenUrl;
    @Value("${azure.Oauth.grant-type}")
    private String grantType;
    @Value("${azure.Oauth.client-id}")
    private String clientId;
    @Value("${azure.Oauth.client-key}")
    private String clientSecret;

    @Value("${azure.Oauth.resource}")
    private String resource;

    @Value("${azure.adfConfiguration.subscription-Id}")
    private String subscriptionId;


    @Value("${azure.adfConfiguration.resource-group-name}")
    private String resourceGroupName;

    @Value("${azure.adfConfiguration.factory-name}")
    private String adfFactoryName;

    @Value("${azure.anrConfig.url.ma}")
    private String maUrl;

    @Value("${azure.anrConfig.url.aca}")
    private String acaUrl;

    @Value("${azure.anrConfig.url.mcaid}")
    private String mcaidUrl;

    @Autowired
    private TrackerApi trackerApi;

    @Autowired
    private RestTemplate template;

    private ObjectReader reader;

    @PostConstruct
    public void init() {
        ObjectMapper jsonParser = new ObjectMapper();
        jsonParser.configure(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
        jsonParser.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        this.reader = jsonParser.readerFor(JsonNode.class);
    }
    // This method is absolete now
    @Retryable(retryFor = Exception.class, maxAttempts = 2, backoff = @Backoff(delay = 100))
    public List<String> batchADFTriggers(Collection<FilePrcs> filePrcsCollection) throws Exception {
        List<String> successfulTriggers = new ArrayList<>();
        for(FilePrcs filePrcs: filePrcsCollection){
            AnrADFMsg adfMsg = ClassMapper.FilePrcsToADFMsg(filePrcs,maUrl,acaUrl,mcaidUrl);  //TO-DO have to delete this
            String tokenValue = null;
            try {
                log.info(" trigger ADF Pipeline started with the file {} ", filePrcs.getFilePrcsName() );
                tokenValue = getOauthToken();
                log.debug(" generated azure token completed  ");
                String adfUrl = getADFTriggerUrl("pl_anr_"+filePrcs.getFileType().toLowerCase()+"_dataintake");
                HttpHeaders adfHeaders = new HttpHeaders();
                adfHeaders.set("Authorization", "Bearer " + tokenValue);
                adfHeaders.setContentType(MediaType.APPLICATION_JSON);
                log.info("Sending ADF Msg to ADF pipeline {}",adfMsg.toString());
                HttpEntity<AnrADFMsg> requestEntity = new HttpEntity<>(adfMsg, adfHeaders);
                log.debug(" constructing ADF URL   {} ", adfUrl);
                template.exchange(adfUrl, HttpMethod.POST, requestEntity, String.class);
                log.info(" trigger ADF Pipeline completed");
                successfulTriggers.add(filePrcs.getFilePrcsName());
            } catch (Exception exception) {
                log.error(" Exception occurred while triggering ADF pipeline the message stack trace: {}, exception name: {}, error code : {} , error description : {}  " ,
                        exception.getStackTrace(), exception.getMessage(), AZURE_ADF_PIPELINE_ERROR.name(),  AZURE_ADF_PIPELINE_ERROR.getDescription());
                FilePrcsTrackError trackError = new FilePrcsTrackError(null, filePrcs.getFilePrcsName(),"Failed to invoke ADF pipeline due to :"+exception.getMessage(),null,null,null, ConsumerConstants.OPSI_CONSUMER,null,ConsumerConstants.OPSI_CONSUMER);
                trackerApi.createTrackError(trackError);
                throw exception;
            }
        }
        return successfulTriggers;
    }

    @Retryable(retryFor = Exception.class, maxAttempts = 2, backoff = @Backoff(delay = 100))
    public List<String> triggerADF(List<AnrADFMsg> anrADFMsgs) throws Exception {
        List<String> successfulTriggers = new ArrayList<>();
        for(AnrADFMsg anrADFMsg: anrADFMsgs){
            String tokenValue = null;
            try {
                String sanitizedFilePrcsName = anrADFMsg.getFilePrcsName().replace('\n', '_').replace('\r', '_');
                log.info(" trigger ADF Pipeline started with the file {} ", sanitizedFilePrcsName);
                tokenValue = getOauthToken();
                log.debug(" generated azure token completed  ");
                String adfUrl="";
                if(anrADFMsg.getFilePrcsName().startsWith("DG_")){
                    adfUrl = getADFTriggerUrl("pl_digital_gateway_dataintake");
                }
                else{
                    adfUrl = getADFTriggerUrl("pl_anr_generic_dataintake");
                }

                HttpHeaders adfHeaders = new HttpHeaders();
                adfHeaders.set("Authorization", "Bearer " + tokenValue);
                adfHeaders.setContentType(MediaType.APPLICATION_JSON);
                HttpEntity<AnrADFMsg> requestEntity = new HttpEntity<>(anrADFMsg, adfHeaders);
                log.debug(" constructing ADF URL   {} ", adfUrl);
                template.exchange(adfUrl, HttpMethod.POST, requestEntity, String.class);
                log.info(" trigger ADF Pipeline completed");
                successfulTriggers.add(anrADFMsg.getFilePrcsName());
            } catch (Exception exception) {
                log.error(" Exception occurred while triggering ADF pipeline the message stack trace: {}, exception name: {}, error code : {} , error description : {}  " ,
                        exception.getStackTrace(), exception.getMessage(), AZURE_ADF_PIPELINE_ERROR.name(),  AZURE_ADF_PIPELINE_ERROR.getDescription());
                FilePrcsTrackError trackError = new FilePrcsTrackError(null, anrADFMsg.getFilePrcsName(),"Failed to invoke ADF pipeline due to :"+exception.getMessage(),null,null,null, ConsumerConstants.OPSI_CONSUMER,null,ConsumerConstants.OPSI_CONSUMER);
                trackerApi.createTrackError(trackError);
                throw exception;
            }
        }
        trackerApi.batchUpdateFilePrcsTrack(successfulTriggers, FilePrcsStatus.valueOf("FILE_TRANSFER_INITIATED"));
        return successfulTriggers;
    }

    private String getADFTriggerUrl(String pipeline) {
        StringBuilder adfFactoryURL = new StringBuilder("https://management.azure.com/subscriptions/");
        adfFactoryURL.append(subscriptionId);
        adfFactoryURL.append("/resourceGroups/");
        adfFactoryURL.append(resourceGroupName);
        adfFactoryURL.append("/providers/Microsoft.DataFactory/factories/");
        adfFactoryURL.append(adfFactoryName);
        adfFactoryURL.append("/pipelines/");
        adfFactoryURL.append(pipeline);
        adfFactoryURL.append("/createRun?api-version=2018-06-01");
        return adfFactoryURL.toString();
    }


    @Retryable
    public String getOauthToken() throws Exception {

//        log.info(" tokenUrl ======>   {} ", tokenUrl);
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
            MultiValueMap<String, String> inputMap = new LinkedMultiValueMap<>();
            inputMap.add("grant_type", grantType);
            inputMap.add("client_id", clientId);
            inputMap.add("client_secret", clientSecret);
            inputMap.add("resource", resource);
            HttpEntity<MultiValueMap<String, String>> entity = new HttpEntity<>(inputMap, headers);
            ResponseEntity<String> response = template.postForEntity(tokenUrl, entity, String.class);
            return reader.readTree(response.getBody()).get(ACCESS_TOKEN).asText();
        } catch (Exception exception) {

            log.error(" Exception occurred while getting ADF Oauth token pipeline the message stack trace: {}, exception name: {}, error code : {} , error description : {}  " ,
                    exception.getStackTrace(), exception.getMessage(), AZURE_ADF_OAUTH_TOKEN_GENERATE_ERROR.name(),  AZURE_ADF_OAUTH_TOKEN_GENERATE_ERROR.getDescription());

            throw exception;
        }
    }
}
