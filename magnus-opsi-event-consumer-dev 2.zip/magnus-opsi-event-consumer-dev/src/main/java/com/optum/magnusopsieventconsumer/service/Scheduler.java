package com.optum.magnusopsieventconsumer.service;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectReader;
import com.optum.magnusopsieventconsumer.Models.AnrADFMsg;
import com.optum.magnusopsieventconsumer.Models.EventTriggerBody;
import com.optum.magnusopsieventconsumer.Models.FilePrcsTrackError;
import com.optum.magnusopsieventconsumer.util.ConsumerConstants;
import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import net.javacrumbs.shedlock.spring.annotation.SchedulerLock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.*;

@Component
@Slf4j
public class Scheduler {

    @Autowired
    private TrackerApi trackerApi;

    @Autowired
    private ADFTriggerService adfTriggerService;

    @Value("${processTracker.max-retry-attempts}")
    private Long maxRetryAttempts;

    private ObjectReader reader;

    @PostConstruct
    public void init() {
        ObjectMapper jsonParser = new ObjectMapper();
        jsonParser.configure(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
        jsonParser.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        this.reader = jsonParser.readerFor(AnrADFMsg.class);
    }
    private final List<String> fileTypes = Arrays.asList("quality", "analytic_member", "analytic_claim", "rendering", "risk");

    @Scheduled(fixedDelay = 300000) // 30 minutes in milliseconds
    @SchedulerLock(name = "opsi_consumer_scheduler", lockAtMostFor = "PT5M", lockAtLeastFor = "PT3M")
    public void performTask() {
        log.info("Scheduler started at : " + System.currentTimeMillis());
        for (String fileType : fileTypes) {
            processFileType(fileType);
        }
        log.info("Task executed at: " + System.currentTimeMillis());
    }

    private void processFileType(String fileType) {
        log.info("Fetching event trigger bodies for fileType: " + fileType);
        ResponseEntity<List<EventTriggerBody>> response = trackerApi.fetchEventTriggerBodies(fileType, maxRetryAttempts);
        String sanitizedFileType = fileType.replace('\n', '_').replace('\r', '_');

        if (response.getBody() == null) {
            log.info("There no files to process for fileType: {}", sanitizedFileType);
            return;
        }

        String sanitizedResponseBody = response.getBody().toString().replace('\n', '_').replace('\r', '_');
        log.info("Response received for fileType: {}. Status code: {} and files: {}", sanitizedFileType, response.getStatusCode(), sanitizedResponseBody);

        if (!response.getStatusCode().is2xxSuccessful()) {
            log.error("Failed to fetch event trigger bodies for fileType " + fileType + ". Status code: " + response.getStatusCode());
            return;
        }

        List<String> filePrcsNames = new ArrayList<>();
        List<AnrADFMsg> anrADFMsgsList = new ArrayList<>();
        parseEventTriggerBodies(response.getBody(), fileType, filePrcsNames, anrADFMsgsList);

        try {
            trackerApi.increaseRetryCountByFilePrcsNameIn(filePrcsNames);
        } catch (Exception ex) {
            log.error("Failed to increment the Retry count for " + fileType, ex);
        }

        if (anrADFMsgsList.isEmpty()) return;

        try {
            adfTriggerService.triggerADF(anrADFMsgsList);
            log.info("ADF Trigger is complete for fileType " + fileType);
        } catch (Exception ex) {
            log.error("Failed to invoke the ADF trigger for fileType " + fileType, ex);
        }
    }

    private void parseEventTriggerBodies(List<EventTriggerBody> eventTriggerBodies, String fileType, List<String> filePrcsNames, List<AnrADFMsg> anrADFMsgsList) {
        for (EventTriggerBody eventTriggerBody : eventTriggerBodies) {
            try {
                AnrADFMsg anrADFMsg = reader.readValue(eventTriggerBody.getEventTriggerBody());
                anrADFMsgsList.add(anrADFMsg);
                filePrcsNames.add(eventTriggerBody.getFilePrcsName());
            } catch (Exception e) {
                log.info("creating a error entry into tracking tables for file name : " + eventTriggerBody.getFilePrcsName().replace('\n', '_').replace('\r', '_'));
                trackerApi.increaseRetryCountByFilePrcsNameIn(Collections.singletonList(eventTriggerBody.getFilePrcsName()));
                FilePrcsTrackError trackError = new FilePrcsTrackError(null, eventTriggerBody.getFilePrcsName(), "Failed to deserialize eventTriggerBody due to :" + e.getMessage(), null, null, null, ConsumerConstants.OPSI_CONSUMER, null, ConsumerConstants.OPSI_CONSUMER);
                trackerApi.createTrackError(trackError);
                log.error("Failed to deserialize eventTriggerBody for fileType " + fileType, e);
            }
        }
    }
}
