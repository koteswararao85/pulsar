package com.optum.magnusopsieventconsumer.util;


import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.optum.magnusopsieventconsumer.Models.AnrADFMsg;
import com.optum.magnusopsieventconsumer.Models.DigitalGatewayEvent;
import com.optum.magnusopsieventconsumer.Models.FilePrcs;
import com.optum.rqns.events.v1.analytics.AnalyticsEvent;
import com.optum.rqns.events.v1.analytics.AnalyticsEventType;
import com.optum.rqns.events.v1.ccdgateway.DDGAPCPGapFileInfo;
import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.apache.avro.Schema;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Objects;

import static com.optum.magnusopsieventconsumer.util.ConsumerConstants.*;
import static com.optum.magnusopsieventconsumer.util.LobMap.*;

@Component
@Slf4j
public class ClassMapper {


    private static ObjectWriter writer;

    static {
        ObjectMapper jsonParser = new ObjectMapper();
        jsonParser.configure(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
        jsonParser.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        writer = jsonParser.writerFor(AnrADFMsg.class);
    }


    public static String getLobFromEvent(AnalyticsEvent event) {
        Object temp = hashMapLob.get(nonNullString(event.getData().getSubCliSk()));
        return temp == null ? "" : (String) temp;
    }

    public static String nonNullString(CharSequence obj) {
        return StringUtils.isEmpty(obj) ? "" : obj.toString();
    }

    public static FilePrcs setFilePrcsFromData(AnalyticsEvent event, String fieldName, FilePrcsStatus status, FilePrcsType prcsType) {
        FilePrcs filePrcs = new FilePrcs();
        AnalyticsEventType data = event.getData();
        filePrcs.setClientId(StringUtils.isEmpty(data.getSubCliSk()) ? "" : data.getSubCliSk().toString());
        filePrcs.setCorrelationId(StringUtils.isEmpty(event.getCorrelationId()) ? "" : event.getCorrelationId().toString());
        filePrcs.setRunID(StringUtils.isEmpty((CharSequence) data.get(fieldName)) ? "" : data.get(fieldName).toString());
        filePrcs.setChaseProcessId(StringUtils.isEmpty(data.getPacketId()) ? "" : data.getPacketId().toString());
        filePrcs.setOrigSourceInfo(StringUtils.isEmpty(event.getSource()) ? "" : event.getSource().toString());
        filePrcs.setBatchStartTIme(StringUtils.isEmpty(event.getEventTime()) ? "" : event.getEventTime().toString());
        filePrcs.setInsrtUserId(ConsumerConstants.OPSI_CONSUMER);
        filePrcs.setUpdtUserId(ConsumerConstants.OPSI_CONSUMER);
        filePrcs.setFilePrcsStatus(status);
        filePrcs.setFilePrcsTypeEnum(prcsType);
        filePrcs.setLob(hashMapLob.get(data.getSubCliSk().toString()));
        return filePrcs;
    }

    public static Collection<FilePrcs> deriveFilePrcs(String analyticsName, FilePrcs filePrcs, AnalyticsEventType data, AnalyticsEvent event, String fieldName, FilePrcsStatus status, FilePrcsType prcsType) {
        Collection<FilePrcs> filePrcsCollection = new ArrayList<>();
        switch (analyticsName) {
            case "risk" -> filePrcsCollection.addAll(deriveForRisk(filePrcs, data, event, fieldName, status, prcsType));
            case "raf" -> filePrcsCollection.addAll(deriveForRaf(filePrcs, data, event, fieldName, status, prcsType));
            case "claimsSummary" -> filePrcsCollection.addAll(deriveForClaimsSummary(filePrcs, data, event, fieldName, status, prcsType));
            case "careModality" -> {
                filePrcs.setFileType(CARE_MODALITY);
                filePrcs.setFilePrcsName(CARE_MODALITY + "_" + filePrcs.getClientId() + "_" + nonNullString(data.getPacketId()) + "_" + filePrcs.getRunID());
                filePrcsCollection.add(filePrcs);
            }
            case "carePriority" -> {
                filePrcs.setFileType(CARE_PRIORITY);
                filePrcs.setFilePrcsName(CARE_PRIORITY + "_" + filePrcs.getClientId() + "_" + nonNullString(data.getPacketId()) + "_" + filePrcs.getRunID());
                filePrcsCollection.add(filePrcs);
            }
            case "crg" -> {
                filePrcs.setFileType(CRG);
                filePrcs.setFilePrcsName(CRG + "_" + filePrcs.getClientId() + "_" + nonNullString(data.getPacketId()) + "_" + filePrcs.getRunID());
                filePrcsCollection.add(filePrcs);
            }
            case "preferredProvider", RENDERING -> {
                filePrcs.setFileType(RENDERING);
                filePrcs.setFilePrcsName(RENDERING + "_" + filePrcs.getClientId() + "_" + nonNullString(data.getPacketId()) + "_" + filePrcs.getRunID());
                if (!analyticsName.equalsIgnoreCase(RENDERING)) filePrcsCollection.add(filePrcs);
            }
            default -> filePrcsCollection.add(filePrcs);
        }
        return filePrcsCollection;
    }

    private static Collection<FilePrcs> deriveForRisk(FilePrcs filePrcs, AnalyticsEventType data, AnalyticsEvent event, String fieldName, FilePrcsStatus status, FilePrcsType prcsType) {
        Collection<FilePrcs> result = new ArrayList<>();
        FilePrcs filePrcs1 = setFilePrcsFromData(event, fieldName, status, prcsType);
        filePrcs1.setFileType(SCR);
        filePrcs1.setFilePrcsName(SCREENING_ROLLUP + "_" + filePrcs1.getClientId() + "_" + nonNullString(data.getPacketId()) + "_" + filePrcs.getRunID());
        filePrcs.setFilePrcsName(SUSPECTS_ROLLUP + "_" + filePrcs.getClientId() + "_" + nonNullString(data.getPacketId()) + "_" + filePrcs.getRunID());
        filePrcs.setFileType(PARTC);
        result.add(filePrcs1);
        result.add(filePrcs);
        return result;
    }

    private static Collection<FilePrcs> deriveForRaf(FilePrcs filePrcs, AnalyticsEventType data, AnalyticsEvent event, String fieldName, FilePrcsStatus status, FilePrcsType prcsType) {
        Collection<FilePrcs> result = new ArrayList<>();
        if (!Objects.equals(filePrcs.getLob(), MA)) {
            filePrcs.setFileType(RAF);
            filePrcs.setFilePrcsName(RAFLOBNAME.get(filePrcs.getLob()) + "_" + RAF + "_" + filePrcs.getClientId() + "_" + nonNullString(data.getPacketId()) + "_" + filePrcs.getRunID());
            result.add(filePrcs);
            return result;
        }
        FilePrcs filePrcs1 = setFilePrcsFromData(event, fieldName, status, prcsType);
        filePrcs1.setFileType(BLD_PARTC_BASE_RAF);
        filePrcs1.setFilePrcsName(BLD_PARTC_BASE_RAF + "_" + filePrcs1.getClientId() + "_" + nonNullString(data.getPacketId()) + "_" + filePrcs.getRunID());
        filePrcs.setFilePrcsName(BLD_PARTC_ESRD_RAF + "_" + filePrcs.getClientId() + "_" + nonNullString(data.getPacketId()) + "_" + filePrcs.getRunID());
        filePrcs.setFileType(BLD_PARTC_ESRD_RAF);
        result.add(filePrcs);
        result.add(filePrcs1);
        return result;
    }

    private static Collection<FilePrcs> deriveForClaimsSummary(FilePrcs filePrcs, AnalyticsEventType data, AnalyticsEvent event, String fieldName, FilePrcsStatus status, FilePrcsType prcsType) {
        Collection<FilePrcs> result = new ArrayList<>();
        CLAIMS.forEach(claimType -> {
            String claim = claimType;
            FilePrcs filePrcsTemp = setFilePrcsFromData(event, fieldName, status, prcsType);
            if (claim.equals(MEMBER_HCC_DXCOUNTS) && filePrcsTemp.getLob().equals(MCAID)) claim = MEMBER_DSS_DXCOUNTS;
            if (claim.equals(MEMBER_DXCOUNTS) && filePrcsTemp.getLob().equals(MCAID)) claim = MCAID_MEMBER_DXCOUNTS;
            filePrcsTemp.setFileType(claim);
            filePrcsTemp.setFilePrcsName(claim + "_" + filePrcsTemp.getClientId() + "_" + nonNullString(data.getPacketId()) + "_" + filePrcs.getRunID());
            result.add(filePrcsTemp);
        });
        return result;
    }

    public static Collection<FilePrcs> analyticsToBatchFilePrcs(AnalyticsEvent event, FilePrcsStatus status, FilePrcsType prcsType, String maUrl, String acaUrl, String mcaidUrl) throws IOException {
        AnalyticsEventType data = event.getData();
        Collection<FilePrcs> filePrcsCollection = new ArrayList<>();
        String serializedEvent = event.toString();

        for (Schema.Field field : data.getSchema().getFields()) {
            String fieldName = field.name();
            if ((!fieldName.matches(".*RunId$") && !fieldName.matches(".*ProviderId$")) || data.get(fieldName) == null || Objects.equals(nonNullString((CharSequence) data.get(fieldName)), ""))
                continue;
            String analyticsName = fieldName.matches(".*ProviderId$") ? fieldName.split("Id")[0] : fieldName.split("RunId")[0];
            FilePrcs filePrcs = setFilePrcsFromData(event, fieldName, status, prcsType);
            filePrcs.setFileType(analyticsName);
            filePrcs.setFilePrcsName(analyticsName + "_" + filePrcs.getClientId() + "_" + nonNullString(data.getPacketId()) + "_" + filePrcs.getRunID());
            Collection<FilePrcs> temp = deriveFilePrcs(analyticsName, filePrcs, data, event, fieldName, status, prcsType);
            filePrcsCollection.addAll(temp);
        }
        filePrcsCollection.forEach(filePrcs -> filePrcs.setFilePath(deriveSourceUrl(filePrcs)));
        filePrcsCollection.forEach(filePrcs -> {
            switch (filePrcs.getFileType()) {
                case PARTC, SCR -> filePrcs.setFileType(RISK);
                default -> {
                    if (MEMBERS.contains(filePrcs.getFileType())) {
                        filePrcs.setFileType(MEMBER_TAG);
                    } else if (CLAIMS.contains(filePrcs.getFileType()) || Objects.equals(filePrcs.getFileType(), MEMBER_DSS_DXCOUNTS)) {
                        filePrcs.setFileType(CLAIMS_TAG);
                    }
                }
            }
            filePrcs.setFileName("anr/" + filePrcs.getFileType() + "/" + filePrcs.getFilePrcsName());
            filePrcs.setEventMessage(serializedEvent);
            filePrcs.setRetryCount(0L);
            String serializedEventTriggerBody;
            AnrADFMsg anrADFMsg;
            try {
                anrADFMsg = FilePrcsToADFMsg(filePrcs, maUrl, acaUrl, mcaidUrl);
                serializedEventTriggerBody = writer.writeValueAsString(anrADFMsg);
            } catch (Exception e) {
                throw new RuntimeException("Failed to serialize Event Trigger Body", e);
            }
            filePrcs.setStorageAccount(anrADFMsg.getStorage());
            filePrcs.setEventTriggerBody(serializedEventTriggerBody);
        });
        return filePrcsCollection;
    }

    public static String deriveSourceUrl(FilePrcs filePrcs) {
        String sourceLocation;
        switch (filePrcs.getFileType()) {
            case PARTC:
                sourceLocation = OPSI_CONTAINER + "/Risk/" + filePrcs.getClientId() + "/" + filePrcs.getChaseProcessId() + "/" + filePrcs.getRunID() + "/rollupSuspects";
                break;
            case SCR:
                sourceLocation = OPSI_CONTAINER + "/Risk/" + filePrcs.getClientId() + "/" + filePrcs.getChaseProcessId() + "/" + filePrcs.getRunID() + "/screeningRollup";
                break;
            case QUALITY:
                sourceLocation = OPSI_CONTAINER + "/Quality/" + filePrcs.getClientId() + "/" + filePrcs.getChaseProcessId() + "/" + filePrcs.getRunID() + "/gaps";
                break;
            case BLD_PARTC_BASE_RAF, BLD_PARTC_ESRD_RAF:
                sourceLocation = OPSI_CONTAINER + "/Raf/" + filePrcs.getClientId() + "/" + filePrcs.getChaseProcessId() + "/" + filePrcs.getRunID() + "/" + filePrcs.getFileType();
                break;
            case RAF:
                sourceLocation = OPSI_CONTAINER + "/RAF/" + filePrcs.getClientId() + "/" + filePrcs.getChaseProcessId() + "/" + filePrcs.getRunID() + "/Raf";
                break;
            case CARE_MODALITY:
                sourceLocation = OPSI_CONTAINER + "/caremodality/" + filePrcs.getClientId() + "/" + filePrcs.getChaseProcessId() + "/" + filePrcs.getRunID() + "/care_modality";
                break;
            case CARE_PRIORITY:
                sourceLocation = OPSI_CONTAINER + "/CPG/" + filePrcs.getClientId() + "/" + filePrcs.getChaseProcessId() + "/" + filePrcs.getRunID() + "/OpsiCPG";
                break;
            case CRG:
                sourceLocation = OPSI_CONTAINER + "/Crg/" + filePrcs.getClientId() + "/" + filePrcs.getChaseProcessId() + "/" + filePrcs.getRunID();
                break;
            case RENDERING:
                sourceLocation = OPSI_CONTAINER + "/PrefferedProvider/" + filePrcs.getClientId() + "/" + filePrcs.getChaseProcessId() + "/" + filePrcs.getRunID() + "/memProvRelationship";
                break;
            default:
                if (CLAIMS.contains(filePrcs.getFileType()) || Objects.equals(filePrcs.getFileType(), MEMBER_DSS_DXCOUNTS) || Objects.equals(filePrcs.getFilePrcsType(), MCAID_MEMBER_DXCOUNTS)) {
                    sourceLocation = OPSI_CONTAINER + "/ClaimsSummary/" + filePrcs.getClientId() + "/" + filePrcs.getChaseProcessId() + "/" + filePrcs.getRunID() + "/" + CLAIMS_FOLDER_NAME.get(filePrcs.getFileType());
                } else {
                    String fileType = filePrcs.getFileType().substring(0, 1).toUpperCase() + filePrcs.getFileType().substring(1).toLowerCase();
                    sourceLocation = OPSI_CONTAINER + "/" + fileType + "/" + filePrcs.getClientId() + "/" + filePrcs.getChaseProcessId() + "/" + filePrcs.getRunID();
                }
                break;
        }
        return sourceLocation;
    }

    public static AnrADFMsg FilePrcsToADFMsg(FilePrcs filePrcs, String maUrl, String acaUrl, String mcaidUrl) {
        String sourceLocation = nonNullString(filePrcs.getFilePath());
        String storageName;
        String descLocation = filePrcs.getFileName();
        String lob = nonNullString(filePrcs.getLob());
        switch (lob) {
            case "MA" -> storageName = maUrl;
            case "ACA" -> storageName = acaUrl;
            case "MCAID" -> storageName = mcaidUrl;
            default -> {
                sourceLocation = "https://samagnusldzonecusdev.dfs.core.windows.net/analytics-results/";
                storageName = "samagnusldzonecusdev";
            }
        }
        String recordCount = filePrcs.getRecordCount() == null ? "" : filePrcs.getRecordCount().toString();
        return new AnrADFMsg(filePrcs.getFileType(), "anr-landingzone", filePrcs.getFilePrcsName(), filePrcs.getLob(), sourceLocation, recordCount, storageName, descLocation);
    }

    public static Collection<FilePrcs> digitalGateWayEventTOBatchFilePrcs(DDGAPCPGapFileInfo event) {
        DigitalGatewayEvent digitalGatewayEvent = new DigitalGatewayEvent();
        digitalGatewayEvent.setClientId(nonNullString(event.getClientId()));
        digitalGatewayEvent.setFileName(nonNullString(event.getFileName()));
        digitalGatewayEvent.setFileType(nonNullString(event.getFileType()));
        digitalGatewayEvent.setLob(nonNullString(event.getLob()));
        digitalGatewayEvent.setLocation(nonNullString(event.getLocation()));
        digitalGatewayEvent.setStorage(nonNullString(event.getStorage()));
        digitalGatewayEvent.setContainer(nonNullString(event.getContainer()));
        digitalGatewayEvent.setDataCount(nonNullString(event.getDataCount()));
        digitalGatewayEvent.setCorrelationId(nonNullString(event.getCorrelationId()));

        FilePrcs filePrcs = new FilePrcs();
        try{
            String fileName = event.getFileName().toString().substring(0, event.getFileName().toString().lastIndexOf("."));
            filePrcs.setClientId(nonNullString(event.getClientId()));
        filePrcs.setCorrelationId(nonNullString(event.getCorrelationId()));
        filePrcs.setFilePrcsName(nonNullString(fileName));
        filePrcs.setFileName(nonNullString(event.getFileName()));
        filePrcs.setStorageAccount(nonNullString(event.getStorage()));
        filePrcs.setStorageUrlID(nonNullString("https://" + event.getStorage() + ".dfs.core.windows.net"));
        filePrcs.setOrigSourceInfo("DigitalGateway");
        filePrcs.setFilePath(event.getLocation().toString()+event.getFileName().toString());
        filePrcs.setInsrtUserId(ConsumerConstants.OPSI_CONSUMER);
        filePrcs.setUpdtUserId(ConsumerConstants.OPSI_CONSUMER);
        filePrcs.setRecordCount(Integer.parseInt(event.getDataCount().toString()));
        filePrcs.setFilePrcsStatus(FilePrcsStatus.MESSAGE_RECEIVED);
        filePrcs.setFilePrcsTypeEnum(FilePrcsType.IN);
        filePrcs.setFileType(nonNullString(event.getFileType()));
        filePrcs.setLob(nonNullString(event.getLob()));
        filePrcs.setRetryCount(0L);
        filePrcs.setEventMessage(event.toString());}
        catch (Exception e) {
            throw new RuntimeException("Failed to map Digital Gateway Event to FilePrcs", e);
        }
        try {
            filePrcs.setEventTriggerBody(writer.writeValueAsString(mapDigitalGatewayFilePrcsToADFMsg(filePrcs,event.getContainer().toString())));
        } catch (Exception e) {
            throw new RuntimeException("Failed to map filePrcs to ADF MSG ", e);
        }
        Collection<FilePrcs> filePrcsCollection = new ArrayList<>();
        filePrcsCollection.add(filePrcs);
        return filePrcsCollection;

    }
    public static AnrADFMsg mapDigitalGatewayFilePrcsToADFMsg(FilePrcs filePrcs,String container){
        AnrADFMsg adfMsg = new AnrADFMsg();
       try{
           String folderName = filePrcs.getFilePrcsName();
           adfMsg.setAnalytics(filePrcs.getFileType());
        adfMsg.setContainer(container);
        adfMsg.setFilePrcsName(folderName);
        adfMsg.setLob(filePrcs.getLob());
        adfMsg.setSourceLocation(filePrcs.getFilePath());
        adfMsg.setRecCount(filePrcs.getRecordCount().toString());
        adfMsg.setStorage(filePrcs.getStorageAccount());
        adfMsg.setDescLocation("anr/" + (folderName.startsWith("DG_sensitive_gaps_") ? "digital_gateway_sensitive_gaps/" : "digital_gateway_suspects_rollup/") + folderName);}
       catch (Exception e) {
           throw new RuntimeException("Failed to map Digital Gateway FilePrcs to ADF Message", e);
       }
        return adfMsg;
    }
}



