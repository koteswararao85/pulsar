package com.optum.magnusopsieventconsumer.util;


import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.optum.magnusopsieventconsumer.util.LobMap.ACA;
import static com.optum.magnusopsieventconsumer.util.LobMap.MCAID;

public class ConsumerConstants {

    private ConsumerConstants() {
    }
    public static final String OPSI_CONSUMER = "OPSI_CONSUMER";

    public static final String AVRO_SCHEMA = "{\"namespace\": \"com.optum.opsi.analytics.common.events\",\"name\": \"AnalyticsEvent\",\"doc\": \"An event representing analytics event\",\"type\": \"record\",\"fields\": [{\"name\": \"analytics\",\"type\": [\"string\",\"null\"]},{\"name\": \"clientName\",\"type\": [\"string\",\"null\"]},{\"name\": \"packetId\",\"type\": [\"string\",\"null\"]},{\"name\": \"opsiRunId\",\"type\": [\"string\",\"null\"]},    {\"name\": \"lob\",\"type\": [\"string\",\"null\"]},{\"name\": \"outputLocation\",\"type\": [\"string\",\"null\"]},{\"name\": \"recCount\",\"type\": [\"string\",\"null\"]},    {\"name\": \"storage\",\"type\": [\"string\",\"null\"]},    {\"name\": \"container\",\"type\": [\"string\",\"null\"]},{\"name\": \"eventTime\",\"doc\": \"https://tools.ietf.org/html/rfc3339\",\"type\": [\"string\",\"null\"]}]}";

    public static final String ACCESS_TOKEN = "access_token";

    public static final String OPSI_CONTAINER = "analytics-results";

    public static final String RAF = "raf";

    public static final String BLD_PARTC_BASE_RAF = "bld_partc_base_raf";

    public static final String GAP = "analytic_gaps";

    public static final String BLD_PARTC_ESRD_RAF = "bld_partc_esrd_raf";

    public static final String PARTC = "partc";

    public static final String SUSPECTS_ROLLUP = "suspects_rollup";

    public static final String SCREENING_ROLLUP = "screening_rollup";

    public static final String SCR = "scr";

    public static final String CARE_MODALITY = "care_modality";

    public static final String CARE_PRIORITY = "care_priority_group";

    public static final String CRG = "clinical_risk_group";

    public static final String CLAIMS_TAG = "analytic_claim";

    public static final String RISK = "risk";

    public static final String RENDERING = "rendering";

    public static final String MEMBER_TAG = "analytic_member";

    public static final String QUALITY = "quality";

    public static final String MEMBER_HCC_DXCOUNTS = "member_hcc_dxcounts";

    public static final String MEMBER_DSS_DXCOUNTS = "member_dss_dxcounts";

    public static final String MEMBER_DXCOUNTS = "member_dxcounts";

    public static final String MCAID_MEMBER_DXCOUNTS = "medicaid_member_dxcounts";

    public static final Collection<String> MEMBERS = List.of(BLD_PARTC_BASE_RAF,BLD_PARTC_ESRD_RAF,CARE_PRIORITY,MEMBER_HCC_DXCOUNTS,MEMBER_DXCOUNTS,MCAID_MEMBER_DXCOUNTS,MEMBER_DSS_DXCOUNTS,CARE_MODALITY,RAF,CRG);

    public static final Collection<String> CLAIMS = List.of("er_visits","annual_visits","hospital_admits","physician_visits","tele_visits",MEMBER_HCC_DXCOUNTS,MEMBER_DXCOUNTS,"mbr_dx_dos_prov");

    public static final Map<String, String> CLAIMS_FOLDER_NAME = new HashMap<>(){{
        put("er_visits", "ErVisits");
        put("annual_visits", "AnnualVisits");
        put("hospital_admits", "HospAdmits");
        put("physician_visits", "PhyVisits");
        put("tele_visits","TeleVisits");
        put(MEMBER_HCC_DXCOUNTS, "MbrHccDx");
        put(MEMBER_DSS_DXCOUNTS, "MbrDssDx");
        put(MEMBER_DXCOUNTS, "MbrDx");
        put(MCAID_MEMBER_DXCOUNTS, "MbrDx");
        put("mbr_dx_dos_prov", "MbrDxDosProv");
    }};

    public static final Map<String, String> RAFLOBNAME = new HashMap<>(){{
        put(ACA,"aca");
        put(MCAID,"medicaid");
    }};
}
