package com.optum.magnusopsieventconsumer.Models;

import com.optum.magnusopsieventconsumer.util.FilePrcsStatus;
import lombok.Data;
import java.time.LocalDateTime;

@Data
public class FilePrcsTrack  {

    private String  filePrcsKey;
    private String filePrcsName;
    private String filePrcsType;
    private String  filePrcsTypeEnum;
    private Integer filePrcsStsKey;
    private FilePrcsStatus filePrcsStatus;
    private String  fileSize;
    private String attempts;
    private String totalCount;
    private String prntFilePrcsKey;
    private LocalDateTime insrtDttm;
    private String insrtUserId;
    private LocalDateTime updtDttm;
    private String updtUserId;
    private String sourceSystem;
    private Long retryCount;

}
