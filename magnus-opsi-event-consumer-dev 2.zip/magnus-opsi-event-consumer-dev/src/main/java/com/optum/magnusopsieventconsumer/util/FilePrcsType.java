package com.optum.magnusopsieventconsumer.util;

public enum FilePrcsType {
    IN,
    OUT;
}
