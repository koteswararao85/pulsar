package com.optum.magnusopsieventconsumer.Models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AnrADFMsg {
    private String analytics;
    private String container;
    private String filePrcsName;
    private String lob;
    private String sourceLocation;
    private String recCount;
    private String storage;
    private String descLocation;
}
